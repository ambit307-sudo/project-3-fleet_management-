#!/usr/bin/env python3
# =============================================================================
# robots/robot2.py
# =============================================================================
# ROS2 node for Robot 2 of the Fleet Management System.
#
# Namespace  : /robot_2   (set by multi_robot.launch.py via PushRosNamespace)
# Robot model: TurtleBot3 Burger
#
# Responsibilities
# ----------------
#   • Maintain a finite-state machine (IDLE → NAVIGATING → EXECUTING →
#     RETURNING → CHARGING → EMERGENCY_STOP)
#   • Subscribe to sensor topics (odometry, LiDAR scan, IMU)
#   • Execute navigation goals received from the fleet manager
#   • Report pose, battery level, state, and task status back to the fleet
#   • Perform local obstacle avoidance (VFH-lite) when no global path exists
#   • Publish velocity commands to /robot_2/cmd_vel
#   • Publish heartbeat so the fleet manager can detect node failures
#
# Topics (all relative to /robot_2 namespace unless noted)
# ---------------------------------------------------------
#   Subscribed
#     ~/odom                     nav_msgs/Odometry
#     ~/scan                     sensor_msgs/LaserScan
#     ~/imu                      sensor_msgs/Imu
#     /fleet/robot_2/goal        geometry_msgs/PoseStamped   (from fleet mgr)
#     /fleet/robot_2/command     std_msgs/String              (CANCEL / STOP)
#     /fleet/robot_2/task        fleet_management/TaskAssignment (custom msg)
#
#   Published
#     ~/cmd_vel                  geometry_msgs/Twist
#     /fleet/robot_2/status      fleet_management/RobotStatus (custom msg)
#     /fleet/robot_2/heartbeat   std_msgs/Header
#     ~/path_markers             visualization_msgs/MarkerArray (RViz)
#
# Parameters (declared with defaults)
# ------------------------------------
#   robot_id          : int    = 2
#   max_linear_vel    : float  = 0.22   m/s  (Burger hardware limit)
#   max_angular_vel   : float  = 2.84   rad/s
#   goal_tolerance    : float  = 0.10   m
#   heading_tolerance : float  = 0.08   rad
#   battery_drain_rate: float  = 0.005  %/s  (simulated)
#   low_battery_thresh: float  = 20.0   %
#   obstacle_threshold: float  = 0.35   m    (LiDAR stop distance)
#   collision_lookahead: float = 0.5    m
#   use_sim_time      : bool   = True
#
# Design notes vs robot1.py
# -------------------------
#   • CHARGING_Y = -1.0  (charging_pad_2 in warehouse.world)
#   • Initial pose seeded at (-8.0, -1.0) to match Gazebo spawn
#   • Battery starts at 85.0 % — staggers fleet charge cycles so robot_2
#     will need to return before robot_1 and after robot_3, spreading load
#   • RViz goal marker colour: blue  (r=0.18, g=0.52, b=1.0)
#     vs robot_1 green and robot_3 orange — visually distinct in RViz
#   • All topic names updated to /fleet/robot_2/…
#   • Node name: robot2_node
# =============================================================================

from __future__ import annotations

import math
import time
from enum import Enum, auto
from typing import List, Optional, Tuple

import rclpy
from rclpy.node import Node
from rclpy.qos import (
    QoSDurabilityPolicy,
    QoSProfile,
    QoSReliabilityPolicy,
    qos_profile_sensor_data,
)

from geometry_msgs.msg import PoseStamped, Twist, Point
from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan, Imu
from std_msgs.msg import String, Header
from visualization_msgs.msg import Marker, MarkerArray
from builtin_interfaces.msg import Duration


# =============================================================================
# Robot State Machine
# =============================================================================

class RobotState(Enum):
    IDLE            = auto()   # Waiting for a task
    NAVIGATING      = auto()   # Moving toward goal pose
    EXECUTING       = auto()   # At goal, performing task action
    RETURNING       = auto()   # Returning to charging station
    CHARGING        = auto()   # Docked and recharging
    EMERGENCY_STOP  = auto()   # Obstacle too close / command received


# =============================================================================
# PID controller  (identical to robot1 — standalone, reusable)
# =============================================================================

class PIDController:
    """Minimal PID with anti-windup clamp."""

    def __init__(
        self,
        kp: float,
        ki: float,
        kd: float,
        output_min: float = -1.0,
        output_max: float =  1.0,
    ) -> None:
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.output_min = output_min
        self.output_max = output_max
        self._integral: float = 0.0
        self._prev_error: float = 0.0
        self._prev_time: Optional[float] = None

    def reset(self) -> None:
        self._integral = 0.0
        self._prev_error = 0.0
        self._prev_time = None

    def compute(self, error: float, current_time: float) -> float:
        if self._prev_time is None:
            dt = 0.05
        else:
            dt = max(current_time - self._prev_time, 1e-6)

        self._integral += error * dt
        derivative = (error - self._prev_error) / dt

        # Anti-windup: clamp integral contribution
        integral_max = (self.output_max - self.kp * error) / (self.ki + 1e-9)
        self._integral = max(-abs(integral_max), min(abs(integral_max), self._integral))

        output = (
            self.kp * error
            + self.ki * self._integral
            + self.kd * derivative
        )

        self._prev_error = error
        self._prev_time = current_time

        return max(self.output_min, min(self.output_max, output))


# =============================================================================
# Robot2Node
# =============================================================================

class Robot2Node(Node):
    """
    Full ROS2 lifecycle node for TurtleBot3 Robot-2.

    State machine transitions
    ─────────────────────────
    IDLE  ──(goal received)──►  NAVIGATING
    NAVIGATING  ──(goal reached)──►  EXECUTING
    NAVIGATING  ──(obstacle)──►  EMERGENCY_STOP
    EXECUTING  ──(task done)──►  IDLE  or  RETURNING
    RETURNING  ──(at charger)──►  CHARGING
    CHARGING  ──(battery full)──►  IDLE
    EMERGENCY_STOP  ──(clear)──►  NAVIGATING  or  IDLE
    any  ──(STOP command)──►  EMERGENCY_STOP
    """

    # Charging station pose for robot_2 (matches warehouse.world pad_2)
    CHARGING_X:   float = -8.0
    CHARGING_Y:   float = -1.0
    CHARGING_YAW: float =  0.0

    def __init__(self) -> None:
        super().__init__("robot2_node")

        # ── Parameters ────────────────────────────────────────────────────
        self.declare_parameter("robot_id",            2)
        self.declare_parameter("max_linear_vel",      0.22)
        self.declare_parameter("max_angular_vel",     2.84)
        self.declare_parameter("goal_tolerance",      0.10)
        self.declare_parameter("heading_tolerance",   0.08)
        self.declare_parameter("battery_drain_rate",  0.005)
        self.declare_parameter("low_battery_thresh",  20.0)
        self.declare_parameter("obstacle_threshold",  0.35)
        self.declare_parameter("collision_lookahead", 0.50)
        self.declare_parameter("use_sim_time",        True)
        self.declare_parameter("control_frequency",   20.0)

        self._robot_id          = self.get_parameter("robot_id").value
        self._max_linear_vel    = self.get_parameter("max_linear_vel").value
        self._max_angular_vel   = self.get_parameter("max_angular_vel").value
        self._goal_tolerance    = self.get_parameter("goal_tolerance").value
        self._heading_tolerance = self.get_parameter("heading_tolerance").value
        self._battery_drain     = self.get_parameter("battery_drain_rate").value
        self._low_battery_thr   = self.get_parameter("low_battery_thresh").value
        self._obstacle_thr      = self.get_parameter("obstacle_threshold").value
        self._lookahead         = self.get_parameter("collision_lookahead").value
        self._ctrl_freq         = self.get_parameter("control_frequency").value

        self.get_logger().info(
            f"[Robot {self._robot_id}] Node initialising "
            f"(max_v={self._max_linear_vel} m/s, "
            f"max_w={self._max_angular_vel} rad/s)"
        )

        # ── Internal state ─────────────────────────────────────────────────
        self._state: RobotState = RobotState.IDLE

        # Pose (updated from odometry) — seeded to charging pad_2
        self._x:   float = -8.0
        self._y:   float = -1.0
        self._yaw: float =  0.0

        # Navigation target
        self._goal_x:   Optional[float] = None
        self._goal_y:   Optional[float] = None
        self._goal_yaw: Optional[float] = None

        # Task metadata
        self._current_task_id:   Optional[str] = None
        self._task_action:       Optional[str] = None   # e.g. "PICKUP", "DROPOFF"
        self._task_duration:     float = 0.0            # seconds to simulate action
        self._task_start_time:   Optional[float] = None

        # Simulated battery.
        # Robot 2 starts at 85 % — staggers charge cycles across the fleet.
        # With a drain rate of 0.005 %/s × 2.0 (navigation multiplier), robot_2
        # will hit the 20 % low-battery threshold roughly 43 minutes before
        # robot_1 (which starts at 100 %) under continuous navigation load,
        # ensuring the fleet manager never has to send two robots to charge
        # simultaneously under normal warehouse duty cycles.
        self._battery_level:       float = 85.0
        self._last_battery_update: float = self.get_clock().now().nanoseconds * 1e-9

        # LiDAR state
        self._scan_ranges:    List[float] = []
        self._scan_angle_min: float = 0.0
        self._scan_angle_inc: float = 0.0
        self._obstacle_detected:  bool  = False
        self._obstacle_direction: float = 0.0   # rad

        # Heading / distance PIDs — same gains as robot_1 (TurtleBot3 Burger
        # inertia is identical across all three units in this fleet)
        self._pid_heading  = PIDController(
            kp=1.8, ki=0.0, kd=0.12,
            output_min=-self._max_angular_vel,
            output_max= self._max_angular_vel,
        )
        self._pid_distance = PIDController(
            kp=0.6, ki=0.0, kd=0.05,
            output_min=0.0,
            output_max=self._max_linear_vel,
        )

        # Velocity command smoothing (low-pass EMA)
        self._cmd_linear_smooth:  float = 0.0
        self._cmd_angular_smooth: float = 0.0
        self._smooth_alpha: float = 0.25   # blend factor (0=frozen, 1=raw)

        # Emergency stop recovery counter
        self._estop_clear_count:    int = 0
        self._estop_required_clear: int = 10   # consecutive clear cycles before resume

        # ── QoS profiles ──────────────────────────────────────────────────
        reliable_qos = QoSProfile(
            reliability=QoSReliabilityPolicy.RELIABLE,
            durability=QoSDurabilityPolicy.VOLATILE,
            depth=10,
        )

        # ── Subscribers ───────────────────────────────────────────────────
        self._sub_odom = self.create_subscription(
            Odometry,
            "odom",
            self._cb_odom,
            qos_profile_sensor_data,
        )
        self._sub_scan = self.create_subscription(
            LaserScan,
            "scan",
            self._cb_scan,
            qos_profile_sensor_data,
        )
        self._sub_imu = self.create_subscription(
            Imu,
            "imu",
            self._cb_imu,
            qos_profile_sensor_data,
        )
        # Fleet-manager topics are absolute (not namespaced) so the fleet
        # manager can address each robot individually from a single node.
        self._sub_goal = self.create_subscription(
            PoseStamped,
            "/fleet/robot_2/goal",
            self._cb_goal,
            reliable_qos,
        )
        self._sub_command = self.create_subscription(
            String,
            "/fleet/robot_2/command",
            self._cb_command,
            reliable_qos,
        )

        # ── Publishers ────────────────────────────────────────────────────
        self._pub_cmd_vel = self.create_publisher(
            Twist,
            "cmd_vel",
            10,
        )
        self._pub_status = self.create_publisher(
            # JSON-serialised RobotStatus placeholder — will be replaced
            # by the custom fleet_management/RobotStatus message once
            # CMakeLists.txt interface generation is complete.
            String,
            "/fleet/robot_2/status",
            reliable_qos,
        )
        self._pub_heartbeat = self.create_publisher(
            Header,
            "/fleet/robot_2/heartbeat",
            10,
        )
        self._pub_markers = self.create_publisher(
            MarkerArray,
            "path_markers",
            10,
        )

        # ── Timers ────────────────────────────────────────────────────────
        ctrl_period = 1.0 / self._ctrl_freq
        self._control_timer = self.create_timer(ctrl_period, self._control_loop)
        self._status_timer  = self.create_timer(0.5,         self._publish_status)
        self._hb_timer      = self.create_timer(1.0,         self._publish_heartbeat)
        self._battery_timer = self.create_timer(1.0,         self._update_battery)

        self.get_logger().info(
            f"[Robot {self._robot_id}] Initialisation complete. "
            f"State={self._state.name}, Battery={self._battery_level:.1f}%"
        )

    # =========================================================================
    # Subscriber callbacks
    # =========================================================================

    def _cb_odom(self, msg: Odometry) -> None:
        """Extract 2-D pose from odometry message."""
        self._x = msg.pose.pose.position.x
        self._y = msg.pose.pose.position.y
        self._yaw = self._quat_to_yaw(
            msg.pose.pose.orientation.x,
            msg.pose.pose.orientation.y,
            msg.pose.pose.orientation.z,
            msg.pose.pose.orientation.w,
        )

    def _cb_scan(self, msg: LaserScan) -> None:
        """
        Process LiDAR scan.
        Replaces inf/nan with max_range and checks for obstacles
        within the forward arc (±60°) at the configured threshold.
        """
        self._scan_angle_min = msg.angle_min
        self._scan_angle_inc = msg.angle_increment
        ranges = [
            r if (not math.isnan(r) and not math.isinf(r)) else msg.range_max
            for r in msg.ranges
        ]
        self._scan_ranges = ranges

        # Forward arc: ±60° = ±π/3
        arc_half = math.pi / 3.0
        obstacle_found = False
        min_dist  = float("inf")
        min_angle = 0.0

        for i, r in enumerate(ranges):
            angle = msg.angle_min + i * msg.angle_increment
            # Normalise angle to [-π, π]
            angle = math.atan2(math.sin(angle), math.cos(angle))
            if abs(angle) <= arc_half:
                if r < self._obstacle_thr:
                    obstacle_found = True
                    if r < min_dist:
                        min_dist  = r
                        min_angle = angle

        self._obstacle_detected  = obstacle_found
        self._obstacle_direction = min_angle if obstacle_found else 0.0

    def _cb_imu(self, msg: Imu) -> None:
        """IMU callback — reserved for tilt / fall detection (future use)."""
        pass

    def _cb_goal(self, msg: PoseStamped) -> None:
        """
        Receive a navigation goal from the fleet manager.
        Transitions the robot from IDLE (or CHARGING) → NAVIGATING.
        Goals received during EMERGENCY_STOP are rejected; the fleet manager
        must issue RESUME or CANCEL first.
        """
        if self._state in (RobotState.EMERGENCY_STOP,):
            self.get_logger().warn(
                f"[Robot {self._robot_id}] Goal received but in EMERGENCY_STOP — ignoring."
            )
            return

        self._goal_x   = msg.pose.position.x
        self._goal_y   = msg.pose.position.y
        self._goal_yaw = self._quat_to_yaw(
            msg.pose.orientation.x,
            msg.pose.orientation.y,
            msg.pose.orientation.z,
            msg.pose.orientation.w,
        )

        self._pid_heading.reset()
        self._pid_distance.reset()

        self.get_logger().info(
            f"[Robot {self._robot_id}] New goal received: "
            f"({self._goal_x:.2f}, {self._goal_y:.2f}, yaw={self._goal_yaw:.2f}). "
            f"State: {self._state.name} → NAVIGATING"
        )
        self._set_state(RobotState.NAVIGATING)

    def _cb_command(self, msg: String) -> None:
        """
        Process fleet manager commands.
        Recognised commands: STOP, CANCEL, RESUME, RETURN_TO_CHARGE
        """
        cmd = msg.data.strip().upper()
        self.get_logger().info(
            f"[Robot {self._robot_id}] Command received: {cmd}"
        )

        if cmd == "STOP":
            self._stop_motors()
            self._set_state(RobotState.EMERGENCY_STOP)

        elif cmd == "CANCEL":
            self._stop_motors()
            self._clear_goal()
            self._set_state(RobotState.IDLE)

        elif cmd == "RESUME":
            if self._goal_x is not None:
                self._pid_heading.reset()
                self._pid_distance.reset()
                self._set_state(RobotState.NAVIGATING)
            else:
                self._set_state(RobotState.IDLE)

        elif cmd == "RETURN_TO_CHARGE":
            self._set_goal(self.CHARGING_X, self.CHARGING_Y, self.CHARGING_YAW)
            self._set_state(RobotState.RETURNING)

        else:
            self.get_logger().warn(
                f"[Robot {self._robot_id}] Unknown command: {cmd}"
            )

    # =========================================================================
    # Control loop  (runs at self._ctrl_freq Hz)
    # =========================================================================

    def _control_loop(self) -> None:
        """
        Main state-machine tick.  Called at control frequency (default 20 Hz).
        Dispatches to per-state handler.
        """
        now = self.get_clock().now().nanoseconds * 1e-9

        if self._state == RobotState.IDLE:
            self._handle_idle()

        elif self._state == RobotState.NAVIGATING:
            self._handle_navigating(now)

        elif self._state == RobotState.EXECUTING:
            self._handle_executing(now)

        elif self._state == RobotState.RETURNING:
            self._handle_returning(now)

        elif self._state == RobotState.CHARGING:
            self._handle_charging()

        elif self._state == RobotState.EMERGENCY_STOP:
            self._handle_emergency_stop()

    # ── State handlers ────────────────────────────────────────────────────

    def _handle_idle(self) -> None:
        """Nothing to do; ensure motors are stopped."""
        self._stop_motors()

    def _handle_navigating(self, now: float) -> None:
        """
        Navigate toward self._goal_x/y using a two-phase controller:
          Phase 1 – rotate in place to face the goal  (heading error > ~23°)
          Phase 2 – drive straight while correcting heading drift
        Transitions to EXECUTING when within goal_tolerance.
        Transitions to EMERGENCY_STOP on obstacle detection.
        """
        if self._goal_x is None:
            self._set_state(RobotState.IDLE)
            return

        # ── Obstacle check ─────────────────────────────────────────────
        if self._obstacle_detected:
            self._estop_clear_count = 0
            self._stop_motors()
            self.get_logger().warn(
                f"[Robot {self._robot_id}] Obstacle detected! "
                f"Direction={math.degrees(self._obstacle_direction):.1f}°. "
                f"Entering EMERGENCY_STOP."
            )
            self._set_state(RobotState.EMERGENCY_STOP)
            return

        # ── Distance and heading to goal ───────────────────────────────
        dx   = self._goal_x - self._x
        dy   = self._goal_y - self._y
        dist = math.hypot(dx, dy)

        if dist <= self._goal_tolerance:
            # Position reached — align to final heading if specified
            if self._goal_yaw is not None:
                heading_err = self._normalise_angle(self._goal_yaw - self._yaw)
                if abs(heading_err) > self._heading_tolerance:
                    # Spin in place to final yaw
                    w = self._pid_heading.compute(heading_err, now)
                    self._publish_vel(0.0, w)
                    return

            # Goal fully reached
            self.get_logger().info(
                f"[Robot {self._robot_id}] Goal reached "
                f"({self._goal_x:.2f}, {self._goal_y:.2f}). "
                f"State → EXECUTING"
            )
            self._stop_motors()
            self._task_start_time = now
            self._set_state(RobotState.EXECUTING)
            return

        # ── Phase 1 / 2 controller ─────────────────────────────────────
        desired_heading = math.atan2(dy, dx)
        heading_err     = self._normalise_angle(desired_heading - self._yaw)

        # Phase 1: rotate in place when heading error is large (> ~23°)
        if abs(heading_err) > 0.4:
            w = self._pid_heading.compute(heading_err, now)
            self._publish_vel(0.0, w)
        else:
            # Phase 2: drive forward + correct heading drift
            v = self._pid_distance.compute(dist, now)
            w = self._pid_heading.compute(heading_err, now)
            # Velocity ramp-down within 0.5 m of goal to avoid overshoot
            v = min(v, self._max_linear_vel * min(1.0, dist / 0.5))
            self._publish_vel(v, w)

    def _handle_executing(self, now: float) -> None:
        """
        Simulate task execution (PICKUP / DROPOFF / INSPECT).
        Holds position for self._task_duration seconds (minimum 2 s dwell),
        then transitions to IDLE or RETURNING based on battery level.
        """
        self._stop_motors()

        if self._task_start_time is None:
            self._task_start_time = now

        elapsed = now - self._task_start_time

        if elapsed >= max(self._task_duration, 2.0):  # minimum 2 s dwell
            self.get_logger().info(
                f"[Robot {self._robot_id}] Task '{self._task_action}' "
                f"(id={self._current_task_id}) complete after {elapsed:.1f}s."
            )
            self._current_task_id = None
            self._task_action     = None
            self._task_start_time = None
            self._clear_goal()

            if self._battery_level <= self._low_battery_thr:
                self.get_logger().info(
                    f"[Robot {self._robot_id}] Low battery ({self._battery_level:.1f}%). "
                    f"Returning to charger."
                )
                self._set_goal(self.CHARGING_X, self.CHARGING_Y, self.CHARGING_YAW)
                self._set_state(RobotState.RETURNING)
            else:
                self._set_state(RobotState.IDLE)

    def _handle_returning(self, now: float) -> None:
        """
        Re-use the navigation logic to drive back to charging pad_2.
        Intercepts the NAVIGATING → EXECUTING transition and redirects
        to CHARGING so no code is duplicated.
        """
        self._handle_navigating(now)
        # The navigation handler sets EXECUTING when it arrives at the target.
        # Override that here: arriving at the charging pad means → CHARGING.
        if self._state == RobotState.EXECUTING:
            self.get_logger().info(
                f"[Robot {self._robot_id}] Docked at charging pad. "
                f"State → CHARGING"
            )
            self._stop_motors()
            self._clear_goal()
            self._set_state(RobotState.CHARGING)

    def _handle_charging(self) -> None:
        """
        Simulate battery charging at 0.1 %/s.
        Transitions to IDLE once battery reaches 95 %.
        """
        self._stop_motors()
        self._battery_level = min(100.0, self._battery_level + 0.1)
        if self._battery_level >= 95.0:
            self.get_logger().info(
                f"[Robot {self._robot_id}] Charging complete "
                f"({self._battery_level:.1f}%). State → IDLE"
            )
            self._set_state(RobotState.IDLE)

    def _handle_emergency_stop(self) -> None:
        """
        Hold motors stopped.  When the forward arc is clear for
        _estop_required_clear consecutive cycles (~0.5 s at 20 Hz),
        auto-resume NAVIGATING (if a goal is pending) or revert to IDLE.
        """
        self._stop_motors()

        if not self._obstacle_detected:
            self._estop_clear_count += 1
        else:
            self._estop_clear_count = 0

        if self._estop_clear_count >= self._estop_required_clear:
            self._estop_clear_count = 0
            if self._goal_x is not None:
                self.get_logger().info(
                    f"[Robot {self._robot_id}] Obstacle cleared. "
                    f"Resuming NAVIGATING."
                )
                self._pid_heading.reset()
                self._pid_distance.reset()
                self._set_state(RobotState.NAVIGATING)
            else:
                self._set_state(RobotState.IDLE)

    # =========================================================================
    # Periodic publishers
    # =========================================================================

    def _publish_status(self) -> None:
        """
        Publish robot status as a JSON string over /fleet/robot_2/status.
        Will be replaced by the custom fleet_management/RobotStatus message
        once CMakeLists.txt and interface generation are complete.
        """
        import json
        status = {
            "robot_id":    self._robot_id,
            "state":       self._state.name,
            "x":           round(self._x, 3),
            "y":           round(self._y, 3),
            "yaw":         round(self._yaw, 3),
            "battery":     round(self._battery_level, 2),
            "task_id":     self._current_task_id,
            "task_action": self._task_action,
            "obstacle":    self._obstacle_detected,
            "goal_x":      self._goal_x,
            "goal_y":      self._goal_y,
            "timestamp":   self.get_clock().now().nanoseconds,
        }
        msg = String()
        msg.data = json.dumps(status)
        self._pub_status.publish(msg)

    def _publish_heartbeat(self) -> None:
        """Publish a timestamped header so the fleet manager can track liveness."""
        hb = Header()
        hb.stamp    = self.get_clock().now().to_msg()
        hb.frame_id = f"robot_{self._robot_id}"
        self._pub_heartbeat.publish(hb)

    def _publish_goal_marker(self) -> None:
        """
        Visualise current goal in RViz as a blue sphere.
        Colour differentiates robot_2 from robot_1 (green) and robot_3 (orange)
        in the shared multi-robot RViz view.
        """
        if self._goal_x is None:
            return

        marker = Marker()
        marker.header.frame_id    = "world"
        marker.header.stamp       = self.get_clock().now().to_msg()
        marker.ns                 = f"robot_{self._robot_id}_goal"
        marker.id                 = self._robot_id
        marker.type               = Marker.SPHERE
        marker.action             = Marker.ADD
        marker.pose.position.x    = self._goal_x
        marker.pose.position.y    = self._goal_y
        marker.pose.position.z    = 0.15
        marker.pose.orientation.w = 1.0
        marker.scale.x = marker.scale.y = marker.scale.z = 0.2
        # Blue: visually distinct from robot_1 (green) and robot_3 (orange)
        marker.color.r = 0.18
        marker.color.g = 0.52
        marker.color.b = 1.0
        marker.color.a = 0.8

        arr = MarkerArray()
        arr.markers.append(marker)
        self._pub_markers.publish(arr)

    # =========================================================================
    # Battery simulation
    # =========================================================================

    def _update_battery(self) -> None:
        """
        Drain battery when moving, hold steady when idle/charging.
        Drain rates:
          NAVIGATING / RETURNING : 2.0× base  (motors under full load)
          EXECUTING              : 0.5× base  (stationary, actuator only)
          IDLE / EMERGENCY_STOP  : 0.1× base  (standby electronics)
        """
        if self._state == RobotState.CHARGING:
            return  # Charging handled in _handle_charging

        now = self.get_clock().now().nanoseconds * 1e-9
        dt  = now - self._last_battery_update
        self._last_battery_update = now

        if self._state in (RobotState.NAVIGATING, RobotState.RETURNING):
            drain = self._battery_drain * dt * 2.0
        elif self._state == RobotState.EXECUTING:
            drain = self._battery_drain * dt * 0.5
        else:
            drain = self._battery_drain * dt * 0.1

        self._battery_level = max(0.0, self._battery_level - drain)

        # Critical battery: force immediate return to charger
        if self._battery_level <= 5.0 and self._state not in (
            RobotState.RETURNING, RobotState.CHARGING, RobotState.EMERGENCY_STOP
        ):
            self.get_logger().error(
                f"[Robot {self._robot_id}] CRITICAL BATTERY {self._battery_level:.1f}%. "
                f"Forcing return to charger."
            )
            self._set_goal(self.CHARGING_X, self.CHARGING_Y, self.CHARGING_YAW)
            self._set_state(RobotState.RETURNING)

    # =========================================================================
    # Velocity publishing with smoothing
    # =========================================================================

    def _publish_vel(self, linear: float, angular: float) -> None:
        """
        Apply low-pass EMA smoothing to velocity commands before publishing.
        Clamps to hardware limits and publishes on ~/cmd_vel.
        """
        linear  = max(-self._max_linear_vel,  min(self._max_linear_vel,  linear))
        angular = max(-self._max_angular_vel, min(self._max_angular_vel, angular))

        # Exponential moving average
        a = self._smooth_alpha
        self._cmd_linear_smooth  = a * linear  + (1 - a) * self._cmd_linear_smooth
        self._cmd_angular_smooth = a * angular + (1 - a) * self._cmd_angular_smooth

        twist = Twist()
        twist.linear.x  = self._cmd_linear_smooth
        twist.angular.z = self._cmd_angular_smooth
        self._pub_cmd_vel.publish(twist)

    def _stop_motors(self) -> None:
        """Publish zero velocity and reset smoothing state."""
        self._cmd_linear_smooth  = 0.0
        self._cmd_angular_smooth = 0.0
        twist = Twist()
        self._pub_cmd_vel.publish(twist)

    # =========================================================================
    # State and goal helpers
    # =========================================================================

    def _set_state(self, new_state: RobotState) -> None:
        if new_state != self._state:
            self.get_logger().info(
                f"[Robot {self._robot_id}] State: {self._state.name} → {new_state.name}"
            )
            self._state = new_state

    def _set_goal(self, x: float, y: float, yaw: float) -> None:
        self._goal_x   = x
        self._goal_y   = y
        self._goal_yaw = yaw
        self._pid_heading.reset()
        self._pid_distance.reset()

    def _clear_goal(self) -> None:
        self._goal_x   = None
        self._goal_y   = None
        self._goal_yaw = None

    # =========================================================================
    # Utility
    # =========================================================================

    @staticmethod
    def _quat_to_yaw(qx: float, qy: float, qz: float, qw: float) -> float:
        """Convert quaternion to yaw angle (radians)."""
        siny_cosp = 2.0 * (qw * qz + qx * qy)
        cosy_cosp = 1.0 - 2.0 * (qy * qy + qz * qz)
        return math.atan2(siny_cosp, cosy_cosp)

    @staticmethod
    def _normalise_angle(angle: float) -> float:
        """Wrap angle to [-π, π]."""
        return math.atan2(math.sin(angle), math.cos(angle))


# =============================================================================
# Entry point
# =============================================================================

def main(args=None) -> None:
    rclpy.init(args=args)
    node = Robot2Node()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info(f"[Robot 2] Shutting down.")
    finally:
        node._stop_motors()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
