# Fleet Management System

## Overview

Fleet Management System is a ROS 2-based multi-robot warehouse automation platform designed to:

- Simulate multiple autonomous mobile robots
- Perform centralized fleet management
- Allocate tasks dynamically
- Plan paths using the A* algorithm
- Prevent robot collisions using traffic management
- Visualize robot activity through a web dashboard
- Support warehouse simulation using RViz and Gazebo

---

## Project Structure

```text
fleet_management_system/

simulation/
│   warehouse.world
│   multi_robot.launch.py
│   warehouse.rviz

robots/
│   robot1.py
│   robot2.py
│   robot3.py

fleet_manager/
│   fleet_manager.py
│   robot_registry.py
│   task_allocator.py

navigation/
│   astar_planner.py
│   path_utils.py

traffic_manager/
│   collision_manager.py
│   reservation_table.py

dashboard/
│   app.py
│   data_provider.py

config/
│   robots.yaml

utils/
│   helper.py
│   logger.py

requirements.txt
README.md
```

---

## Features

### Multi-Robot Simulation
- Simulates multiple warehouse robots.
- Launches robots in a shared environment.
- RViz visualization support.

### Fleet Management
- Robot registration and monitoring.
- Fleet-wide task distribution.
- Robot status tracking.

### Task Allocation
- Dynamic assignment of tasks.
- Robot availability management.
- Load balancing across robots.

### Navigation
- A* path planning.
- Path optimization utilities.
- Route generation between warehouse locations.

### Traffic Management
- Collision detection.
- Path reservation mechanism.
- Deadlock prevention strategies.

### Dashboard
- Real-time fleet monitoring.
- Robot status visualization.
- Task and performance analytics.

---

## Components

### simulation/

| File | Description |
|--------|------------|
| warehouse.world | Warehouse simulation environment |
| multi_robot.launch.py | Launches all robots and services |
| warehouse.rviz | RViz visualization configuration |

### robots/

| File | Description |
|--------|------------|
| robot1.py | Robot 1 controller |
| robot2.py | Robot 2 controller |
| robot3.py | Robot 3 controller |

### fleet_manager/

| File | Description |
|--------|------------|
| fleet_manager.py | Main fleet management node |
| robot_registry.py | Robot registration and tracking |
| task_allocator.py | Task assignment engine |

### navigation/

| File | Description |
|--------|------------|
| astar_planner.py | A* path planning implementation |
| path_utils.py | Path utility functions |

### traffic_manager/

| File | Description |
|--------|------------|
| collision_manager.py | Collision avoidance system |
| reservation_table.py | Path reservation management |

### dashboard/

| File | Description |
|--------|------------|
| app.py | Dashboard web application |
| data_provider.py | Dashboard data source layer |

### config/

| File | Description |
|--------|------------|
| robots.yaml | Robot configuration parameters |

### utils/

| File | Description |
|--------|------------|
| helper.py | Common utility functions |
| logger.py | Logging utilities |

---

## Installation

### Clone Repository

```bash
git clone <repository-url>
cd fleet_management_system
```

### Create Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate
```

### Install Dependencies

```bash
pip install -r requirements.txt
```

---

## Running the System

### Launch Simulation

```bash
ros2 launch simulation multi_robot.launch.py
```

### Start Fleet Manager

```bash
python fleet_manager/fleet_manager.py
```

### Start Dashboard

```bash
python dashboard/app.py
```

---

## Configuration

Robot parameters are defined in:

```text
config/robots.yaml
```

Example:

```yaml
robots:
  - id: robot1
    start_position: [0, 0]

  - id: robot2
    start_position: [5, 0]

  - id: robot3
    start_position: [10, 0]
```

---

## Future Enhancements

- Dynamic obstacle avoidance
- Battery-aware task allocation
- Multi-floor warehouse support
- MQTT integration
- Database persistence
- AI-based task scheduling
- ROS 2 Nav2 integration

---

## Technology Stack

- ROS 2 Humble
- Python 3.10+
- Flask Dashboard
- RViz
- Gazebo
- NetworkX
- NumPy
- Pandas

---

## License

This project is released under the MIT License.
