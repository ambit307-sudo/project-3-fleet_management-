# utils/logger.py

import logging
import os
from datetime import datetime


class FleetLogger:
    """
    Centralized logger for Fleet Management System.
    """

    LOG_DIR = "logs"

    def __init__(self, logger_name="FleetManager"):
        self.logger_name = logger_name

        if not os.path.exists(self.LOG_DIR):
            os.makedirs(self.LOG_DIR)

        log_file = os.path.join(
            self.LOG_DIR,
            f"fleet_{datetime.now().strftime('%Y%m%d')}.log"
        )

        self.logger = logging.getLogger(logger_name)

        if not self.logger.handlers:
            self.logger.setLevel(logging.INFO)

            formatter = logging.Formatter(
                "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s"
            )

            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(formatter)

            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)

            self.logger.addHandler(file_handler)
            self.logger.addHandler(console_handler)

    def info(self, message):
        self.logger.info(message)

    def warning(self, message):
        self.logger.warning(message)

    def error(self, message):
        self.logger.error(message)

    def critical(self, message):
        self.logger.critical(message)

    def debug(self, message):
        self.logger.debug(message)

    def robot_registered(self, robot_id):
        self.info(f"Robot Registered -> {robot_id}")

    def robot_status_changed(self, robot_id, status):
        self.info(f"Robot {robot_id} status changed to {status}")

    def robot_position_updated(self, robot_id, position):
        self.info(f"Robot {robot_id} moved to {position}")

    def battery_low(self, robot_id, battery_level):
        self.warning(
            f"Robot {robot_id} battery low ({battery_level}%)"
        )

    def task_created(self, task_id):
        self.info(f"Task Created -> {task_id}")

    def task_assigned(self, task_id, robot_id):
        self.info(f"Task {task_id} assigned to {robot_id}")

    def task_completed(self, task_id, robot_id):
        self.info(f"Task {task_id} completed by {robot_id}")

    def path_generated(self, robot_id, path_length):
        self.info(
            f"Path generated for {robot_id} (Length: {path_length})"
        )

    def destination_reached(self, robot_id, destination):
        self.info(f"{robot_id} reached {destination}")

    def reservation_created(self, reservation_id, robot_id):
        self.info(
            f"Reservation {reservation_id} created for {robot_id}"
        )

    def reservation_released(self, reservation_id):
        self.info(f"Reservation released -> {reservation_id}")

    def collision_warning(self, robot1, robot2):
        self.warning(
            f"Potential collision detected between {robot1} and {robot2}"
        )

    def system_started(self):
        self.info("Fleet Management System Started")

    def system_shutdown(self):
        self.info("Fleet Management System Shutdown")

    def dashboard_accessed(self):
        self.info("Dashboard accessed")


logger = FleetLogger()
