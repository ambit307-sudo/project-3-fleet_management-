#!/usr/bin/env python3
# =============================================================================
# fleet_manager/task_allocator.py
# =============================================================================
# Weighted multi-criteria task allocator for the Fleet Management System.
#
# Responsibilities
# ----------------
#   • Maintain a priority queue of pending Task objects.
#   • On each allocation tick (called by FleetManagerNode timer), attempt to
#     assign queued tasks to available robots using a weighted scoring model:
#
#       score(robot, task) = w_dist     * norm_distance_score(robot, task)
#                          + w_battery  * norm_battery_score(robot)
#                          + w_load     * norm_load_score(robot)
#
#     The robot with the HIGHEST score wins the task.
#
#   • Publish a PoseStamped goal to /fleet/robot_<id>/goal and a JSON command
#     to /fleet/robot_<id>/task so the robot node starts navigating.
#   • Track in-flight tasks and detect timeouts (task_timeout parameter from
#     multi_robot.launch.py, default 30 s).  On timeout the task is re-queued
#     and a CANCEL command is sent to the offending robot.
#   • Expose add_task(), cancel_task(), and queue_snapshot() for the
#     FleetManagerNode and the optional dashboard REST bridge.
#
# Scoring model detail
# --------------------
# distance score  — inverse of Euclidean distance from robot to task goal,
#                   normalised across all candidates.  A robot sitting on top
#                   of the goal scores 1.0; the furthest robot scores 0.0.
# battery score   — raw battery% / 100, so a fully-charged robot gets full
#                   credit.  Robots below low_battery_threshold are already
#                   excluded by RobotRegistry.available_robots().
# load score      — inverse of tasks_completed count, normalised so the robot
#                   that has done the fewest tasks scores 1.0.  Breaks ties in
#                   favour of the least-used robot, giving even wear across the
#                   fleet over a long run.
#
# Default weights (tunable via ROS2 parameters):
#   w_dist    = 0.50   — distance dominates (warehouse is small)
#   w_battery = 0.30   — prefer higher-charge robots for longer tasks
#   w_load    = 0.20   — light load-balancing to spread wear
#
# Integration
# -----------
# TaskAllocator is NOT a ROS2 node.  It is instantiated once inside
# FleetManagerNode.__init__ and receives the node's publishers and registry
# reference.  Only the allocation tick and re-queue logic interact with ROS.
#
# Wiring example in fleet_manager.py:
#
#   from fleet_manager.task_allocator import TaskAllocator, Task, TaskPriority
#
#   self._allocator = TaskAllocator(
#       registry        = self._registry,
#       goal_publishers = self._goal_pubs,   # dict[int, Publisher]
#       task_publishers = self._task_pubs,   # dict[int, Publisher]
#       cmd_publishers  = self._cmd_pubs,    # dict[int, Publisher]
#       node_logger     = self.get_logger(),
#       task_timeout    = 30.0,
#       dispatch_pose   = (-4.0, -8.5, 0.0),
#       receiving_pose  = ( 4.0, -8.5, 0.0),
#       w_dist          = 0.50,
#       w_battery       = 0.30,
#       w_load          = 0.20,
#   )
#
#   # In a 1 Hz timer callback:
#   self._allocator.tick()
#
#   # To enqueue a new task from an external service call:
#   from fleet_manager.task_allocator import Task, TaskPriority
#   task = Task(
#       task_id   = "pick_A14",
#       action    = "PICK",
#       goal_x    = 2.0,
#       goal_y    = 3.5,
#       goal_yaw  = 0.0,
#       priority  = TaskPriority.NORMAL,
#   )
#   self._allocator.add_task(task)
#
# Task lifecycle
# --------------
#   PENDING  ──(robot assigned)──►  IN_FLIGHT
#   IN_FLIGHT──(robot IDLE, task_id cleared)──►  DONE  (detected in tick)
#   IN_FLIGHT──(timeout)──►  PENDING  (re-queued with priority boost)
#   PENDING  ──(cancel_task called)──►  CANCELLED
#   IN_FLIGHT──(cancel_task called)──►  CANCELLED  (CANCEL sent to robot)
#
# Topic contracts (mirrors robot1/2/3.py)
# ----------------------------------------
#   /fleet/robot_<id>/goal    geometry_msgs/PoseStamped
#   /fleet/robot_<id>/task    std_msgs/String  (JSON — see _build_task_json)
#   /fleet/robot_<id>/command std_msgs/String  ("CANCEL" | "STOP")
# =============================================================================

from __future__ import annotations

import json
import math
import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable, Dict, List, Optional, Tuple

# ROS2 message types — imported lazily so unit tests can import this module
# without a full ROS2 install.
try:
    from geometry_msgs.msg import PoseStamped, Quaternion
    from std_msgs.msg import String
    _ROS_AVAILABLE = True
except ImportError:
    _ROS_AVAILABLE = False

from fleet_manager.robot_registry import RobotRegistry, RobotRecord, RobotState


# =============================================================================
# Task priority
# =============================================================================

class TaskPriority(int, Enum):
    """
    Higher value = higher priority.  The queue is ordered by (priority desc,
    enqueue_time asc) so urgent tasks jump the queue but FIFO order is
    preserved within the same priority tier.
    """
    LOW    = 1
    NORMAL = 2
    HIGH   = 3
    URGENT = 4


# =============================================================================
# Task status
# =============================================================================

class TaskStatus(str, Enum):
    PENDING   = "PENDING"
    IN_FLIGHT = "IN_FLIGHT"
    DONE      = "DONE"
    CANCELLED = "CANCELLED"
    TIMED_OUT = "TIMED_OUT"    # transient — re-queued immediately as PENDING


# =============================================================================
# Task dataclass
# =============================================================================

@dataclass
class Task:
    """
    Describes a single unit of warehouse work dispatched to a robot.

    Fields
    ------
    task_id
        Unique identifier.  If not supplied a UUID4 is generated.
    action
        String label for the task (e.g. "PICK", "PLACE", "MOVE_TO",
        "CHARGE").  Forwarded verbatim to the robot node via the task topic.
    goal_x, goal_y, goal_yaw
        Target pose in the world frame.  Must match warehouse.world coordinates.
    priority
        TaskPriority enum value.  Higher priorities are allocated first.
    payload
        Optional free-form dict (shelf ID, package label, etc.) forwarded to
        the robot as additional JSON context.
    """

    action:   str
    goal_x:   float
    goal_y:   float
    goal_yaw: float = 0.0

    task_id:  str          = field(default_factory=lambda: str(uuid.uuid4())[:8])
    priority: TaskPriority = TaskPriority.NORMAL
    payload:  Dict         = field(default_factory=dict)

    # ── Managed by TaskAllocator — do not set externally ──────────────────
    status:        TaskStatus    = field(default=TaskStatus.PENDING,   init=False)
    assigned_robot: Optional[int] = field(default=None,               init=False)
    enqueue_time:  float         = field(default_factory=time.monotonic, init=False)
    dispatch_time: float         = field(default=0.0,                 init=False)
    done_time:     float         = field(default=0.0,                 init=False)
    retry_count:   int           = field(default=0,                   init=False)

    # ── Sortable — lower tuple value = higher queue priority ──────────────
    def queue_key(self) -> Tuple:
        """
        Sort key for the pending queue.
        Primary  : priority descending (negate to use min-heap semantics).
        Secondary: enqueue_time ascending (FIFO within same priority).
        """
        return (-self.priority.value, self.enqueue_time)

    def as_dict(self) -> dict:
        return {
            "task_id":        self.task_id,
            "action":         self.action,
            "goal_x":         round(self.goal_x,   3),
            "goal_y":         round(self.goal_y,   3),
            "goal_yaw":       round(self.goal_yaw, 3),
            "priority":       self.priority.name,
            "status":         self.status.value,
            "assigned_robot": self.assigned_robot,
            "retry_count":    self.retry_count,
            "payload":        self.payload,
        }


# =============================================================================
# TaskAllocator
# =============================================================================

class TaskAllocator:
    """
    Weighted multi-criteria task dispatcher for the warehouse fleet.

    Thread-safety
    -------------
    All public methods acquire ``self._lock`` (a reentrant lock).
    ``tick()`` is typically called from a single ROS2 timer thread, but
    ``add_task()``, ``cancel_task()``, and ``queue_snapshot()`` may be
    called from the dashboard REST-bridge thread concurrently.
    """

    # ── Scoring weight defaults ────────────────────────────────────────────
    _DEFAULT_W_DIST    = 0.50
    _DEFAULT_W_BATTERY = 0.30
    _DEFAULT_W_LOAD    = 0.20

    def __init__(
        self,
        registry:        RobotRegistry,
        goal_publishers: Dict,          # {robot_id: rclpy Publisher<PoseStamped>}
        task_publishers: Dict,          # {robot_id: rclpy Publisher<String>}
        cmd_publishers:  Dict,          # {robot_id: rclpy Publisher<String>}
        node_logger,                    # rclpy Logger from the fleet manager node
        task_timeout:    float = 30.0,
        dispatch_pose:   Tuple = (-4.0, -8.5, 0.0),
        receiving_pose:  Tuple = ( 4.0, -8.5, 0.0),
        w_dist:    float = _DEFAULT_W_DIST,
        w_battery: float = _DEFAULT_W_BATTERY,
        w_load:    float = _DEFAULT_W_LOAD,
        clock_fn:  Callable[[], float] = time.monotonic,
    ) -> None:
        """
        Parameters
        ----------
        registry
            Shared RobotRegistry instance (single source of truth for robot state).
        goal_publishers
            Mapping from robot_id → rclpy Publisher for PoseStamped goals.
        task_publishers
            Mapping from robot_id → rclpy Publisher for JSON task strings.
        cmd_publishers
            Mapping from robot_id → rclpy Publisher for command strings
            ("CANCEL", "STOP").
        node_logger
            The fleet manager node's logger (``self.get_logger()``).
        task_timeout
            Seconds after dispatch before an IN_FLIGHT task is considered
            timed out and re-queued.  Matches ``task_timeout`` in
            multi_robot.launch.py (default 30 s).
        dispatch_pose
            (x, y, yaw) of the dispatch station.  Provided as a convenience
            constant for callers creating PICK tasks.
        receiving_pose
            (x, y, yaw) of the receiving station.  Convenience constant for
            PLACE tasks.
        w_dist, w_battery, w_load
            Scoring weights.  Must sum to 1.0 (enforced in __init__).
        clock_fn
            Injected clock for unit-testing without real wall time.
        """
        self._registry        = registry
        self._goal_pubs       = goal_publishers
        self._task_pubs       = task_publishers
        self._cmd_pubs        = cmd_publishers
        self._log             = node_logger
        self._task_timeout    = task_timeout
        self._dispatch_pose   = dispatch_pose
        self._receiving_pose  = receiving_pose
        self._clock           = clock_fn

        # Validate and normalise weights
        total = w_dist + w_battery + w_load
        if abs(total - 1.0) > 1e-6:
            self._log.warning(
                f"[TaskAllocator] Weights ({w_dist}, {w_battery}, {w_load}) "
                f"sum to {total:.4f}, not 1.0 — normalising."
            )
            w_dist    /= total
            w_battery /= total
            w_load    /= total
        self._w_dist    = w_dist
        self._w_battery = w_battery
        self._w_load    = w_load

        # ── Data structures ────────────────────────────────────────────────
        # Pending queue: sorted list of Task objects (re-sorted on insert).
        self._pending:   List[Task]        = []
        # In-flight registry: task_id → Task
        self._in_flight: Dict[str, Task]   = {}
        # Historical archive: task_id → Task  (DONE / CANCELLED / TIMED_OUT)
        self._archive:   Dict[str, Task]   = {}

        # Lock guards _pending, _in_flight, and _archive
        self._lock = threading.RLock()

        # Allocation-cycle statistics (not locked — single-writer from tick())
        self._ticks_total:     int = 0
        self._tasks_dispatched: int = 0
        self._tasks_timed_out: int = 0
        self._tasks_cancelled: int = 0
        self._tasks_completed: int = 0

        self._log.info(
            f"[TaskAllocator] Initialised  "
            f"w_dist={self._w_dist:.2f}  "
            f"w_battery={self._w_battery:.2f}  "
            f"w_load={self._w_load:.2f}  "
            f"timeout={self._task_timeout}s"
        )

    # =========================================================================
    # Public interface
    # =========================================================================

    def add_task(self, task: Task) -> str:
        """
        Enqueue a new task.  Returns task_id for caller reference.

        Thread-safe: may be called from the dashboard REST-bridge thread.
        """
        with self._lock:
            task.status       = TaskStatus.PENDING
            task.enqueue_time = self._clock()
            self._pending.append(task)
            self._pending.sort(key=lambda t: t.queue_key())

        self._log.info(
            f"[TaskAllocator] Enqueued task {task.task_id}  "
            f"action={task.action}  goal=({task.goal_x:.2f}, {task.goal_y:.2f})  "
            f"priority={task.priority.name}"
        )
        return task.task_id

    def cancel_task(self, task_id: str) -> bool:
        """
        Cancel a task by ID whether it is PENDING or IN_FLIGHT.

        For IN_FLIGHT tasks a CANCEL command is sent to the assigned robot so
        it can stop navigating and return to IDLE.

        Returns True if the task was found and cancelled, False otherwise.
        """
        with self._lock:
            # Search pending queue first
            for i, task in enumerate(self._pending):
                if task.task_id == task_id:
                    task.status   = TaskStatus.CANCELLED
                    task.done_time = self._clock()
                    self._pending.pop(i)
                    self._archive[task_id] = task
                    self._tasks_cancelled += 1
                    self._log.info(
                        f"[TaskAllocator] Cancelled PENDING task {task_id}"
                    )
                    return True

            # Search in-flight
            task = self._in_flight.get(task_id)
            if task is not None:
                task.status    = TaskStatus.CANCELLED
                task.done_time = self._clock()
                robot_id       = task.assigned_robot
                del self._in_flight[task_id]
                self._archive[task_id] = task
                self._tasks_cancelled += 1

        # Send CANCEL outside the lock to avoid holding it during I/O
        if task is not None and robot_id is not None:
            self._send_command(robot_id, "CANCEL")
            self._log.info(
                f"[TaskAllocator] Cancelled IN_FLIGHT task {task_id} "
                f"on robot_{robot_id}  → CANCEL command sent"
            )
        return task is not None

    def tick(self) -> None:
        """
        Main allocation cycle — call from a ROS2 timer at 1 Hz or faster.

        Steps
        -----
        1. Detect completed tasks (robot returned to IDLE with cleared task_id).
        2. Detect timed-out tasks and re-queue them with a priority boost.
        3. Attempt to assign each pending task (highest priority first) to the
           best-scoring available robot.
        """
        self._ticks_total += 1
        self._check_completions()
        self._check_timeouts()
        self._assign_pending()

    def queue_snapshot(self) -> dict:
        """
        Return a serialisable snapshot of all queues for the dashboard.

        Keys
        ----
        pending       list[dict]   — tasks waiting for a robot
        in_flight     list[dict]   — tasks currently being executed
        stats         dict         — allocation cycle counters
        """
        with self._lock:
            pending_snap   = [t.as_dict() for t in self._pending]
            in_flight_snap = [t.as_dict() for t in self._in_flight.values()]

        return {
            "pending":    pending_snap,
            "in_flight":  in_flight_snap,
            "stats": {
                "ticks_total":      self._ticks_total,
                "tasks_dispatched": self._tasks_dispatched,
                "tasks_completed":  self._tasks_completed,
                "tasks_timed_out":  self._tasks_timed_out,
                "tasks_cancelled":  self._tasks_cancelled,
                "pending_count":    len(pending_snap),
                "in_flight_count":  len(in_flight_snap),
            },
        }

    # ── Convenience factory methods ────────────────────────────────────────

    def enqueue_pick(
        self,
        goal_x:   float,
        goal_y:   float,
        goal_yaw: float = 0.0,
        priority: TaskPriority = TaskPriority.NORMAL,
        payload:  Optional[dict] = None,
    ) -> str:
        """Shorthand: create and enqueue a PICK task."""
        return self.add_task(Task(
            action   = "PICK",
            goal_x   = goal_x,
            goal_y   = goal_y,
            goal_yaw = goal_yaw,
            priority = priority,
            payload  = payload or {},
        ))

    def enqueue_place(
        self,
        goal_x:   float,
        goal_y:   float,
        goal_yaw: float = 0.0,
        priority: TaskPriority = TaskPriority.NORMAL,
        payload:  Optional[dict] = None,
    ) -> str:
        """Shorthand: create and enqueue a PLACE task."""
        return self.add_task(Task(
            action   = "PLACE",
            goal_x   = goal_x,
            goal_y   = goal_y,
            goal_yaw = goal_yaw,
            priority = priority,
            payload  = payload or {},
        ))

    def enqueue_charge(self, robot_id: int) -> str:
        """
        Enqueue an explicit CHARGE task for a specific robot.

        The task is assigned directly — bypassing the scoring model — because
        the robot that needs charging is already known.  This is a higher-level
        command than the robot's own critical-battery return-to-charger logic
        and allows the fleet manager to pre-emptively charge robots during
        quiet periods.
        """
        rec = self._registry.get_robot(robot_id)
        if rec is None:
            raise ValueError(f"Unknown robot_id {robot_id}")

        task = Task(
            action   = "CHARGE",
            goal_x   = rec.home_x,
            goal_y   = rec.home_y,
            goal_yaw = 0.0,
            priority = TaskPriority.HIGH,
        )
        task.assigned_robot = robot_id

        with self._lock:
            task.status       = TaskStatus.PENDING
            task.enqueue_time = self._clock()
            self._pending.append(task)
            self._pending.sort(key=lambda t: t.queue_key())

        self._log.info(
            f"[TaskAllocator] Enqueued CHARGE task {task.task_id} "
            f"pre-assigned to robot_{robot_id}"
        )
        return task.task_id

    # =========================================================================
    # Internal — allocation cycle
    # =========================================================================

    def _check_completions(self) -> None:
        """
        Scan in-flight tasks and mark any whose assigned robot has returned
        to IDLE with a cleared task_id as DONE.

        The registry's update_status() already increments tasks_completed on
        the RobotRecord; here we just mirror that into the Task object and
        move it to the archive.
        """
        completed_ids = []

        with self._lock:
            for task_id, task in self._in_flight.items():
                robot_id = task.assigned_robot
                if robot_id is None:
                    continue
                rec = self._registry.get_robot(robot_id)
                if rec is None:
                    continue
                # Robot has returned to IDLE and cleared its task_id
                if rec.state == RobotState.IDLE and rec.task_id is None:
                    completed_ids.append(task_id)

            for task_id in completed_ids:
                task = self._in_flight.pop(task_id)
                task.status    = TaskStatus.DONE
                task.done_time = self._clock()
                self._archive[task_id] = task
                self._tasks_completed += 1
                self._log.info(
                    f"[TaskAllocator] Task {task_id} DONE "
                    f"(robot_{task.assigned_robot}, action={task.action})"
                )

    def _check_timeouts(self) -> None:
        """
        Scan in-flight tasks and re-queue any that have exceeded task_timeout.

        On timeout:
          • A CANCEL command is sent to the assigned robot.
          • The task's retry_count is incremented.
          • The task's priority is boosted by one tier (capped at URGENT) so
            it jumps ahead of freshly queued lower-priority work.
          • The task is re-inserted into the pending queue.
        """
        now = self._clock()
        timed_out = []

        with self._lock:
            for task_id, task in self._in_flight.items():
                elapsed = now - task.dispatch_time
                if elapsed >= self._task_timeout:
                    timed_out.append(task_id)

            for task_id in timed_out:
                task = self._in_flight.pop(task_id)
                robot_id = task.assigned_robot
                self._tasks_timed_out += 1

                self._log.warning(
                    f"[TaskAllocator] Task {task_id} TIMED OUT after "
                    f"{self._task_timeout}s on robot_{robot_id}  "
                    f"(retry #{task.retry_count + 1})"
                )

                # Send CANCEL to free the robot
                if robot_id is not None:
                    self._send_command(robot_id, "CANCEL")

                # Boost priority and re-queue
                task.retry_count  += 1
                task.status        = TaskStatus.PENDING
                task.assigned_robot = None
                task.dispatch_time  = 0.0
                if task.priority.value < TaskPriority.URGENT.value:
                    task.priority = TaskPriority(task.priority.value + 1)
                task.enqueue_time  = self._clock()

                self._pending.append(task)

            if timed_out:
                self._pending.sort(key=lambda t: t.queue_key())

    def _assign_pending(self) -> None:
        """
        For each pending task (highest priority first) attempt to find the
        best-scoring available robot and dispatch.

        Stops assigning once no available robots remain.
        """
        available = self._registry.available_robots()
        if not available:
            return

        # Shallow copy so we can mutate the working set without holding the lock
        with self._lock:
            pending_copy = list(self._pending)

        assigned_robot_ids: set = set()

        for task in pending_copy:
            if not available:
                break  # no robots left this tick

            # If this is a pre-assigned CHARGE task, honour the assignment
            if task.assigned_robot is not None:
                target = self._registry.get_robot(task.assigned_robot)
                if target is not None and target.is_available:
                    self._dispatch(task, target)
                    available = [r for r in available if r.robot_id != target.robot_id]
                    assigned_robot_ids.add(target.robot_id)
                continue

            # General task: score all available robots and pick best
            candidates = [r for r in available if r.robot_id not in assigned_robot_ids]
            if not candidates:
                continue

            best_robot = self._best_robot(task, candidates)
            if best_robot is None:
                continue

            self._dispatch(task, best_robot)
            available = [r for r in available if r.robot_id != best_robot.robot_id]
            assigned_robot_ids.add(best_robot.robot_id)

    # =========================================================================
    # Internal — scoring
    # =========================================================================

    def _best_robot(
        self,
        task:       Task,
        candidates: List[RobotRecord],
    ) -> Optional[RobotRecord]:
        """
        Return the highest-scoring robot from candidates for the given task,
        or None if candidates is empty.

        Scoring
        -------
        score = w_dist * dist_score + w_battery * battery_score + w_load * load_score

        dist_score
            Normalised inverse distance.  The closest robot scores 1.0,
            the furthest scores 0.0.  If all candidates are equidistant the
            score is 1.0 for all (no distance preference).

        battery_score
            battery% / 100.  Linear — a robot at 80 % scores 0.80.

        load_score
            Normalised inverse task completion count.  The robot that has
            completed the fewest tasks scores 1.0.  If all robots have done
            the same number of tasks the score is 1.0 for all.
        """
        if not candidates:
            return None

        # ── Distance scores ────────────────────────────────────────────────
        distances = [r.distance_to(task.goal_x, task.goal_y) for r in candidates]
        max_dist  = max(distances) if max(distances) > 0.0 else 1.0
        min_dist  = min(distances)
        dist_range = max_dist - min_dist
        if dist_range < 1e-6:
            dist_scores = [1.0] * len(candidates)
        else:
            dist_scores = [(max_dist - d) / dist_range for d in distances]

        # ── Battery scores ─────────────────────────────────────────────────
        battery_scores = [r.battery / 100.0 for r in candidates]

        # ── Load scores ────────────────────────────────────────────────────
        completions = [r.tasks_completed for r in candidates]
        max_comp    = max(completions)
        if max_comp == 0:
            load_scores = [1.0] * len(candidates)
        else:
            load_scores = [(max_comp - c) / max_comp for c in completions]

        # ── Weighted sum ───────────────────────────────────────────────────
        scores = [
            self._w_dist    * dist_scores[i]
            + self._w_battery * battery_scores[i]
            + self._w_load    * load_scores[i]
            for i in range(len(candidates))
        ]

        best_idx = scores.index(max(scores))
        best     = candidates[best_idx]

        self._log.debug(
            f"[TaskAllocator] Scoring for task {task.task_id}  "
            + "  ".join(
                f"robot_{candidates[i].robot_id}="
                f"{scores[i]:.3f}("
                f"d={dist_scores[i]:.2f},"
                f"b={battery_scores[i]:.2f},"
                f"l={load_scores[i]:.2f})"
                for i in range(len(candidates))
            )
        )

        return best

    # =========================================================================
    # Internal — dispatch
    # =========================================================================

    def _dispatch(self, task: Task, robot: RobotRecord) -> None:
        """
        Assign task to robot: update internal state, then publish goal and
        task JSON over the robot's fleet topics.

        The registry's record_task_assigned() is called immediately so the
        robot appears busy before its next status message arrives, preventing
        double-dispatch.
        """
        now = self._clock()

        with self._lock:
            # Guard: task may have been cancelled between _assign_pending
            # building the candidate list and this dispatch call
            if task.status == TaskStatus.CANCELLED:
                return
            if task in self._pending:
                self._pending.remove(task)

            task.status        = TaskStatus.IN_FLIGHT
            task.assigned_robot = robot.robot_id
            task.dispatch_time  = now
            self._in_flight[task.task_id] = task

        # Pre-mark robot in registry (before next status arrives)
        self._registry.record_task_assigned(
            robot.robot_id, task.task_id, task.action
        )
        self._tasks_dispatched += 1

        self._log.info(
            f"[TaskAllocator] Dispatching task {task.task_id}  "
            f"action={task.action}  "
            f"goal=({task.goal_x:.2f}, {task.goal_y:.2f})  "
            f"→ robot_{robot.robot_id}  "
            f"(battery={robot.battery:.1f}%  "
            f"dist={robot.distance_to(task.goal_x, task.goal_y):.2f}m)"
        )

        # Publish PoseStamped goal
        self._publish_goal(robot.robot_id, task)

        # Publish task JSON (action + payload)
        self._publish_task(robot.robot_id, task)

    def _publish_goal(self, robot_id: int, task: Task) -> None:
        """
        Publish a geometry_msgs/PoseStamped on /fleet/robot_<id>/goal.

        The robot node subscribes to this topic and transitions from IDLE →
        NAVIGATING when it receives a valid goal.
        """
        pub = self._goal_pubs.get(robot_id)
        if pub is None:
            self._log.error(
                f"[TaskAllocator] No goal publisher for robot_{robot_id}"
            )
            return

        if not _ROS_AVAILABLE:
            return  # Running in unit-test context without ROS2

        msg = PoseStamped()
        msg.header.frame_id = "world"
        # Stamp is intentionally left at zero — the fleet manager node should
        # call get_clock().now().to_msg() and fill this in if needed.
        # For Gazebo sim use_sim_time=true, zero stamp is accepted by robot nodes.

        msg.pose.position.x = task.goal_x
        msg.pose.position.y = task.goal_y
        msg.pose.position.z = 0.0

        # Convert yaw → quaternion  (roll=0, pitch=0, yaw=goal_yaw)
        half_yaw = task.goal_yaw * 0.5
        msg.pose.orientation.z = math.sin(half_yaw)
        msg.pose.orientation.w = math.cos(half_yaw)

        pub.publish(msg)

    def _publish_task(self, robot_id: int, task: Task) -> None:
        """
        Publish a JSON task assignment on /fleet/robot_<id>/task.

        JSON schema:
        {
          "task_id":    str,
          "action":     str,          # "PICK" | "PLACE" | "MOVE_TO" | "CHARGE"
          "goal_x":     float,
          "goal_y":     float,
          "goal_yaw":   float,
          "priority":   str,
          "payload":    dict,
          "retry":      int
        }
        """
        pub = self._task_pubs.get(robot_id)
        if pub is None:
            self._log.error(
                f"[TaskAllocator] No task publisher for robot_{robot_id}"
            )
            return

        if not _ROS_AVAILABLE:
            return

        data = {
            "task_id":  task.task_id,
            "action":   task.action,
            "goal_x":   task.goal_x,
            "goal_y":   task.goal_y,
            "goal_yaw": task.goal_yaw,
            "priority": task.priority.name,
            "payload":  task.payload,
            "retry":    task.retry_count,
        }
        msg      = String()
        msg.data = json.dumps(data)
        pub.publish(msg)

    def _send_command(self, robot_id: int, command: str) -> None:
        """
        Publish a command string ("CANCEL" | "STOP") to
        /fleet/robot_<id>/command.

        This matches the subscription in robot1/2/3.py:
            /fleet/robot_<id>/command  std_msgs/String
        """
        pub = self._cmd_pubs.get(robot_id)
        if pub is None:
            self._log.warning(
                f"[TaskAllocator] No command publisher for robot_{robot_id} "
                f"— cannot send {command}"
            )
            return

        if not _ROS_AVAILABLE:
            return

        msg      = String()
        msg.data = command
        pub.publish(msg)
        self._log.info(
            f"[TaskAllocator] → robot_{robot_id}  command={command}"
        )

    # =========================================================================
    # Dunder helpers
    # =========================================================================

    def __repr__(self) -> str:
        with self._lock:
            np = len(self._pending)
            ni = len(self._in_flight)
        return (
            f"TaskAllocator("
            f"pending={np}, in_flight={ni}, "
            f"dispatched={self._tasks_dispatched}, "
            f"completed={self._tasks_completed})"
        )
