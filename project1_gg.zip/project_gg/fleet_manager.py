#!/usr/bin/env python3
# =============================================================================
# fleet_manager/fleet_manager.py
# =============================================================================
# Central ROS2 node for the Fleet Management System.
#
# Role in the stack
# -----------------
#   This is the single orchestration node for the three-robot warehouse fleet.
#   It is instantiated once by multi_robot.launch.py (10 s after Gazebo starts)
#   and runs for the lifetime of the simulation.
#
#                         ┌──────────────────────────┐
#                         │      FleetManagerNode     │
#                         │                          │
#   /fleet/robot_N/status ┤→ RobotRegistry           │
#   /fleet/robot_N/hb     ┤→ (liveness tracking)     │
#                         │         ↕                │
#                         │   TaskAllocator          ├→ /fleet/robot_N/goal
#                         │   (scoring + dispatch)   ├→ /fleet/robot_N/task
#                         │         ↕                ├→ /fleet/robot_N/command
#                         │   Fleet-health checks    │
#                         │   (low-battery, ESTOP)   │
#                         │         ↕                │
#                         │   /fleet/status  (JSON)  │
#                         │   /fleet/tasks   (JSON)  │
#                         └──────────────────────────┘
#
# Responsibilities
# ----------------
#   1. Subscribe to every robot's status and heartbeat topics; feed them into
#      RobotRegistry so all fleet state is centralised.
#   2. Drive TaskAllocator.tick() at 1 Hz to assign pending tasks and detect
#      timeouts.
#   3. Monitor fleet health every 2 s:
#        • Low-battery robots → enqueue a CHARGE task.
#        • EMERGENCY_STOP robots → publish a STOP command and log an alert.
#        • Offline robots (heartbeat timeout) → log a WARNING.
#   4. Publish aggregate fleet status on /fleet/status (JSON, 1 Hz).
#   5. Publish task-queue snapshot on /fleet/tasks (JSON, 1 Hz).
#   6. Expose ROS2 services:
#        • /fleet/add_task     (std_srvs/srv/SetBool used as a trigger;
#                               actual task params arrive via /fleet/task_request)
#        • /fleet/cancel_task  (rcl_interfaces/srv/SetParameters re-purposed
#                               as a string-keyed call — see below)
#        • /fleet/robot_command  (send arbitrary command to a robot)
#   7. Accept task requests on /fleet/task_request (std_msgs/String, JSON)
#      from the Streamlit dashboard or external nodes without needing a service.
#
# Parameters (declared; all come from multi_robot.launch.py)
# ----------------------------------------------------------
#   use_sim_time          bool     true
#   robot_namespaces      str[]    ["robot_1","robot_2","robot_3"]
#   grid_resolution       float    0.2   m/cell
#   map_width             float    20.0  m
#   map_height            float    20.0  m
#   collision_lookahead   float    0.5   m
#   task_timeout          float    30.0  s
#   charging_positions    float[]  [-8,0, -8,-1, -8,-2]
#   dispatch_pose         float[]  [-4.0,-8.5,0.0]
#   receiving_pose        float[]  [ 4.0,-8.5,0.0]
#   heartbeat_timeout     float    5.0   s
#   low_battery_threshold float    20.0  %
#   w_dist                float    0.50
#   w_battery             float    0.30
#   w_load                float    0.20
#   fleet_status_hz       float    1.0   Hz
#   health_check_hz       float    0.5   Hz (every 2 s)
#
# Topics
# ------
#   Subscribed (per robot, N = 1..3)
#     /fleet/robot_N/status       std_msgs/String   (JSON)
#     /fleet/robot_N/heartbeat    std_msgs/Header
#
#   Published (per robot, N = 1..3)
#     /fleet/robot_N/goal         geometry_msgs/PoseStamped
#     /fleet/robot_N/task         std_msgs/String   (JSON)
#     /fleet/robot_N/command      std_msgs/String   ("STOP"|"CANCEL"|"RESUME")
#
#   Published (fleet-level)
#     /fleet/status               std_msgs/String   (JSON fleet summary)
#     /fleet/tasks                std_msgs/String   (JSON task-queue snapshot)
#
#   Subscribed (fleet-level)
#     /fleet/task_request         std_msgs/String   (JSON new-task request)
#
# Services
# --------
#   /fleet/cancel_task            std_srvs/srv/Trigger  (request.data = task_id)
#   /fleet/emergency_stop_all     std_srvs/srv/Trigger
#   /fleet/resume_all             std_srvs/srv/Trigger
#
# Task request JSON schema  (/fleet/task_request)
# ------------------------------------------------
#   {
#     "action"   : str,           # "PICK" | "PLACE" | "MOVE_TO" | "CHARGE"
#     "goal_x"   : float,
#     "goal_y"   : float,
#     "goal_yaw" : float,         # optional, default 0.0
#     "priority" : str,           # optional, default "NORMAL"
#     "payload"  : dict,          # optional, arbitrary metadata
#     "task_id"  : str,           # optional, auto-generated if omitted
#     "robot_id" : int            # optional — force assignment to specific robot
#   }
#
# Cancel service request JSON  (/fleet/cancel_task)
# --------------------------------------------------
#   Uses std_srvs/srv/Trigger; the caller encodes task_id in a topic-level
#   JSON published to /fleet/task_request with action="CANCEL_TASK".
#   A dedicated cancel service is also available via /fleet/cancel_task
#   (std_srvs/srv/Trigger with task_id in the message — handled via
#    a parameter-set workaround; see _svc_cancel_task).
#
# =============================================================================

from __future__ import annotations

import json
import math
import threading
import time
from typing import Dict, List, Optional, Tuple

import rclpy
from rclpy.node import Node
from rclpy.qos import (
    QoSDurabilityPolicy,
    QoSProfile,
    QoSReliabilityPolicy,
)

from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String, Header
from std_srvs.srv import Trigger
from rcl_interfaces.msg import SetParametersResult

from fleet_manager.robot_registry import RobotRegistry, RobotState
from fleet_manager.task_allocator import TaskAllocator, Task, TaskPriority, TaskStatus


# =============================================================================
# QoS helpers
# =============================================================================

def _reliable_qos(depth: int = 10) -> QoSProfile:
    return QoSProfile(
        reliability=QoSReliabilityPolicy.RELIABLE,
        durability=QoSDurabilityPolicy.VOLATILE,
        depth=depth,
    )


# =============================================================================
# FleetManagerNode
# =============================================================================

class FleetManagerNode(Node):
    """
    Centralised fleet orchestration node for the three-robot warehouse system.

    Lifecycle
    ---------
    __init__
        Declare + read parameters → create RobotRegistry → create publishers
        and subscribers → create TaskAllocator → create timers and services.

    Timers (all single-threaded via the default executor)
        _timer_allocation   1 Hz  → TaskAllocator.tick()
        _timer_fleet_pub    1 Hz  → publish /fleet/status and /fleet/tasks
        _timer_health       0.5 Hz → fleet health checks (battery, ESTOP, liveness)

    Shutdown
        destroy_node() → rclpy.shutdown()
    """

    # ── Robot IDs managed by this node ────────────────────────────────────
    _ROBOT_IDS: List[int] = [1, 2, 3]

    def __init__(self) -> None:
        super().__init__("fleet_manager")

        # ── Declare parameters ─────────────────────────────────────────────
        self._declare_parameters()

        # ── Read parameters ────────────────────────────────────────────────
        self._read_parameters()

        self.get_logger().info(
            "[FleetManager] Initialising — "
            f"robots={self._robot_namespaces}  "
            f"task_timeout={self._task_timeout}s  "
            f"low_battery_thr={self._low_battery_threshold}%"
        )

        # ── Build per-robot publisher / subscriber maps ────────────────────
        self._goal_pubs:    Dict[int, object] = {}   # int → Publisher<PoseStamped>
        self._task_pubs:    Dict[int, object] = {}   # int → Publisher<String>
        self._cmd_pubs:     Dict[int, object] = {}   # int → Publisher<String>
        self._status_subs:  Dict[int, object] = {}   # int → Subscription<String>
        self._hb_subs:      Dict[int, object] = {}   # int → Subscription<Header>

        self._setup_robot_comms()

        # ── Fleet-level publishers ─────────────────────────────────────────
        self._pub_fleet_status = self.create_publisher(
            String, "/fleet/status", _reliable_qos()
        )
        self._pub_fleet_tasks = self.create_publisher(
            String, "/fleet/tasks", _reliable_qos()
        )

        # ── Task-request subscriber (dashboard / external nodes) ───────────
        self._sub_task_request = self.create_subscription(
            String,
            "/fleet/task_request",
            self._cb_task_request,
            _reliable_qos(),
        )

        # ── RobotRegistry ─────────────────────────────────────────────────
        home_positions = self._parse_home_positions()
        self._registry = RobotRegistry(
            robot_ids             = self._robot_ids,
            heartbeat_timeout     = self._heartbeat_timeout,
            low_battery_threshold = self._low_battery_threshold,
            home_positions        = home_positions,
        )

        # ── TaskAllocator ──────────────────────────────────────────────────
        self._allocator = TaskAllocator(
            registry        = self._registry,
            goal_publishers = self._goal_pubs,
            task_publishers = self._task_pubs,
            cmd_publishers  = self._cmd_pubs,
            node_logger     = self.get_logger(),
            task_timeout    = self._task_timeout,
            dispatch_pose   = tuple(self._dispatch_pose),
            receiving_pose  = tuple(self._receiving_pose),
            w_dist          = self._w_dist,
            w_battery       = self._w_battery,
            w_load          = self._w_load,
        )

        # ── Services ───────────────────────────────────────────────────────
        self._svc_cancel = self.create_service(
            Trigger,
            "/fleet/cancel_task",
            self._svc_cancel_task,
        )
        self._svc_estop_all = self.create_service(
            Trigger,
            "/fleet/emergency_stop_all",
            self._svc_emergency_stop_all,
        )
        self._svc_resume_all = self.create_service(
            Trigger,
            "/fleet/resume_all",
            self._svc_resume_all,
        )

        # ── Internal state ─────────────────────────────────────────────────
        # task_id pending cancellation — set by service, consumed by allocator
        self._pending_cancel_id: Optional[str] = None
        self._cancel_lock = threading.Lock()

        # Track which robots have already had a low-battery charge enqueued
        # (reset when the robot reaches CHARGING state)
        self._charge_enqueued: Dict[int, bool] = {rid: False for rid in self._robot_ids}

        # Global ESTOP flag (set by service, cleared by resume service)
        self._global_estop: bool = False

        # ── Timers ─────────────────────────────────────────────────────────
        alloc_period  = 1.0 / max(self._fleet_status_hz, 0.1)
        health_period = 1.0 / max(self._health_check_hz, 0.1)

        self._timer_allocation = self.create_timer(
            alloc_period, self._cb_allocation_tick
        )
        self._timer_fleet_pub = self.create_timer(
            alloc_period, self._cb_publish_fleet
        )
        self._timer_health = self.create_timer(
            health_period, self._cb_health_check
        )

        # ── Parameter change callback ──────────────────────────────────────
        self.add_on_set_parameters_callback(self._on_param_change)

        self.get_logger().info("[FleetManager] Initialisation complete. Ready.")

    # =========================================================================
    # Parameter declaration and reading
    # =========================================================================

    def _declare_parameters(self) -> None:
        """Declare all ROS2 parameters with defaults matching launch file."""
        self.declare_parameter("robot_namespaces",      ["robot_1", "robot_2", "robot_3"])
        self.declare_parameter("grid_resolution",       0.2)
        self.declare_parameter("map_width",             20.0)
        self.declare_parameter("map_height",            20.0)
        self.declare_parameter("collision_lookahead",   0.5)
        self.declare_parameter("task_timeout",          30.0)
        self.declare_parameter("heartbeat_timeout",     5.0)
        self.declare_parameter("low_battery_threshold", 20.0)
        self.declare_parameter("fleet_status_hz",       1.0)
        self.declare_parameter("health_check_hz",       0.5)
        self.declare_parameter("w_dist",                0.50)
        self.declare_parameter("w_battery",             0.30)
        self.declare_parameter("w_load",                0.20)
        # Charging positions: flat list [x1,y1, x2,y2, x3,y3]
        # Matches multi_robot.launch.py "charging_positions" parameter.
        self.declare_parameter(
            "charging_positions", [-8.0, 0.0, -8.0, -1.0, -8.0, -2.0]
        )
        # Named goal poses [x, y, yaw]
        self.declare_parameter("dispatch_pose",  [-4.0, -8.5, 0.0])
        self.declare_parameter("receiving_pose", [ 4.0, -8.5, 0.0])

    def _read_parameters(self) -> None:
        """Read all declared parameters into instance variables."""
        self._robot_namespaces: List[str] = (
            self.get_parameter("robot_namespaces").value
        )
        # Derive integer IDs from namespace strings "robot_N" → N
        self._robot_ids: List[int] = []
        for ns in self._robot_namespaces:
            try:
                self._robot_ids.append(int(ns.split("_")[-1]))
            except (ValueError, IndexError):
                self.get_logger().warning(
                    f"[FleetManager] Cannot parse robot_id from namespace '{ns}'"
                )

        self._task_timeout:          float = self.get_parameter("task_timeout").value
        self._heartbeat_timeout:     float = self.get_parameter("heartbeat_timeout").value
        self._low_battery_threshold: float = self.get_parameter("low_battery_threshold").value
        self._fleet_status_hz:       float = self.get_parameter("fleet_status_hz").value
        self._health_check_hz:       float = self.get_parameter("health_check_hz").value
        self._w_dist:                float = self.get_parameter("w_dist").value
        self._w_battery:             float = self.get_parameter("w_battery").value
        self._w_load:                float = self.get_parameter("w_load").value
        self._collision_lookahead:   float = self.get_parameter("collision_lookahead").value

        raw_charging: List[float] = self.get_parameter("charging_positions").value
        self._charging_positions: List[float] = list(raw_charging)

        self._dispatch_pose:  List[float] = list(self.get_parameter("dispatch_pose").value)
        self._receiving_pose: List[float] = list(self.get_parameter("receiving_pose").value)

    def _parse_home_positions(self) -> Dict[int, Tuple[float, float]]:
        """
        Convert the flat charging_positions list [x1,y1,x2,y2,x3,y3] into
        {robot_id: (x, y)} using the ordering of robot_ids.
        """
        homes: Dict[int, Tuple[float, float]] = {}
        pairs = list(zip(self._charging_positions[0::2], self._charging_positions[1::2]))
        for idx, rid in enumerate(self._robot_ids):
            if idx < len(pairs):
                homes[rid] = pairs[idx]
            else:
                homes[rid] = (0.0, 0.0)
        return homes

    # =========================================================================
    # Per-robot communication setup
    # =========================================================================

    def _setup_robot_comms(self) -> None:
        """
        For each robot, create:
          • goal publisher    → /fleet/robot_N/goal
          • task publisher    → /fleet/robot_N/task
          • command publisher → /fleet/robot_N/command
          • status subscriber → /fleet/robot_N/status
          • heartbeat sub     → /fleet/robot_N/heartbeat
        """
        rqos = _reliable_qos()

        for rid in self._robot_ids:
            ns = f"robot_{rid}"

            # ── Publishers ─────────────────────────────────────────────────
            self._goal_pubs[rid] = self.create_publisher(
                PoseStamped,
                f"/fleet/{ns}/goal",
                rqos,
            )
            self._task_pubs[rid] = self.create_publisher(
                String,
                f"/fleet/{ns}/task",
                rqos,
            )
            self._cmd_pubs[rid] = self.create_publisher(
                String,
                f"/fleet/{ns}/command",
                rqos,
            )

            # ── Subscribers ────────────────────────────────────────────────
            # Capture rid in closure with default-arg trick
            self._status_subs[rid] = self.create_subscription(
                String,
                f"/fleet/{ns}/status",
                lambda msg, r=rid: self._cb_robot_status(msg, r),
                rqos,
            )
            self._hb_subs[rid] = self.create_subscription(
                Header,
                f"/fleet/{ns}/heartbeat",
                lambda msg, r=rid: self._cb_robot_heartbeat(msg, r),
                10,
            )

            self.get_logger().info(
                f"[FleetManager] Registered comms for {ns}"
            )

    # =========================================================================
    # Subscriber callbacks
    # =========================================================================

    def _cb_robot_status(self, msg: String, robot_id: int) -> None:
        """
        Receive a JSON status message from robot_N and update the registry.

        Also checks if a CHARGE task should be auto-cleared (robot reached
        CHARGING state) to allow future low-battery re-enqueuing.
        """
        ok = self._registry.update_status(msg.data)
        if not ok:
            self.get_logger().warning(
                f"[FleetManager] Malformed status from robot_{robot_id}: "
                f"{msg.data[:80]}…"
            )
            return

        # Clear charge-enqueued flag once robot is actually charging
        rec = self._registry.get_robot(robot_id)
        if rec is not None and rec.state == RobotState.CHARGING:
            self._charge_enqueued[robot_id] = False

    def _cb_robot_heartbeat(self, msg: Header, robot_id: int) -> None:
        """
        Record heartbeat receipt in the registry so liveness tracking works.
        The Header timestamp is not used directly — wall-clock monotonic is
        used inside the registry to be immune to sim-time jumps.
        """
        self._registry.update_heartbeat(robot_id)

    def _cb_task_request(self, msg: String) -> None:
        """
        Parse a JSON task-request from /fleet/task_request and enqueue or
        route it appropriately.

        Accepted actions
        ----------------
        PICK / PLACE / MOVE_TO
            Standard tasks routed through the scoring allocator.
        CHARGE
            Directed charge task for a specific robot (requires "robot_id").
        CANCEL_TASK
            Cancel an existing task (requires "task_id").
        STOP_ROBOT
            Send STOP command to a specific robot (requires "robot_id").
        RESUME_ROBOT
            Send RESUME command to a specific robot (requires "robot_id").
        """
        try:
            data = json.loads(msg.data)
        except json.JSONDecodeError as exc:
            self.get_logger().error(
                f"[FleetManager] /fleet/task_request — JSON parse error: {exc}"
            )
            return

        action = str(data.get("action", "")).upper()

        if action == "CANCEL_TASK":
            task_id = data.get("task_id")
            if task_id:
                cancelled = self._allocator.cancel_task(task_id)
                self.get_logger().info(
                    f"[FleetManager] Cancel request for {task_id}: "
                    f"{'OK' if cancelled else 'NOT FOUND'}"
                )
            return

        if action in ("STOP_ROBOT", "RESUME_ROBOT"):
            robot_id = data.get("robot_id")
            if robot_id in self._robot_ids:
                cmd = "STOP" if action == "STOP_ROBOT" else "RESUME"
                self._send_command(robot_id, cmd)
            return

        if action == "CHARGE":
            robot_id = data.get("robot_id")
            if robot_id not in self._robot_ids:
                self.get_logger().error(
                    f"[FleetManager] CHARGE action requires valid robot_id, "
                    f"got: {robot_id}"
                )
                return
            task_id = self._allocator.enqueue_charge(robot_id)
            self.get_logger().info(
                f"[FleetManager] Enqueued CHARGE task {task_id} "
                f"for robot_{robot_id} (manual request)"
            )
            return

        # General task: PICK / PLACE / MOVE_TO
        goal_x = data.get("goal_x")
        goal_y = data.get("goal_y")
        if goal_x is None or goal_y is None:
            self.get_logger().error(
                f"[FleetManager] Task request missing goal_x/goal_y: {data}"
            )
            return

        try:
            priority = TaskPriority[data.get("priority", "NORMAL").upper()]
        except KeyError:
            priority = TaskPriority.NORMAL

        task = Task(
            action   = action or "MOVE_TO",
            goal_x   = float(goal_x),
            goal_y   = float(goal_y),
            goal_yaw = float(data.get("goal_yaw", 0.0)),
            priority = priority,
            payload  = data.get("payload", {}),
        )
        if "task_id" in data:
            task.task_id = str(data["task_id"])

        # If caller specified a robot_id, pre-assign
        robot_id = data.get("robot_id")
        if robot_id in self._robot_ids:
            task.assigned_robot = robot_id

        enqueued_id = self._allocator.add_task(task)
        self.get_logger().info(
            f"[FleetManager] Task {enqueued_id} enqueued via /fleet/task_request  "
            f"action={task.action}  "
            f"goal=({task.goal_x:.2f}, {task.goal_y:.2f})  "
            f"priority={task.priority.name}"
        )

    # =========================================================================
    # Timer callbacks
    # =========================================================================

    def _cb_allocation_tick(self) -> None:
        """
        Called at fleet_status_hz (1 Hz default).
        Drives the task-allocation cycle: completion detection → timeout
        detection → pending-task dispatch.
        """
        if self._global_estop:
            return  # allocation suspended during fleet-wide ESTOP

        # Process any pending cancel issued via service call
        with self._cancel_lock:
            pending_cancel = self._pending_cancel_id
            self._pending_cancel_id = None
        if pending_cancel:
            self._allocator.cancel_task(pending_cancel)

        self._allocator.tick()

    def _cb_publish_fleet(self) -> None:
        """
        Publish JSON fleet status and task-queue snapshots at fleet_status_hz.
        These are consumed by the Streamlit dashboard (via REST bridge) and
        any monitoring tools listening to /fleet/status and /fleet/tasks.
        """
        # Fleet status
        summary = self._registry.fleet_summary()
        summary["global_estop"] = self._global_estop
        status_msg      = String()
        status_msg.data = json.dumps(summary)
        self._pub_fleet_status.publish(status_msg)

        # Task queue snapshot
        task_snap       = self._allocator.queue_snapshot()
        tasks_msg       = String()
        tasks_msg.data  = json.dumps(task_snap)
        self._pub_fleet_tasks.publish(tasks_msg)

    def _cb_health_check(self) -> None:
        """
        Called at health_check_hz (0.5 Hz = every 2 s).

        Checks
        ------
        1. Offline robots (heartbeat timeout) — log WARNING.
        2. EMERGENCY_STOP robots — log ERROR; send STOP to ensure cmd_vel stops.
        3. Low-battery robots — enqueue a CHARGE task (once per battery cycle).
        4. Critical-battery robots (≤5 %) — send RETURN_TO_CHARGE command.
        """
        for rid in self._robot_ids:
            rec = self._registry.get_robot(rid)
            if rec is None:
                continue

            # ── Liveness ──────────────────────────────────────────────────
            if not self._registry.is_alive(rid):
                self.get_logger().warning(
                    f"[FleetManager] robot_{rid} OFFLINE — "
                    f"no heartbeat within {self._heartbeat_timeout}s"
                )
                continue  # no point checking state of a dead robot

            # ── Emergency stop ─────────────────────────────────────────────
            if rec.state == RobotState.EMERGENCY_STOP:
                self.get_logger().error(
                    f"[FleetManager] robot_{rid} in EMERGENCY_STOP — "
                    f"sending STOP command"
                )
                self._send_command(rid, "STOP")

            # ── Critical battery (≤5 %) ────────────────────────────────────
            elif rec.battery <= 5.0 and rec.state not in (
                RobotState.RETURNING, RobotState.CHARGING
            ):
                self.get_logger().error(
                    f"[FleetManager] robot_{rid} CRITICAL battery "
                    f"{rec.battery:.1f}% — sending RETURN_TO_CHARGE"
                )
                self._send_command(rid, "RETURN_TO_CHARGE")
                self._charge_enqueued[rid] = True  # suppress duplicate enqueue

            # ── Low battery (≤ threshold, > 5 %) ─────────────────────────
            elif (
                rec.battery <= self._low_battery_threshold
                and not self._charge_enqueued.get(rid, False)
                and rec.state not in (RobotState.RETURNING, RobotState.CHARGING)
            ):
                self.get_logger().warning(
                    f"[FleetManager] robot_{rid} low battery "
                    f"{rec.battery:.1f}% — enqueuing CHARGE task"
                )
                self._allocator.enqueue_charge(rid)
                self._charge_enqueued[rid] = True

    # =========================================================================
    # Service handlers
    # =========================================================================

    def _svc_cancel_task(
        self, request: Trigger.Request, response: Trigger.Response
    ) -> Trigger.Response:
        """
        Cancel a task by task_id.

        Because std_srvs/Trigger carries no payload the caller must first
        publish the task_id to /fleet/task_request with action="CANCEL_TASK",
        OR set a ROS2 parameter "cancel_task_id" and then call this service.

        This service reads the "cancel_task_id" parameter if set.
        """
        task_id = None
        try:
            task_id = self.get_parameter("cancel_task_id").value
        except Exception:
            pass

        if not task_id:
            response.success = False
            response.message = (
                "No task_id provided. Set parameter 'cancel_task_id' before calling."
            )
            return response

        cancelled = self._allocator.cancel_task(str(task_id))
        response.success = cancelled
        response.message = (
            f"Task {task_id} cancelled." if cancelled
            else f"Task {task_id} not found."
        )
        self.get_logger().info(
            f"[FleetManager] /fleet/cancel_task  task={task_id}  "
            f"result={'OK' if cancelled else 'NOT FOUND'}"
        )
        return response

    def _svc_emergency_stop_all(
        self, request: Trigger.Request, response: Trigger.Response
    ) -> Trigger.Response:
        """
        Send STOP to every robot and suspend task allocation.
        """
        self._global_estop = True
        for rid in self._robot_ids:
            self._send_command(rid, "STOP")
        self.get_logger().error(
            "[FleetManager] FLEET-WIDE EMERGENCY STOP activated"
        )
        response.success = True
        response.message = f"STOP sent to {len(self._robot_ids)} robots. Allocation suspended."
        return response

    def _svc_resume_all(
        self, request: Trigger.Request, response: Trigger.Response
    ) -> Trigger.Response:
        """
        Send RESUME to every robot and re-enable task allocation.
        """
        self._global_estop = False
        for rid in self._robot_ids:
            self._send_command(rid, "RESUME")
        self.get_logger().info(
            "[FleetManager] Fleet-wide RESUME — allocation re-enabled"
        )
        response.success = True
        response.message = f"RESUME sent to {len(self._robot_ids)} robots. Allocation active."
        return response

    # =========================================================================
    # Internal helpers
    # =========================================================================

    def _send_command(self, robot_id: int, command: str) -> None:
        """
        Publish a command string to /fleet/robot_<id>/command.

        Recognised by robot nodes: STOP | CANCEL | RESUME | RETURN_TO_CHARGE
        """
        pub = self._cmd_pubs.get(robot_id)
        if pub is None:
            self.get_logger().error(
                f"[FleetManager] No command publisher for robot_{robot_id}"
            )
            return
        msg      = String()
        msg.data = command
        pub.publish(msg)
        self.get_logger().info(
            f"[FleetManager] → robot_{robot_id}  command={command}"
        )

    # =========================================================================
    # Dynamic parameter reconfiguration
    # =========================================================================

    def _on_param_change(self, params) -> SetParametersResult:
        """
        Respond to runtime parameter updates via ros2 param set.

        Supported live-reconfigurable parameters:
          task_timeout          → updates allocator
          low_battery_threshold → updates registry + health-check logic
          w_dist / w_battery / w_load  → logs note (allocator uses values on
                                         next tick via closure — see note below)

        Note: TaskAllocator reads weights at construction time, so weight
        changes take effect on the NEXT TaskAllocator instantiation (i.e. node
        restart) unless TaskAllocator exposes a set_weights() method in a
        future iteration.
        """
        result = SetParametersResult(successful=True)
        for param in params:
            if param.name == "task_timeout":
                self._task_timeout = float(param.value)
                self._allocator._task_timeout = self._task_timeout
                self.get_logger().info(
                    f"[FleetManager] task_timeout updated → {self._task_timeout}s"
                )
            elif param.name == "low_battery_threshold":
                self._low_battery_threshold = float(param.value)
                self._registry._low_battery_threshold = self._low_battery_threshold
                self.get_logger().info(
                    f"[FleetManager] low_battery_threshold updated → "
                    f"{self._low_battery_threshold}%"
                )
            elif param.name in ("w_dist", "w_battery", "w_load"):
                self.get_logger().info(
                    f"[FleetManager] {param.name}={param.value} noted — "
                    f"takes effect on next node restart"
                )
            elif param.name == "cancel_task_id":
                pass  # Accepted; consumed by _svc_cancel_task
        return result

    # =========================================================================
    # Shutdown
    # =========================================================================

    def destroy_node(self) -> None:
        """
        Clean shutdown: stop all robots before destroying ROS2 resources.
        """
        self.get_logger().info(
            "[FleetManager] Shutting down — sending STOP to all robots"
        )
        for rid in self._robot_ids:
            try:
                self._send_command(rid, "STOP")
            except Exception:
                pass
        super().destroy_node()


# =============================================================================
# Entry point
# =============================================================================

def main(args=None) -> None:
    rclpy.init(args=args)
    node = FleetManagerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("[FleetManager] KeyboardInterrupt — shutting down.")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
