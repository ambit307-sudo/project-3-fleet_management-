# dashboard/app.py

import streamlit as st
import pandas as pd
from dashboard.data_provider import get_robot_data

st.set_page_config(
    page_title="Fleet Management Dashboard",
    page_icon="🤖",
    layout="wide"
)

st.title("🚚 Multi-Robot Fleet Management System")

st.markdown("---")

# Fetch robot data
robot_data = get_robot_data()

# Convert to dataframe
df = pd.DataFrame(robot_data)

# Metrics
col1, col2, col3 = st.columns(3)

with col1:
    st.metric("Total Robots", len(df))

with col2:
    idle_count = len(df[df["status"] == "idle"])
    st.metric("Idle Robots", idle_count)

with col3:
    busy_count = len(df[df["status"] == "busy"])
    st.metric("Busy Robots", busy_count)

st.markdown("---")

st.subheader("Robot Status")

st.dataframe(
    df,
    use_container_width=True
)

st.markdown("---")

st.subheader("Battery Levels")

st.bar_chart(
    df.set_index("robot_id")["battery"]
)

st.markdown("---")

st.subheader("Robot Positions")

for _, robot in df.iterrows():
    st.write(
        f"{robot['robot_id']} → "
        f"Position ({robot['x']}, {robot['y']}) "
        f"| Status: {robot['status']}"
    )

st.markdown("---")

st.success("Dashboard running successfully.")
