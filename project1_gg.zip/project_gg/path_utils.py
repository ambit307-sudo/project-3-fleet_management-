#!/usr/bin/env python3
# =============================================================================
# navigation/path_utils.py
# =============================================================================
# Stateless geometric utilities that operate on the paths produced by
# AStarPlanner and consumed by the robot navigation loops.
#
# Design overview
# ---------------
#   This module is NOT a ROS2 node.  Every function is pure Python — no ROS
#   imports, no side effects — so it can be unit-tested without a running ROS2
#   environment and imported safely from both robot nodes and the fleet manager.
#
#   The module is organised into six functional groups:
#
#   ┌─────────────────────────────────────────────────────────────────────────┐
#   │  1. Core geometry primitives                                            │
#   │       angle_between, normalise_angle, euclidean_distance,              │
#   │       heading_to, cross_track_error                                     │
#   ├─────────────────────────────────────────────────────────────────────────┤
#   │  2. Path interrogation                                                  │
#   │       path_length, path_curvature, turning_angles,                     │
#   │       closest_point_on_segment, closest_waypoint_index,                │
#   │       lookahead_point (pure-pursuit)                                    │
#   ├─────────────────────────────────────────────────────────────────────────┤
#   │  3. Path transformation                                                 │
#   │       interpolate_path, trim_path_to_distance,                         │
#   │       subsample_path, reverse_path,                                    │
#   │       offset_path (lateral shift for lane separation)                  │
#   ├─────────────────────────────────────────────────────────────────────────┤
#   │  4. Path validation                                                     │
#   │       path_clears_obstacle, path_min_clearance,                        │
#   │       segment_intersects_circle, path_within_bounds                    │
#   ├─────────────────────────────────────────────────────────────────────────┤
#   │  5. Multi-robot conflict detection                                      │
#   │       paths_conflict, earliest_conflict_point,                         │
#   │       temporal_separation  (time-parameterised proximity check)        │
#   ├─────────────────────────────────────────────────────────────────────────┤
#   │  6. Named-pose helpers  (mirrors AStarPlanner constants)               │
#   │       nearest_charging_pad, nearest_shelf_access,                      │
#   │       pose_near_named_location                                          │
#   └─────────────────────────────────────────────────────────────────────────┘
#
# Coordinate convention
# ---------------------
#   All functions use the ROS REP-103 / warehouse world frame:
#     • Origin at warehouse centre
#     • x-axis pointing East, y-axis pointing North
#     • Angles in radians, measured counter-clockwise from +x
#     • World bounds: x ∈ [−10.0, 10.0],  y ∈ [−10.0, 10.0]
#
#   WorldPt = Tuple[float, float]    — (x, y) in metres
#   Path    = List[WorldPt]          — ordered sequence of world points
#
# Integration notes
# -----------------
#   Typical import in a robot node or fleet manager:
#
#       from navigation.path_utils import (
#           lookahead_point,
#           path_length,
#           paths_conflict,
#           nearest_charging_pad,
#       )
#
#   The module shares the WorldPt / Path type aliases with astar_planner.py;
#   paths produced by AStarPlanner are directly usable here.
#
# Dependencies
# ------------
#   Standard library only: math, typing, collections (no third-party packages).
#
# =============================================================================

from __future__ import annotations

import math
from collections import deque
from typing import Dict, Iterator, List, Optional, Sequence, Tuple

# ---------------------------------------------------------------------------
# Public type aliases  (mirror astar_planner.py for cross-module consistency)
# ---------------------------------------------------------------------------
WorldPt = Tuple[float, float]    # (x, y) metres
Path    = List[WorldPt]          # ordered waypoint sequence


# =============================================================================
# 1. Core geometry primitives
# =============================================================================

def normalise_angle(angle: float) -> float:
    """
    Wrap *angle* (radians) into the half-open interval (−π, +π].

    Uses the two-argument arc-tangent trick to avoid branch arithmetic.

    Parameters
    ----------
    angle : float
        Input angle in radians (any value).

    Returns
    -------
    float
        Equivalent angle in (−π, +π].

    Examples
    --------
    >>> normalise_angle(3 * math.pi)          # → π
    >>> normalise_angle(-3 * math.pi)         # → π (or −π at boundary)
    """
    return math.atan2(math.sin(angle), math.cos(angle))


def euclidean_distance(a: WorldPt, b: WorldPt) -> float:
    """
    Return the straight-line distance between two world points.

    Parameters
    ----------
    a, b : WorldPt
        Source and destination points.

    Returns
    -------
    float
        Distance in metres (always ≥ 0).
    """
    return math.hypot(b[0] - a[0], b[1] - a[1])


def heading_to(src: WorldPt, dst: WorldPt) -> float:
    """
    Bearing from *src* to *dst* in the world frame.

    Returns the angle (radians, counter-clockwise from +x) of the vector
    that points from *src* to *dst*.

    Parameters
    ----------
    src : WorldPt
        Starting position.
    dst : WorldPt
        Target position.

    Returns
    -------
    float
        Bearing in [−π, +π].  Returns 0.0 when src == dst.
    """
    dx = dst[0] - src[0]
    dy = dst[1] - src[1]
    if abs(dx) < 1e-9 and abs(dy) < 1e-9:
        return 0.0
    return math.atan2(dy, dx)


def angle_between(a: WorldPt, vertex: WorldPt, b: WorldPt) -> float:
    """
    Interior angle at *vertex* formed by the path a → vertex → b.

    Returns the signed turning angle (radians, in [−π, π]).  A positive
    value means a left (counter-clockwise) turn; negative means right.

    Parameters
    ----------
    a      : WorldPt — the point before the vertex.
    vertex : WorldPt — the turning point.
    b      : WorldPt — the point after the vertex.

    Returns
    -------
    float
        Signed turning angle in [−π, π].
    """
    heading_in  = heading_to(a, vertex)
    heading_out = heading_to(vertex, b)
    return normalise_angle(heading_out - heading_in)


def cross_track_error(
    robot: WorldPt,
    seg_start: WorldPt,
    seg_end: WorldPt,
) -> float:
    """
    Signed perpendicular distance from *robot* to the infinite line through
    *seg_start* → *seg_end*.

    Convention (matches ROS nav2 cross-track convention):
      • Positive → robot is to the left of the direction of travel.
      • Negative → robot is to the right.
      • Zero     → robot is on the line.

    Uses the 2-D cross product:
        XTE = ((B−A) × (P−A)) / |B−A|

    Parameters
    ----------
    robot     : WorldPt — current robot position.
    seg_start : WorldPt — start of the reference segment.
    seg_end   : WorldPt — end of the reference segment.

    Returns
    -------
    float
        Signed cross-track error in metres.  Returns 0.0 if seg_start == seg_end.
    """
    ax, ay = seg_start
    bx, by = seg_end
    px, py = robot

    seg_len = euclidean_distance(seg_start, seg_end)
    if seg_len < 1e-9:
        return 0.0

    # 2-D cross product (B − A) × (P − A)
    cross = (bx - ax) * (py - ay) - (by - ay) * (px - ax)
    return cross / seg_len


# =============================================================================
# 2. Path interrogation
# =============================================================================

def path_length(path: Path) -> float:
    """
    Total arc length of a path (sum of consecutive segment lengths).

    Parameters
    ----------
    path : Path
        Ordered list of world-frame waypoints.

    Returns
    -------
    float
        Total length in metres.  Returns 0.0 for paths with fewer than 2 points.
    """
    if len(path) < 2:
        return 0.0
    return sum(
        euclidean_distance(path[i], path[i + 1])
        for i in range(len(path) - 1)
    )


def turning_angles(path: Path) -> List[float]:
    """
    Return the signed turning angle (radians) at every interior waypoint.

    The list has len(path) − 2 elements (no angles at the start or end).

    Parameters
    ----------
    path : Path
        Ordered list of world-frame waypoints.

    Returns
    -------
    List[float]
        Signed turning angles at interior waypoints [1 … len−2].
        An empty list is returned for paths with fewer than 3 points.
    """
    if len(path) < 3:
        return []
    return [
        angle_between(path[i - 1], path[i], path[i + 1])
        for i in range(1, len(path) - 1)
    ]


def path_curvature(path: Path) -> List[float]:
    """
    Approximate discrete curvature at every interior waypoint.

    Curvature κ ≈ |turning_angle| / average_segment_length at that vertex.
    Units: radians per metre.

    Parameters
    ----------
    path : Path
        Ordered list of world-frame waypoints (must have ≥ 3 points).

    Returns
    -------
    List[float]
        Curvature (rad/m) at interior waypoints.  Empty for short paths.
    """
    if len(path) < 3:
        return []

    curvatures: List[float] = []
    for i in range(1, len(path) - 1):
        d_prev = euclidean_distance(path[i - 1], path[i])
        d_next = euclidean_distance(path[i],     path[i + 1])
        avg_d  = (d_prev + d_next) * 0.5
        turn   = abs(angle_between(path[i - 1], path[i], path[i + 1]))
        curvatures.append(turn / avg_d if avg_d > 1e-9 else 0.0)

    return curvatures


def closest_point_on_segment(
    p: WorldPt,
    seg_start: WorldPt,
    seg_end: WorldPt,
) -> Tuple[WorldPt, float]:
    """
    Project point *p* onto the line segment *seg_start* → *seg_end*.

    Returns the closest point on the (finite) segment and the parameter
    t ∈ [0, 1] that describes where along the segment it lies.

    Parameters
    ----------
    p         : WorldPt — query point.
    seg_start : WorldPt — segment start.
    seg_end   : WorldPt — segment end.

    Returns
    -------
    (closest_pt, t) :
        closest_pt — world coordinates of the projection (clamped to segment).
        t          — scalar ∈ [0.0, 1.0]; 0 → seg_start, 1 → seg_end.
    """
    ax, ay = seg_start
    bx, by = seg_end
    px, py = p

    dx, dy = bx - ax, by - ay
    seg_len_sq = dx * dx + dy * dy

    if seg_len_sq < 1e-12:
        return seg_start, 0.0

    t = ((px - ax) * dx + (py - ay) * dy) / seg_len_sq
    t = max(0.0, min(1.0, t))
    return (ax + t * dx, ay + t * dy), t


def closest_waypoint_index(robot: WorldPt, path: Path) -> int:
    """
    Return the index of the waypoint in *path* that is nearest to *robot*.

    Scans the entire path, so O(N).  For real-time use, consider maintaining
    a cursor and searching only a forward window.

    Parameters
    ----------
    robot : WorldPt — current robot position.
    path  : Path    — ordered waypoints.

    Returns
    -------
    int
        Index of the nearest waypoint (0-based).  Returns 0 for empty paths.
    """
    if not path:
        return 0
    best_idx = 0
    best_d   = math.inf
    for i, wp in enumerate(path):
        d = euclidean_distance(robot, wp)
        if d < best_d:
            best_d   = d
            best_idx = i
    return best_idx


def lookahead_point(
    robot: WorldPt,
    path: Path,
    lookahead_dist: float,
    start_index: int = 0,
) -> Tuple[WorldPt, int]:
    """
    Pure-pursuit lookahead: find the point on *path* that is exactly
    *lookahead_dist* metres ahead of *robot* along the path arc.

    Algorithm
    ---------
    1. Starting from *start_index*, project *robot* onto each segment in turn.
    2. Walk forward along the path until accumulated arc length ≥ lookahead_dist.
    3. Interpolate linearly within the straddling segment to get the exact point.
    4. If the remaining path length is shorter than *lookahead_dist*, return the
       final waypoint so the robot continues driving toward the goal.

    Parameters
    ----------
    robot          : WorldPt — current robot position in world frame.
    path           : Path    — ordered waypoints produced by AStarPlanner.
    lookahead_dist : float   — desired look-ahead distance in metres (> 0).
    start_index    : int     — start searching from this waypoint index
                               (avoids re-scanning already-passed segments).

    Returns
    -------
    (target_pt, segment_index) :
        target_pt     — world point to steer toward.
        segment_index — index of the segment that contains *target_pt*.
                        Callers should update their cursor to this value.

    Notes
    -----
    * If *path* is empty or has only one point the robot position itself is
      returned so the caller can detect arrival and stop.
    * lookahead_dist should be at least one grid resolution (0.2 m) larger than
      the goal_tolerance used by the robot PID to guarantee smooth convergence.
    """
    if not path:
        return robot, 0
    if len(path) == 1:
        return path[0], 0

    n = len(path)
    idx = max(0, min(start_index, n - 2))

    # Project the robot onto the nearest segment starting from idx
    remaining = lookahead_dist

    for i in range(idx, n - 1):
        seg_len = euclidean_distance(path[i], path[i + 1])
        if seg_len < 1e-9:
            continue

        if remaining <= seg_len:
            # Interpolate within this segment
            t  = remaining / seg_len
            pt = (
                path[i][0] + t * (path[i + 1][0] - path[i][0]),
                path[i][1] + t * (path[i + 1][1] - path[i][1]),
            )
            return pt, i

        remaining -= seg_len

    # Lookahead overshot the end of path — return the final waypoint
    return path[-1], n - 2


def path_arc_distance(
    path: Path,
    from_idx: int,
    to_idx: int,
) -> float:
    """
    Arc length along *path* between waypoint indices *from_idx* and *to_idx*.

    Parameters
    ----------
    path     : Path — ordered waypoints.
    from_idx : int  — start index (inclusive).
    to_idx   : int  — end index (inclusive).

    Returns
    -------
    float
        Arc length in metres.  Returns 0.0 if from_idx ≥ to_idx.
    """
    if from_idx >= to_idx or len(path) < 2:
        return 0.0
    from_idx = max(0, from_idx)
    to_idx   = min(len(path) - 1, to_idx)
    return sum(
        euclidean_distance(path[i], path[i + 1])
        for i in range(from_idx, to_idx)
    )


# =============================================================================
# 3. Path transformation
# =============================================================================

def interpolate_path(path: Path, step: float) -> Path:
    """
    Re-sample *path* at uniform arc-length intervals of *step* metres.

    The first and last waypoints are always preserved exactly.  Intermediate
    points are linearly interpolated along each segment so that consecutive
    output waypoints are approximately *step* metres apart.

    Typical use: convert a coarse A*-smoothed path (waypoints every 0.4–1.0 m)
    to a denser sequence for the robot PID controller or for collision checks.

    Parameters
    ----------
    path : Path  — source waypoints (≥ 1 point).
    step : float — desired sample spacing in metres (must be > 0).

    Returns
    -------
    Path
        Re-sampled path.  Returns a copy of *path* unchanged if it has fewer
        than 2 points or if *step* ≤ 0.
    """
    if len(path) < 2 or step <= 0:
        return list(path)

    out: Path = [path[0]]
    accumulated = 0.0

    for i in range(len(path) - 1):
        seg_start = path[i]
        seg_end   = path[i + 1]
        seg_len   = euclidean_distance(seg_start, seg_end)
        if seg_len < 1e-9:
            continue

        # How far along this segment do we have left until the next sample?
        dist_until_next = step - accumulated
        t_step = dist_until_next / seg_len

        t = t_step
        while t < 1.0 - 1e-9:
            px = seg_start[0] + t * (seg_end[0] - seg_start[0])
            py = seg_start[1] + t * (seg_end[1] - seg_start[1])
            out.append((px, py))
            t += step / seg_len

        # Carry forward the overshoot into the next segment
        accumulated = (1.0 - (t - step / seg_len)) * seg_len
        accumulated = accumulated % step  # wrap cleanly

    # Always include the final waypoint
    if euclidean_distance(out[-1], path[-1]) > 1e-9:
        out.append(path[-1])

    return out


def trim_path_to_distance(path: Path, max_dist: float) -> Path:
    """
    Truncate *path* so that its total arc length does not exceed *max_dist*.

    Useful when re-planning: the robot navigates only the near portion of
    its path and expects an updated plan for the rest.

    Parameters
    ----------
    path     : Path  — source waypoints.
    max_dist : float — maximum allowed arc length in metres (> 0).

    Returns
    -------
    Path
        Truncated path.  The last point is linearly interpolated to land
        exactly at *max_dist* from the start.  Returns a full copy if
        path_length(path) ≤ max_dist.
    """
    if not path or max_dist <= 0:
        return []
    if len(path) == 1:
        return [path[0]]

    out: Path = [path[0]]
    remaining = max_dist

    for i in range(len(path) - 1):
        seg_len = euclidean_distance(path[i], path[i + 1])
        if seg_len < 1e-9:
            out.append(path[i + 1])
            continue
        if seg_len >= remaining:
            t  = remaining / seg_len
            px = path[i][0] + t * (path[i + 1][0] - path[i][0])
            py = path[i][1] + t * (path[i + 1][1] - path[i][1])
            out.append((px, py))
            return out
        remaining -= seg_len
        out.append(path[i + 1])

    return out


def subsample_path(path: Path, keep_every: int = 2) -> Path:
    """
    Return a sub-sampled path by keeping every *keep_every*-th waypoint.

    The first and last waypoints are always kept so the goal pose is preserved.
    This is a lightweight alternative to interpolate_path when the caller just
    needs to reduce publisher bandwidth or RViz marker counts.

    Parameters
    ----------
    path       : Path — source waypoints.
    keep_every : int  — stride; default 2 halves the waypoint count.

    Returns
    -------
    Path
        Sub-sampled path.
    """
    if len(path) <= 2 or keep_every <= 1:
        return list(path)
    indices = list(range(0, len(path), keep_every))
    if indices[-1] != len(path) - 1:
        indices.append(len(path) - 1)
    return [path[i] for i in indices]


def reverse_path(path: Path) -> Path:
    """
    Return a reversed copy of *path*.

    Useful when a robot needs to back-track along a previously computed
    outbound route (e.g., shelf access → staging area).

    Parameters
    ----------
    path : Path — source waypoints.

    Returns
    -------
    Path
        New list with waypoints in reverse order.
    """
    return list(reversed(path))


def offset_path(path: Path, lateral_offset: float) -> Path:
    """
    Shift every waypoint in *path* perpendicularly by *lateral_offset* metres.

    Positive offset shifts the path to the left of the direction of travel
    (port side in maritime convention); negative shifts to the right.

    This is used by the fleet manager to separate planned routes of robots
    travelling in the same aisle, reducing the probability of head-on
    conflicts and allowing narrower safety margins.

    Algorithm: at each waypoint, compute the average of the inbound and
    outbound normal vectors and shift by *lateral_offset* along that normal.
    For the first and last points, only the single available segment normal
    is used.

    Parameters
    ----------
    path           : Path  — source waypoints (≥ 2 points).
    lateral_offset : float — perpendicular shift in metres.
                             Positive = left, negative = right.

    Returns
    -------
    Path
        New path shifted laterally.  Returns a copy unchanged if len < 2.

    Warnings
    --------
    This does *not* check whether shifted points land inside obstacles.
    Always validate with path_clears_obstacle() before using the result.
    """
    if len(path) < 2:
        return list(path)

    def _normal(a: WorldPt, b: WorldPt) -> Tuple[float, float]:
        """Left-hand unit normal of direction a→b."""
        dx, dy = b[0] - a[0], b[1] - a[1]
        length = math.hypot(dx, dy)
        if length < 1e-9:
            return (0.0, 0.0)
        # Rotate 90° CCW: (dx, dy) → (−dy, dx)
        return (-dy / length, dx / length)

    n = len(path)
    shifted: Path = []

    for i in range(n):
        if i == 0:
            nx, ny = _normal(path[0], path[1])
        elif i == n - 1:
            nx, ny = _normal(path[-2], path[-1])
        else:
            n1x, n1y = _normal(path[i - 1], path[i])
            n2x, n2y = _normal(path[i],     path[i + 1])
            # Average and re-normalise
            avg_x = (n1x + n2x) * 0.5
            avg_y = (n1y + n2y) * 0.5
            avg_len = math.hypot(avg_x, avg_y)
            if avg_len < 1e-9:
                nx, ny = n1x, n1y
            else:
                nx, ny = avg_x / avg_len, avg_y / avg_len

        shifted.append((
            path[i][0] + nx * lateral_offset,
            path[i][1] + ny * lateral_offset,
        ))

    return shifted


# =============================================================================
# 4. Path validation
# =============================================================================

# World bounds mirrors WarehouseGrid constants
_MAP_X_MIN: float = -10.0
_MAP_X_MAX: float =  10.0
_MAP_Y_MIN: float = -10.0
_MAP_Y_MAX: float =  10.0


def path_within_bounds(path: Path) -> bool:
    """
    Return True if every waypoint in *path* lies within the warehouse boundary.

    Checks against the hard walls at x ∈ [−10.0, 10.0] and y ∈ [−10.0, 10.0]
    (sourced from WarehouseGrid.MAP_X/Y_MIN/MAX).

    Parameters
    ----------
    path : Path — waypoints to validate.

    Returns
    -------
    bool
        True if all points are within bounds; False if any is outside.
    """
    for x, y in path:
        if not (_MAP_X_MIN <= x <= _MAP_X_MAX and _MAP_Y_MIN <= y <= _MAP_Y_MAX):
            return False
    return True


def segment_intersects_circle(
    seg_start: WorldPt,
    seg_end: WorldPt,
    centre: WorldPt,
    radius: float,
) -> bool:
    """
    Return True if the finite line segment *seg_start* → *seg_end* passes
    within *radius* metres of *centre*.

    Uses the closest-point projection to test minimum distance from the
    segment to the circle centre — O(1), branch-free.

    Parameters
    ----------
    seg_start : WorldPt — segment start.
    seg_end   : WorldPt — segment end.
    centre    : WorldPt — circle centre.
    radius    : float   — circle radius in metres.

    Returns
    -------
    bool
        True if the segment intersects or is tangent to the circle.
    """
    closest, _ = closest_point_on_segment(centre, seg_start, seg_end)
    return euclidean_distance(closest, centre) <= radius


def path_clears_obstacle(
    path: Path,
    obstacle_centre: WorldPt,
    obstacle_radius: float,
) -> bool:
    """
    Return True if *path* keeps at least *obstacle_radius* metres from a
    circular obstacle at *obstacle_centre*.

    Checks every path segment individually; a path is considered clear only
    if all segments clear the obstacle.

    Parameters
    ----------
    path             : Path     — ordered waypoints.
    obstacle_centre  : WorldPt  — obstacle position in world frame.
    obstacle_radius  : float    — exclusion radius in metres.

    Returns
    -------
    bool
        True if the entire path clears the obstacle; False if any segment
        passes within *obstacle_radius* of the centre.
    """
    if len(path) < 2:
        return True
    for i in range(len(path) - 1):
        if segment_intersects_circle(path[i], path[i + 1],
                                     obstacle_centre, obstacle_radius):
            return False
    return True


def path_min_clearance(
    path: Path,
    obstacle_centres: Sequence[WorldPt],
    sample_step: float = 0.1,
) -> float:
    """
    Compute the minimum clearance (metres) between any point on *path* and
    the nearest obstacle centre in *obstacle_centres*.

    Points along each segment are sampled every *sample_step* metres so that
    the check is not purely vertex-based.

    Parameters
    ----------
    path             : Path              — ordered waypoints.
    obstacle_centres : Sequence[WorldPt] — list of obstacle world positions.
    sample_step      : float             — sampling resolution in metres.

    Returns
    -------
    float
        Minimum distance in metres.  Returns math.inf for empty inputs.
    """
    if not path or not obstacle_centres:
        return math.inf

    min_d = math.inf
    dense = interpolate_path(path, sample_step)
    for pt in dense:
        for obs in obstacle_centres:
            d = euclidean_distance(pt, obs)
            if d < min_d:
                min_d = d
    return min_d


# =============================================================================
# 5. Multi-robot conflict detection
# =============================================================================

def paths_conflict(
    path_a: Path,
    path_b: Path,
    safety_radius: float = 0.4,
) -> bool:
    """
    Return True if path_a and path_b pass within *safety_radius* metres of
    each other at any corresponding point along their arcs.

    This is a spatial check only (no timing information).  Both paths are
    re-sampled at *safety_radius / 2* resolution before comparison, so the
    result is conservative but not exact.

    For a time-aware check, use temporal_separation().

    Parameters
    ----------
    path_a, path_b : Path  — paths of two robots (world frame).
    safety_radius  : float — minimum allowed separation in metres
                             (default 0.4 m ≈ 2 × TurtleBot3 Burger half-width
                             + a small margin, matching collision_lookahead
                             parameter in multi_robot.launch.py).

    Returns
    -------
    bool
        True if any segment pair is within *safety_radius*.
    """
    if not path_a or not path_b:
        return False

    step = max(safety_radius * 0.5, 0.05)
    dense_a = interpolate_path(path_a, step)
    dense_b = interpolate_path(path_b, step)

    # Build a simple proximity test: for each point on path_b, check against
    # every point on path_a within a bounding scan.
    for pb in dense_b:
        for pa in dense_a:
            if euclidean_distance(pa, pb) < safety_radius:
                return True
    return False


def earliest_conflict_point(
    path_a: Path,
    path_b: Path,
    safety_radius: float = 0.4,
) -> Optional[Tuple[WorldPt, int, int]]:
    """
    Find the first location where *path_a* and *path_b* come within
    *safety_radius* of each other.

    Scans segment pairs in order; returns the conflict point on path_a,
    the segment index on path_a, and the segment index on path_b.

    Parameters
    ----------
    path_a, path_b : Path  — paths of two robots.
    safety_radius  : float — conflict threshold in metres.

    Returns
    -------
    Optional[Tuple[WorldPt, int, int]]
        (conflict_world_point, idx_a, idx_b) or None if no conflict exists.
        conflict_world_point is the mid-point of the two conflicting points.
    """
    if not path_a or not path_b:
        return None

    step    = max(safety_radius * 0.5, 0.05)
    dense_a = interpolate_path(path_a, step)
    dense_b = interpolate_path(path_b, step)

    # stride is step; map dense index back to original segment index
    def _seg_index(dense_idx: int, original_path: Path) -> int:
        """Approximate original segment index from dense index."""
        arc = dense_idx * step
        acc = 0.0
        for i in range(len(original_path) - 1):
            seg_len = euclidean_distance(original_path[i], original_path[i + 1])
            acc += seg_len
            if acc >= arc:
                return i
        return max(0, len(original_path) - 2)

    for j, pb in enumerate(dense_b):
        for i, pa in enumerate(dense_a):
            if euclidean_distance(pa, pb) < safety_radius:
                mid = ((pa[0] + pb[0]) * 0.5, (pa[1] + pb[1]) * 0.5)
                return mid, _seg_index(i, path_a), _seg_index(j, path_b)

    return None


def temporal_separation(
    path_a: Path,
    speed_a: float,
    path_b: Path,
    speed_b: float,
    time_step: float = 0.25,
    safety_radius: float = 0.4,
) -> Optional[float]:
    """
    Time-parameterised proximity check.

    Simulate both robots traversing their respective paths at constant
    speeds *speed_a* and *speed_b*, and return the earliest simulated time
    (seconds) at which they come within *safety_radius* metres of each other.

    Returns None if the robots never come within *safety_radius* of each other
    over the full duration of both paths.

    This is used by the fleet manager to detect imminent conflicts before they
    reach the collision-avoidance layer, so it can delay dispatch or request
    a path re-plan while there is still safe separation.

    Parameters
    ----------
    path_a, path_b : Path  — planned paths for each robot (world frame).
    speed_a        : float — average travel speed of robot A (m/s).
    speed_b        : float — average travel speed of robot B (m/s).
    time_step      : float — simulation time increment in seconds (default 0.25 s).
    safety_radius  : float — conflict distance threshold in metres.

    Returns
    -------
    Optional[float]
        Earliest conflict time in seconds, or None if paths are temporally safe.
    """
    if not path_a or not path_b or speed_a <= 0 or speed_b <= 0:
        return None

    len_a = path_length(path_a)
    len_b = path_length(path_b)

    duration = max(len_a / speed_a, len_b / speed_b)
    t = 0.0

    while t <= duration:
        dist_a = min(speed_a * t, len_a)
        dist_b = min(speed_b * t, len_b)

        pos_a = _position_at_arc(path_a, dist_a)
        pos_b = _position_at_arc(path_b, dist_b)

        if euclidean_distance(pos_a, pos_b) < safety_radius:
            return t

        t += time_step

    return None


def _position_at_arc(path: Path, arc_dist: float) -> WorldPt:
    """
    Internal helper: return the world position at *arc_dist* metres along *path*.

    Linearly interpolates within the straddling segment.  If *arc_dist* exceeds
    the total path length, the final waypoint is returned.
    """
    if not path:
        return (0.0, 0.0)
    if len(path) == 1 or arc_dist <= 0.0:
        return path[0]

    remaining = arc_dist
    for i in range(len(path) - 1):
        seg_len = euclidean_distance(path[i], path[i + 1])
        if seg_len < 1e-9:
            continue
        if remaining <= seg_len:
            t  = remaining / seg_len
            return (
                path[i][0] + t * (path[i + 1][0] - path[i][0]),
                path[i][1] + t * (path[i + 1][1] - path[i][1]),
            )
        remaining -= seg_len

    return path[-1]


# =============================================================================
# 6. Named-pose helpers
# =============================================================================

# ---------------------------------------------------------------------------
# Named locations  (sourced from astar_planner.py constants and
# multi_robot.launch.py parameter values — kept in sync manually)
# ---------------------------------------------------------------------------

#: Charging pad world positions; index matches robot_id − 1.
CHARGING_PADS: List[WorldPt] = [
    (-8.0,  0.0),   # pad_1  →  robot_1 home
    (-8.0, -1.0),   # pad_2  →  robot_2 home
    (-8.0, -2.0),   # pad_3  →  robot_3 home
]

#: Dispatch staging zone (matches multi_robot.launch.py dispatch_pose).
DISPATCH_POSE: WorldPt = (-4.0, -8.5)

#: Receiving staging zone (matches multi_robot.launch.py receiving_pose).
RECEIVING_POSE: WorldPt = ( 4.0, -8.5)

#: Shelf access aisles (world frame, 0.8 m clear of shelf board edge).
#: Keys match AStarPlanner.SHELF_ACCESS exactly.
SHELF_ACCESS: Dict[str, WorldPt] = {
    # Row A — access from south
    "A1": (-7.5,  4.5),
    "A2": (-5.5,  4.5),
    "A3": (-3.5,  4.5),
    # Row B — access from south
    "B1": ( 3.5,  4.5),
    "B2": ( 5.5,  4.5),
    "B3": ( 7.5,  4.5),
    # Row C — access from north
    "C1": (-7.5, -4.5),
    "C2": (-5.5, -4.5),
    "C3": (-3.5, -4.5),
    # Row D — access from north
    "D1": ( 3.5, -4.5),
    "D2": ( 5.5, -4.5),
    "D3": ( 7.5, -4.5),
}


def nearest_charging_pad(robot: WorldPt) -> Tuple[WorldPt, int]:
    """
    Return the closest charging pad to *robot* and its 1-based robot_id.

    The assignment is by Euclidean distance to pad centre only — it does not
    account for whether the pad is already occupied.  The fleet manager should
    check robot states before calling this if pad exclusivity matters.

    Parameters
    ----------
    robot : WorldPt — current robot position.

    Returns
    -------
    (pad_position, robot_id) :
        pad_position — world coordinates of the nearest pad.
        robot_id     — 1-based index matching multi_robot.launch.py pad numbering.
    """
    best_idx = 0
    best_d   = math.inf
    for i, pad in enumerate(CHARGING_PADS):
        d = euclidean_distance(robot, pad)
        if d < best_d:
            best_d   = d
            best_idx = i
    return CHARGING_PADS[best_idx], best_idx + 1


def nearest_shelf_access(robot: WorldPt) -> Tuple[str, WorldPt]:
    """
    Return the label and world position of the shelf access point nearest to *robot*.

    Parameters
    ----------
    robot : WorldPt — current robot position.

    Returns
    -------
    (shelf_label, access_point) :
        shelf_label  — e.g. "A1", "C3".
        access_point — world coordinates of the access aisle point.
    """
    best_label = ""
    best_pt: WorldPt = (0.0, 0.0)
    best_d = math.inf

    for label, pt in SHELF_ACCESS.items():
        d = euclidean_distance(robot, pt)
        if d < best_d:
            best_d     = d
            best_label = label
            best_pt    = pt

    return best_label, best_pt


def pose_near_named_location(
    pose: WorldPt,
    location_name: str,
    tolerance: float = 0.30,
) -> bool:
    """
    Return True if *pose* is within *tolerance* metres of a named location.

    Recognised location names
    -------------------------
    ``"dispatch"``        → DISPATCH_POSE
    ``"receiving"``       → RECEIVING_POSE
    ``"charging_1"`` …
    ``"charging_3"``      → CHARGING_PADS[0..2]
    ``"A1"`` … ``"D3"``  → SHELF_ACCESS entries

    Parameters
    ----------
    pose          : WorldPt — robot or goal world position.
    location_name : str     — case-insensitive location identifier.
    tolerance     : float   — maximum distance to be considered "near" (metres).

    Returns
    -------
    bool
        True if *pose* is within *tolerance* of the named location.

    Raises
    ------
    KeyError
        If *location_name* is not recognised.
    """
    key = location_name.strip().lower()

    if key == "dispatch":
        ref = DISPATCH_POSE
    elif key == "receiving":
        ref = RECEIVING_POSE
    elif key == "charging_1":
        ref = CHARGING_PADS[0]
    elif key == "charging_2":
        ref = CHARGING_PADS[1]
    elif key == "charging_3":
        ref = CHARGING_PADS[2]
    else:
        upper = key.upper()
        if upper in SHELF_ACCESS:
            ref = SHELF_ACCESS[upper]
        else:
            raise KeyError(
                f"Unknown named location: '{location_name}'. "
                f"Valid choices: dispatch, receiving, charging_1..3, "
                f"{', '.join(sorted(SHELF_ACCESS))}."
            )

    return euclidean_distance(pose, ref) <= tolerance


# =============================================================================
# Module self-test  (python -m navigation.path_utils)
# =============================================================================

if __name__ == "__main__":  # pragma: no cover
    import sys

    def _approx(a: float, b: float, tol: float = 1e-6) -> bool:
        return abs(a - b) < tol

    errors = 0

    # --- normalise_angle ---
    assert _approx(normalise_angle(0.0), 0.0),        "normalise_angle(0)"
    assert _approx(normalise_angle(math.pi), math.pi), "normalise_angle(π)"
    assert _approx(normalise_angle(3 * math.pi), math.pi, 1e-5), "normalise_angle(3π)"
    assert _approx(normalise_angle(-math.pi / 2), -math.pi / 2), "normalise_angle(-π/2)"

    # --- euclidean_distance ---
    assert _approx(euclidean_distance((0.0, 0.0), (3.0, 4.0)), 5.0), "distance 3-4-5"
    assert _approx(euclidean_distance((1.0, 1.0), (1.0, 1.0)), 0.0), "distance self"

    # --- heading_to ---
    assert _approx(heading_to((0.0, 0.0), (1.0, 0.0)), 0.0),       "heading east"
    assert _approx(heading_to((0.0, 0.0), (0.0, 1.0)), math.pi / 2), "heading north"

    # --- path_length ---
    p = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0)]
    assert _approx(path_length(p), 2.0), "path_length L-shape"
    assert _approx(path_length([]), 0.0), "path_length empty"

    # --- lookahead_point ---
    straight = [(float(i), 0.0) for i in range(10)]
    lp, seg_idx = lookahead_point((0.0, 0.0), straight, 3.5)
    assert _approx(lp[0], 3.5, 1e-3), f"lookahead x expected 3.5 got {lp[0]}"

    # --- interpolate_path ---
    line = [(0.0, 0.0), (10.0, 0.0)]
    interp = interpolate_path(line, 1.0)
    assert len(interp) >= 10, f"interpolate_path got {len(interp)} points"
    assert _approx(interp[-1][0], 10.0, 1e-3), "interpolate_path end preserved"

    # --- trim_path_to_distance ---
    trimmed = trim_path_to_distance([(0.0, 0.0), (10.0, 0.0)], 4.0)
    assert _approx(trimmed[-1][0], 4.0), f"trim_path end x expected 4.0 got {trimmed[-1]}"

    # --- cross_track_error ---
    xte = cross_track_error((1.0, 1.0), (0.0, 0.0), (2.0, 0.0))
    assert _approx(xte, -1.0), f"cross_track_error expected -1.0 got {xte}"  # right of travel

    # --- nearest_charging_pad ---
    pad, rid = nearest_charging_pad((-8.0, -1.5))
    assert rid == 2, f"nearest pad expected robot_id=2 got {rid}"

    # --- pose_near_named_location ---
    assert pose_near_named_location((-8.0, 0.0), "charging_1", 0.1)
    assert not pose_near_named_location((0.0, 0.0), "charging_1", 0.1)
    assert pose_near_named_location((-4.0, -8.5), "dispatch", 0.05)

    # --- segment_intersects_circle ---
    assert segment_intersects_circle((0.0, 0.0), (4.0, 0.0), (2.0, 0.3), 0.4)
    assert not segment_intersects_circle((0.0, 0.0), (4.0, 0.0), (2.0, 1.5), 0.4)

    # --- paths_conflict ---
    pa = [(0.0, y) for y in range(10)]
    pb = [(0.1, y) for y in range(10)]    # very close, should conflict
    assert paths_conflict(pa, pb, safety_radius=0.5)

    pb_far = [(5.0, y) for y in range(10)]
    assert not paths_conflict(pa, pb_far, safety_radius=0.5)

    print(f"[path_utils] All self-tests passed.  errors={errors}")
    sys.exit(errors)
