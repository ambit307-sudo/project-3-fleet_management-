#!/usr/bin/env python3
# =============================================================================
# simulation/multi_robot.launch.py
# =============================================================================
# Brings up the full Fleet Management simulation stack:
#
#   1. Gazebo Classic with warehouse.world
#   2. Three TurtleBot3 Burger robots (each in its own namespace)
#        /robot_1  →  spawn @ (-8.0,  0.0, 0.05)  yaw=0.0
#        /robot_2  →  spawn @ (-8.0, -1.0, 0.05)  yaw=0.0
#        /robot_3  →  spawn @ (-8.0, -2.0, 0.05)  yaw=0.0
#   3. Per-robot nodes
#        • robot_state_publisher  (URDF → /tf)
#        • joint_state_publisher
#        • static_transform_publisher  (world → odom bootstrap)
#   4. Fleet-level nodes
#        • fleet_manager          (fleet_management pkg)
#        • rviz2                  (multi-robot config)
#
# Usage
# -----
#   export TURTLEBOT3_MODEL=burger
#   ros2 launch fleet_management multi_robot.launch.py
#
# Optional arguments
# ------------------
#   use_sim_time  : bool   (default true)
#   rviz          : bool   (default true)
#   world         : path   (default <pkg>/simulation/warehouse.world)
#   gui           : bool   (default true)  — show Gazebo GUI
# =============================================================================

import os
from pathlib import Path

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    ExecuteProcess,
    GroupAction,
    IncludeLaunchDescription,
    LogInfo,
    RegisterEventHandler,
    TimerAction,
)
from launch.conditions import IfCondition
from launch.event_handlers import OnProcessStart, OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import (
    Command,
    FindExecutable,
    LaunchConfiguration,
    PathJoinSubstitution,
    PythonExpression,
)
from launch_ros.actions import Node, PushRosNamespace
from launch_ros.substitutions import FindPackageShare


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _robot_urdf(robot_namespace: str, x: float, y: float, yaw: float):
    """
    Return the xacro command substitution that produces a TurtleBot3 URDF
    with the correct namespace and initial tf-prefix baked in.
    """
    tb3_description_pkg = get_package_share_directory("turtlebot3_description")
    urdf_path = os.path.join(
        tb3_description_pkg, "urdf", "turtlebot3_burger.urdf"
    )
    # Use xacro if available, else fall back to plain URDF
    if os.path.exists(urdf_path.replace(".urdf", ".urdf.xacro")):
        urdf_path = urdf_path.replace(".urdf", ".urdf.xacro")

    return Command(
        [
            FindExecutable(name="xacro"),
            " ",
            urdf_path,
            " namespace:=",
            robot_namespace,
        ]
    )


def _spawn_robot_group(
    robot_id: int,
    x: float,
    y: float,
    z: float,
    yaw: float,
    use_sim_time: LaunchConfiguration,
) -> GroupAction:
    """
    Build a GroupAction that:
      • pushes namespace /robot_<id>
      • starts robot_state_publisher
      • starts joint_state_publisher
      • spawns the robot model in Gazebo
      • publishes the static world→odom transform
    """
    ns = f"robot_{robot_id}"
    entity_name = ns  # Gazebo model name

    tb3_description = get_package_share_directory("turtlebot3_description")
    urdf_file = os.path.join(
        tb3_description, "urdf", "turtlebot3_burger.urdf"
    )
    # Prefer xacro source when present
    xacro_file = urdf_file.replace(".urdf", ".urdf.xacro")
    if os.path.exists(xacro_file):
        robot_description_content = Command(
            [
                FindExecutable(name="xacro"),
                " ",
                xacro_file,
                " namespace:=",
                ns,
            ]
        )
    else:
        with open(urdf_file, "r") as fh:
            robot_description_content = fh.read()

    robot_description = {"robot_description": robot_description_content}

    return GroupAction(
        actions=[
            # ── Push namespace so every node inside is namespaced ──────
            PushRosNamespace(ns),

            # ── robot_state_publisher ──────────────────────────────────
            Node(
                package="robot_state_publisher",
                executable="robot_state_publisher",
                name="robot_state_publisher",
                output="screen",
                parameters=[
                    robot_description,
                    {
                        "use_sim_time": use_sim_time,
                        "frame_prefix": ns + "/",
                    },
                ],
                remappings=[
                    ("/tf", "tf"),
                    ("/tf_static", "tf_static"),
                ],
            ),

            # ── joint_state_publisher ──────────────────────────────────
            Node(
                package="joint_state_publisher",
                executable="joint_state_publisher",
                name="joint_state_publisher",
                output="screen",
                parameters=[{"use_sim_time": use_sim_time}],
            ),

            # ── Static TF: world → <ns>/odom (bootstrap before odometry)
            Node(
                package="tf2_ros",
                executable="static_transform_publisher",
                name="static_tf_world_odom",
                output="screen",
                arguments=[
                    str(x), str(y), str(z),   # translation
                    str(yaw), "0.0", "0.0",    # yaw, pitch, roll
                    "world",                   # parent frame
                    ns + "/odom",              # child frame
                ],
                parameters=[{"use_sim_time": use_sim_time}],
            ),

            # ── Spawn entity in Gazebo ─────────────────────────────────
            Node(
                package="gazebo_ros",
                executable="spawn_entity.py",
                name=f"spawn_{ns}",
                output="screen",
                arguments=[
                    "-topic", "robot_description",
                    "-entity", entity_name,
                    "-robot_namespace", ns,
                    "-x", str(x),
                    "-y", str(y),
                    "-z", str(z),
                    "-Y", str(yaw),
                ],
            ),
        ]
    )


# ---------------------------------------------------------------------------
# generate_launch_description
# ---------------------------------------------------------------------------

def generate_launch_description():

    # ── Package paths ──────────────────────────────────────────────────────
    fleet_pkg_share = get_package_share_directory("fleet_management")
    gazebo_ros_pkg   = get_package_share_directory("gazebo_ros")

    default_world = os.path.join(
        fleet_pkg_share, "simulation", "warehouse.world"
    )
    default_rviz_config = os.path.join(
        fleet_pkg_share, "rviz", "multi_robot.rviz"
    )

    # ── Launch arguments ───────────────────────────────────────────────────
    arg_use_sim_time = DeclareLaunchArgument(
        "use_sim_time",
        default_value="true",
        description="Use /clock from Gazebo as ROS time source",
    )
    arg_world = DeclareLaunchArgument(
        "world",
        default_value=default_world,
        description="Absolute path to the Gazebo .world file",
    )
    arg_gui = DeclareLaunchArgument(
        "gui",
        default_value="true",
        description="Launch the Gazebo client GUI",
    )
    arg_rviz = DeclareLaunchArgument(
        "rviz",
        default_value="true",
        description="Launch RViz2 for multi-robot visualisation",
    )
    arg_verbose = DeclareLaunchArgument(
        "verbose",
        default_value="false",
        description="Enable verbose Gazebo output",
    )

    # ── LaunchConfiguration handles ───────────────────────────────────────
    use_sim_time = LaunchConfiguration("use_sim_time")
    world        = LaunchConfiguration("world")
    gui          = LaunchConfiguration("gui")
    rviz         = LaunchConfiguration("rviz")
    verbose      = LaunchConfiguration("verbose")

    # ── Gazebo server (gzserver) ───────────────────────────────────────────
    gazebo_server = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_ros_pkg, "launch", "gzserver.launch.py")
        ),
        launch_arguments={
            "world":   world,
            "verbose": verbose,
            "pause":   "false",
        }.items(),
    )

    # ── Gazebo client (gzclient) — conditional on `gui` arg ───────────────
    gazebo_client = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(gazebo_ros_pkg, "launch", "gzclient.launch.py")
        ),
        condition=IfCondition(gui),
    )

    # ── Robot spawn groups ────────────────────────────────────────────────
    # Positions align with the three charging pads defined in warehouse.world
    #   pad_1 centre: (-8.0,  0.0)
    #   pad_2 centre: (-8.0, -1.0)
    #   pad_3 centre: (-8.0, -2.0)
    robot_1_group = _spawn_robot_group(
        robot_id=1, x=-8.0, y=0.0,  z=0.05, yaw=0.0,
        use_sim_time=use_sim_time,
    )
    robot_2_group = _spawn_robot_group(
        robot_id=2, x=-8.0, y=-1.0, z=0.05, yaw=0.0,
        use_sim_time=use_sim_time,
    )
    robot_3_group = _spawn_robot_group(
        robot_id=3, x=-8.0, y=-2.0, z=0.05, yaw=0.0,
        use_sim_time=use_sim_time,
    )

    # ── Fleet Manager node ─────────────────────────────────────────────────
    fleet_manager_node = Node(
        package="fleet_management",
        executable="fleet_manager",
        name="fleet_manager",
        output="screen",
        parameters=[
            {
                "use_sim_time": use_sim_time,
                # Robot namespaces the manager will supervise
                "robot_namespaces": ["robot_1", "robot_2", "robot_3"],
                # Warehouse grid resolution (metres per cell) for A*
                "grid_resolution": 0.2,
                # Warehouse bounds (must match warehouse.world floor)
                "map_width":  20.0,
                "map_height": 20.0,
                # Collision avoidance lookahead distance (metres)
                "collision_lookahead": 0.5,
                # Task re-assignment timeout (seconds)
                "task_timeout": 30.0,
                # Charging positions (must match pad poses in world file)
                "charging_positions": [
                    -8.0, 0.0,
                    -8.0, -1.0,
                    -8.0, -2.0,
                ],
                # Named goal poses  [x, y, yaw]
                "dispatch_pose":   [-4.0, -8.5, 0.0],
                "receiving_pose":  [ 4.0, -8.5, 0.0],
            }
        ],
        remappings=[
            ("/tf",        "tf"),
            ("/tf_static", "tf_static"),
        ],
    )

    # ── RViz2 ─────────────────────────────────────────────────────────────
    rviz_node = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2",
        output="screen",
        arguments=["-d", default_rviz_config],
        parameters=[{"use_sim_time": use_sim_time}],
        condition=IfCondition(rviz),
    )

    # ── Stagger robot spawns to avoid Gazebo service race conditions ───────
    # robot_1 spawns immediately after Gazebo is ready;
    # robot_2 and robot_3 are delayed by 3 s and 6 s respectively.
    delayed_robot_2 = TimerAction(period=3.0,  actions=[robot_2_group])
    delayed_robot_3 = TimerAction(period=6.0,  actions=[robot_3_group])
    # Fleet manager starts after all robots are expected to be spawned
    delayed_fleet   = TimerAction(period=10.0, actions=[fleet_manager_node])
    # RViz starts last (cosmetic, not safety-critical)
    delayed_rviz    = TimerAction(period=11.0, actions=[rviz_node])

    # ── Log messages for operator feedback ────────────────────────────────
    log_start = LogInfo(msg="[fleet_launch] Starting warehouse simulation...")
    log_robots = LogInfo(
        msg="[fleet_launch] Spawning robots: robot_1 now, robot_2 in 3 s, robot_3 in 6 s"
    )
    log_fleet = LogInfo(
        msg="[fleet_launch] Fleet manager will start in 10 s"
    )

    # ── Assemble LaunchDescription ─────────────────────────────────────────
    return LaunchDescription(
        [
            # Declare arguments first
            arg_use_sim_time,
            arg_world,
            arg_gui,
            arg_rviz,
            arg_verbose,

            # Operator feedback
            log_start,
            log_robots,
            log_fleet,

            # Simulation
            gazebo_server,
            gazebo_client,

            # Robots (staggered)
            robot_1_group,
            delayed_robot_2,
            delayed_robot_3,

            # Fleet manager + RViz (delayed)
            delayed_fleet,
            delayed_rviz,
        ]
    )
