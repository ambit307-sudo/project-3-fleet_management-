# dashboard/data_provider.py

from datetime import datetime
from fleet_manager.robot_registry import RobotRegistry
from fleet_manager.task_allocator import TaskAllocator
from traffic_manager.reservation_table import ReservationTable


class DataProvider:
    """
    Provides real-time data for Dashboard.
    """

    def __init__(
        self,
        robot_registry: RobotRegistry,
        task_allocator: TaskAllocator,
        reservation_table: ReservationTable
    ):
        self.robot_registry = robot_registry
        self.task_allocator = task_allocator
        self.reservation_table = reservation_table

    def get_robot_data(self):
        robots = []

        for robot_id, robot in self.robot_registry.get_all_robots().items():
            robots.append({
                "robot_id": robot_id,
                "status": robot.get("status", "IDLE"),
                "position": robot.get("position", [0, 0]),
                "battery": robot.get("battery", 100),
                "current_task": robot.get("current_task", "None")
            })

        return robots

    def get_task_data(self):
        tasks = []

        for task in self.task_allocator.get_all_tasks():
            tasks.append({
                "task_id": task.get("task_id"),
                "assigned_robot": task.get("assigned_robot"),
                "status": task.get("status"),
                "pickup": task.get("pickup"),
                "dropoff": task.get("dropoff")
            })

        return tasks

    def get_reservation_data(self):
        reservations = []

        for reservation in self.reservation_table.get_all_reservations():
            reservations.append({
                "robot_id": reservation.get("robot_id"),
                "cell": reservation.get("cell"),
                "timestamp": reservation.get("timestamp")
            })

        return reservations

    def get_fleet_summary(self):
        robots = self.robot_registry.get_all_robots()

        total_robots = len(robots)

        active_robots = sum(
            1 for r in robots.values()
            if r.get("status") == "MOVING"
        )

        idle_robots = sum(
            1 for r in robots.values()
            if r.get("status") == "IDLE"
        )

        charging_robots = sum(
            1 for r in robots.values()
            if r.get("status") == "CHARGING"
        )

        total_tasks = len(self.task_allocator.get_all_tasks())

        completed_tasks = len([
            t for t in self.task_allocator.get_all_tasks()
            if t.get("status") == "COMPLETED"
        ])

        pending_tasks = len([
            t for t in self.task_allocator.get_all_tasks()
            if t.get("status") != "COMPLETED"
        ])

        return {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_robots": total_robots,
            "active_robots": active_robots,
            "idle_robots": idle_robots,
            "charging_robots": charging_robots,
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "pending_tasks": pending_tasks
        }

    def get_dashboard_data(self):
        return {
            "summary": self.get_fleet_summary(),
            "robots": self.get_robot_data(),
            "tasks": self.get_task_data(),
            "reservations": self.get_reservation_data()
        }
