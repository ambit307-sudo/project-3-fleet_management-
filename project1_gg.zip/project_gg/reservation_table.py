# traffic_manager/reservation_table.py

from collections import defaultdict
from typing import List, Tuple, Dict, Optional


class ReservationTable:
    """
    Time-space reservation table for multi-robot coordination.

    Stores:
        time_step -> {(x, y): robot_id}
    """

    def __init__(self):
        self.reservations: Dict[int, Dict[Tuple[int, int], str]] = defaultdict(dict)

    def reserve_path(
        self,
        robot_id: str,
        path: List[Tuple[int, int]],
        start_time: int = 0
    ) -> bool:
        """
        Reserve an entire path for a robot.
        """
        for i, position in enumerate(path):
            t = start_time + i

            if position in self.reservations[t]:
                occupying_robot = self.reservations[t][position]

                if occupying_robot != robot_id:
                    return False

        for i, position in enumerate(path):
            t = start_time + i
            self.reservations[t][position] = robot_id

        return True

    def release_path(
        self,
        robot_id: str,
        path: List[Tuple[int, int]],
        start_time: int = 0
    ) -> None:
        """
        Remove reservations associated with a robot's path.
        """
        for i, position in enumerate(path):
            t = start_time + i

            if (
                position in self.reservations[t]
                and self.reservations[t][position] == robot_id
            ):
                del self.reservations[t][position]

            if not self.reservations[t]:
                del self.reservations[t]

    def is_reserved(
        self,
        position: Tuple[int, int],
        time_step: int
    ) -> bool:
        return position in self.reservations.get(time_step, {})

    def get_reserving_robot(
        self,
        position: Tuple[int, int],
        time_step: int
    ) -> Optional[str]:
        return self.reservations.get(time_step, {}).get(position)

    def can_reserve(
        self,
        robot_id: str,
        path: List[Tuple[int, int]],
        start_time: int = 0
    ) -> bool:
        for i, position in enumerate(path):
            t = start_time + i

            if position in self.reservations[t]:
                occupying_robot = self.reservations[t][position]

                if occupying_robot != robot_id:
                    return False

        return True

    def clear_robot_reservations(self, robot_id: str) -> None:
        times_to_remove = []

        for t, positions in self.reservations.items():
            positions_to_remove = [
                pos
                for pos, rid in positions.items()
                if rid == robot_id
            ]

            for pos in positions_to_remove:
                del positions[pos]

            if not positions:
                times_to_remove.append(t)

        for t in times_to_remove:
            del self.reservations[t]

    def clear(self) -> None:
        self.reservations.clear()

    def print_table(self) -> None:
        print("\nReservation Table")
        print("-" * 40)

        for t in sorted(self.reservations.keys()):
            print(f"Time {t}:")
            for pos, robot_id in self.reservations[t].items():
                print(f"  {pos} -> {robot_id}")

        print("-" * 40)
