# utils/helper.py

import math
import uuid
from datetime import datetime


class Helper:
    """
    Common utility functions for the Fleet Management System.
    """

    @staticmethod
    def generate_task_id():
        return f"TASK_{uuid.uuid4().hex[:8]}"

    @staticmethod
    def generate_reservation_id():
        return f"RES_{uuid.uuid4().hex[:8]}"

    @staticmethod
    def calculate_distance(point1, point2):
        return math.sqrt(
            (point2[0] - point1[0]) ** 2 +
            (point2[1] - point1[1]) ** 2
        )

    @staticmethod
    def calculate_manhattan_distance(point1, point2):
        return (
            abs(point1[0] - point2[0]) +
            abs(point1[1] - point2[1])
        )

    @staticmethod
    def estimate_travel_time(distance, speed=1.0):
        if speed <= 0:
            return 0
        return round(distance / speed, 2)

    @staticmethod
    def get_current_timestamp():
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def format_position(position):
        return f"({position[0]}, {position[1]})"

    @staticmethod
    def battery_percentage(current_charge, max_charge):
        if max_charge == 0:
            return 0
        return round((current_charge / max_charge) * 100, 2)

    @staticmethod
    def is_battery_low(battery_level, threshold=20):
        return battery_level <= threshold

    @staticmethod
    def validate_position(position):
        return (
            isinstance(position, (tuple, list))
            and len(position) == 2
            and all(isinstance(v, (int, float)) for v in position)
        )

    @staticmethod
    def path_length(path):
        if not path or len(path) < 2:
            return 0

        length = 0

        for i in range(len(path) - 1):
            length += Helper.calculate_distance(
                path[i],
                path[i + 1]
            )

        return round(length, 2)

    @staticmethod
    def robot_status_color(status):
        status = status.upper()

        mapping = {
            "IDLE": "green",
            "MOVING": "blue",
            "CHARGING": "orange",
            "ERROR": "red",
            "BLOCKED": "yellow"
        }

        return mapping.get(status, "gray")

    @staticmethod
    def serialize_robot(robot):
        return {
            "robot_id": getattr(robot, "robot_id", None),
            "status": getattr(robot, "status", "IDLE"),
            "position": getattr(robot, "position", [0, 0]),
            "battery": getattr(robot, "battery", 100),
            "current_task": getattr(robot, "current_task", None)
        }

    @staticmethod
    def serialize_task(task):
        return {
            "task_id": task.get("task_id"),
            "pickup": task.get("pickup"),
            "dropoff": task.get("dropoff"),
            "status": task.get("status"),
            "assigned_robot": task.get("assigned_robot")
        }

    @staticmethod
    def serialize_reservation(reservation):
        return {
            "reservation_id": reservation.get("reservation_id"),
            "robot_id": reservation.get("robot_id"),
            "cell": reservation.get("cell"),
            "timestamp": reservation.get("timestamp")
        }
