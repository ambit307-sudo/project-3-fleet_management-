#!/usr/bin/env python3
# =============================================================================
# navigation/astar_planner.py
# =============================================================================
# Grid-based A* path planner pre-loaded with the static obstacle map derived
# from warehouse.world.
#
# Design overview
# ---------------
#   ┌─────────────────────────────────────────────────────────────────────┐
#   │  WarehouseGrid                                                      │
#   │    • 20 m × 20 m world, origin at centre (REP-103)                 │
#   │    • Configurable cell resolution (default 0.2 m → 100 × 100 grid) │
#   │    • Binary occupancy: FREE (0) or OCCUPIED (1)                     │
#   │    • Static obstacles painted from world geometry at construction   │
#   │    • Inflation layer: every obstacle cell is expanded by robot_     │
#   │      radius + safety_margin, giving clearance equal to the          │
#   │      TurtleBot3 Burger half-width (≈ 0.105 m) + configurable margin │
#   │    • Dynamic obstacle injection via mark_obstacle / clear_obstacle  │
#   │      (used by CollisionAvoidance when another robot is detected)    │
#   └─────────────────────────────────────────────────────────────────────┘
#   ┌─────────────────────────────────────────────────────────────────────┐
#   │  AStarPlanner                                                       │
#   │    • Weighted A* with configurable ε weight (ε=1 → admissible,     │
#   │      ε>1 → faster, slightly suboptimal)                             │
#   │    • 8-connected grid (cardinal + diagonal)                         │
#   │    • Octile distance heuristic (consistent, never over-estimates    │
#   │      on 8-connected grids with diagonal cost √2)                    │
#   │    • Path smoothing: Bézier-based waypoint reduction that removes   │
#   │      collinear intermediate cells while respecting obstacles         │
#   │    • Thread-safe: the grid RLock is acquired for reads/writes;      │
#   │      plan() may be called concurrently from different robot threads  │
#   │    • Returns a list of (x_world, y_world) float tuples — ready for  │
#   │      direct consumption by the robot PID navigation loops           │
#   └─────────────────────────────────────────────────────────────────────┘
#
# Static obstacle inventory (sourced from warehouse.world)
# --------------------------------------------------------
#   Outer walls      — 0.2 m thick, inner face at ±9.9 m
#   Shelf row A      — A1(-7.5,5.5)  A2(-5.5,5.5)  A3(-3.5,5.5)   y+ face
#   Shelf row B      — B1( 3.5,5.5)  B2( 5.5,5.5)  B3( 7.5,5.5)   y+ face
#   Shelf row C      — C1(-7.5,-5.5) C2(-5.5,-5.5) C3(-3.5,-5.5)  y- face
#   Shelf row D      — D1( 3.5,-5.5) D2( 5.5,-5.5) D3( 7.5,-5.5)  y- face
#   Pillars (×4)     — (±2.0, ±3.0), 0.3 × 0.3 m cross-section
#   Each shelf unit is 1.8 m wide × 0.4 m deep (boards + back panel)
#
# Named poses (world frame, from warehouse.world and multi_robot.launch.py)
# -------------------------------------------------------------------------
#   CHARGING_PADS    = [(-8.0, 0.0), (-8.0, -1.0), (-8.0, -2.0)]
#   DISPATCH_POSE    = (-4.0, -8.5)
#   RECEIVING_POSE   = ( 4.0, -8.5)
#   SHELF_FRONTAGE   — access aisles in front of each shelf row
#
# Integration
# -----------
#   AStarPlanner is NOT a ROS2 node. It is instantiated once inside
#   FleetManagerNode (or CollisionAvoidance) and shared across planning calls.
#
#   Typical usage:
#
#       from navigation.astar_planner import AStarPlanner
#
#       planner = AStarPlanner(
#           resolution      = 0.2,   # metres per cell
#           robot_radius    = 0.105, # TurtleBot3 Burger half-width
#           safety_margin   = 0.10,  # extra clearance around obstacles
#           epsilon         = 1.2,   # weighted A* sub-optimality factor
#       )
#
#       # Static path from charging pad 1 to shelf A1 access point
#       path = planner.plan(start=(-8.0, 0.0), goal=(-7.5, 4.8))
#       # path → [(x0,y0), (x1,y1), …, (xN,yN)]  in world metres
#
#       # Temporarily block a cell occupied by another robot
#       planner.mark_obstacle(-3.0, 1.0)
#       path2 = planner.plan((-8.0, 0.0), (-3.0, -3.0))
#       planner.clear_obstacle(-3.0, 1.0)
#
# =============================================================================

from __future__ import annotations

import heapq
import math
import threading
from dataclasses import dataclass, field
from typing import Dict, FrozenSet, List, Optional, Set, Tuple

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------
Cell      = Tuple[int, int]          # (col, row) grid indices
WorldPt   = Tuple[float, float]      # (x, y) in metres
Path      = List[WorldPt]


# =============================================================================
# WarehouseObstacle — axis-aligned rectangle in world coordinates
# =============================================================================

@dataclass(frozen=True)
class WarehouseObstacle:
    """
    Axis-aligned rectangular obstacle in world (metre) coordinates.

    Attributes
    ----------
    name     : human-readable label for debug/logging.
    cx, cy   : centre of the rectangle in the world frame.
    half_w   : half-width  (along world x-axis).
    half_h   : half-height (along world y-axis).
    """
    name:   str
    cx:     float
    cy:     float
    half_w: float
    half_h: float

    def contains(self, x: float, y: float) -> bool:
        """Return True if point (x,y) falls inside the obstacle footprint."""
        return (
            abs(x - self.cx) <= self.half_w
            and abs(y - self.cy) <= self.half_h
        )

    def inflated(self, margin: float) -> "WarehouseObstacle":
        """Return a copy expanded uniformly by margin on all sides."""
        return WarehouseObstacle(
            name   = self.name + "_inf",
            cx     = self.cx,
            cy     = self.cy,
            half_w = self.half_w + margin,
            half_h = self.half_h + margin,
        )


# =============================================================================
# Static obstacle catalogue  (parsed from warehouse.world)
# =============================================================================

def _build_static_obstacles() -> List[WarehouseObstacle]:
    """
    Return the list of all static obstacles in warehouse.world.

    Each shelf has:
      • A back panel  : 1.8 m wide × 0.05 m deep
      • Two shelf boards (top+bottom) : 1.8 m wide × 0.4 m deep
      • Two uprights  : 0.05 m wide  × 0.4 m deep

    For planning purposes the entire shelf footprint is conservatively
    represented as a single rectangle:  1.8 m wide × 0.4 m deep (the
    deepest element — the shelf boards).  The back panel adds only 0.175 m
    centred behind the boards; the inflation layer covers the gap.

    Row A / B face north (y+ direction) → back panel at y + 0.175
    Row C / D face south (y- direction) → back panel at y - 0.175
    The footprint centre is taken at the shelf-board centre (shelf pose,
    since shelf_board_low/high are centred at pose origin x,y).

    Outer walls: 20.4 m × 0.2 m boxes centred at ±10.0 m from origin.
    Wall inner face at ±9.9 m; we model the full 0.2 m thickness.
    """
    obs: List[WarehouseObstacle] = []

    # ── Outer walls ────────────────────────────────────────────────────────
    # North wall: pose(0, 10, 1.5), size(20.4, 0.2, 3.0)
    obs.append(WarehouseObstacle("wall_north", 0.0, 10.0, 10.2, 0.1))
    # South wall: pose(0, -10, 1.5)
    obs.append(WarehouseObstacle("wall_south", 0.0, -10.0, 10.2, 0.1))
    # East wall:  pose(10, 0, 1.5), size(0.2, 20.4, 3.0)
    obs.append(WarehouseObstacle("wall_east",  10.0, 0.0, 0.1, 10.2))
    # West wall:  pose(-10, 0, 1.5)
    obs.append(WarehouseObstacle("wall_west", -10.0, 0.0, 0.1, 10.2))

    # ── Helper: add a shelf ────────────────────────────────────────────────
    # Shelf boards are 1.8 m wide × 0.4 m deep, centred at (cx, cy).
    # We include the back panel (+0.175 offset) by extending half_h to 0.375.
    # (0.4/2 board + 0.175 panel offset = 0.375 half-extent on panel side)
    def _shelf_ab(name: str, cx: float, cy: float) -> WarehouseObstacle:
        """Shelf facing south (rows A, B) — panel at y + 0.175."""
        # footprint: x in [cx-0.9, cx+0.9], y in [cy-0.2, cy+0.375]
        c_y = cy + (0.375 - 0.2) / 2          # = cy + 0.0875
        return WarehouseObstacle(name, cx, c_y, 0.9, 0.2875)

    def _shelf_cd(name: str, cx: float, cy: float) -> WarehouseObstacle:
        """Shelf facing north (rows C, D) — panel at y - 0.175."""
        c_y = cy - (0.375 - 0.2) / 2          # = cy - 0.0875
        return WarehouseObstacle(name, cx, c_y, 0.9, 0.2875)

    # Row A  (north-west, y = 5.5)
    obs.append(_shelf_ab("shelf_A1", -7.5, 5.5))
    obs.append(_shelf_ab("shelf_A2", -5.5, 5.5))
    obs.append(_shelf_ab("shelf_A3", -3.5, 5.5))

    # Row B  (north-east, y = 5.5)
    obs.append(_shelf_ab("shelf_B1",  3.5, 5.5))
    obs.append(_shelf_ab("shelf_B2",  5.5, 5.5))
    obs.append(_shelf_ab("shelf_B3",  7.5, 5.5))

    # Row C  (south-west, y = -5.5)
    obs.append(_shelf_cd("shelf_C1", -7.5, -5.5))
    obs.append(_shelf_cd("shelf_C2", -5.5, -5.5))
    obs.append(_shelf_cd("shelf_C3", -3.5, -5.5))

    # Row D  (south-east, y = -5.5)
    obs.append(_shelf_cd("shelf_D1",  3.5, -5.5))
    obs.append(_shelf_cd("shelf_D2",  5.5, -5.5))
    obs.append(_shelf_cd("shelf_D3",  7.5, -5.5))

    # ── Pillars  (0.3 × 0.3 m at four locations) ──────────────────────────
    for name, cx, cy in [
        ("pillar_nw", -2.0,  3.0),
        ("pillar_ne",  2.0,  3.0),
        ("pillar_sw", -2.0, -3.0),
        ("pillar_se",  2.0, -3.0),
    ]:
        obs.append(WarehouseObstacle(name, cx, cy, 0.15, 0.15))

    return obs


# Singleton catalogue — built once at import time
_STATIC_OBSTACLES: List[WarehouseObstacle] = _build_static_obstacles()


# =============================================================================
# WarehouseGrid
# =============================================================================

class WarehouseGrid:
    """
    Binary occupancy grid for the 20 × 20 m warehouse.

    Grid convention
    ---------------
    • Cell (col=0, row=0) maps to world corner (x_min, y_min).
    • col increases with world-x (East), row increases with world-y (North).
    • Cell centre: x = x_min + (col + 0.5) * resolution
                   y = y_min + (row + 0.5) * resolution

    Map bounds (matches warehouse.world floor exactly):
        x ∈ [−10.0, 10.0]   (wall inner faces at ±9.9 m)
        y ∈ [−10.0, 10.0]
    """

    MAP_X_MIN: float = -10.0
    MAP_X_MAX: float =  10.0
    MAP_Y_MIN: float = -10.0
    MAP_Y_MAX: float =  10.0

    def __init__(
        self,
        resolution:    float = 0.2,
        robot_radius:  float = 0.105,
        safety_margin: float = 0.10,
    ) -> None:
        """
        Parameters
        ----------
        resolution
            Cell side length in metres.  Must evenly divide 20.0 for a clean
            grid.  Default 0.2 → 100 × 100 = 10 000 cells.
        robot_radius
            Half-width of the TurtleBot3 Burger (0.105 m).  Used to compute
            the inflation distance so the robot centre never gets closer to
            an obstacle than robot_radius + safety_margin.
        safety_margin
            Extra clearance added on top of robot_radius.  Set to 0 to
            disable inflation (not recommended — sharp corners will be nicked).
        """
        self._res    = resolution
        self._inflate = robot_radius + safety_margin

        self._cols: int = round((self.MAP_X_MAX - self.MAP_X_MIN) / resolution)
        self._rows: int = round((self.MAP_Y_MAX - self.MAP_Y_MIN) / resolution)

        # Flat binary array: True = occupied
        self._static:  List[bool] = [False] * (self._cols * self._rows)
        self._dynamic: List[bool] = [False] * (self._cols * self._rows)

        # Reentrant lock — plan() may be called from multiple threads
        self._lock = threading.RLock()

        # Paint static obstacles from the warehouse catalogue
        self._paint_static_obstacles()

    # =========================================================================
    # Grid ↔ world conversions
    # =========================================================================

    def world_to_cell(self, x: float, y: float) -> Cell:
        """Convert world coordinates to (col, row).  Clamps to grid bounds."""
        col = int((x - self.MAP_X_MIN) / self._res)
        row = int((y - self.MAP_Y_MIN) / self._res)
        col = max(0, min(self._cols - 1, col))
        row = max(0, min(self._rows - 1, row))
        return (col, row)

    def cell_to_world(self, col: int, row: int) -> WorldPt:
        """Return the world-frame centre of cell (col, row)."""
        x = self.MAP_X_MIN + (col + 0.5) * self._res
        y = self.MAP_Y_MIN + (row + 0.5) * self._res
        return (x, y)

    def _idx(self, col: int, row: int) -> int:
        return row * self._cols + col

    def in_bounds(self, col: int, row: int) -> bool:
        return 0 <= col < self._cols and 0 <= row < self._rows

    # =========================================================================
    # Occupancy queries
    # =========================================================================

    def is_occupied(self, col: int, row: int) -> bool:
        """True if cell is blocked by a static or dynamic obstacle."""
        with self._lock:
            idx = self._idx(col, row)
            return self._static[idx] or self._dynamic[idx]

    def is_free(self, col: int, row: int) -> bool:
        return not self.is_occupied(col, row)

    def is_world_free(self, x: float, y: float) -> bool:
        """Return True if the world-frame point (x, y) falls in a free cell."""
        return self.is_free(*self.world_to_cell(x, y))

    # =========================================================================
    # Static obstacle painting
    # =========================================================================

    def _paint_static_obstacles(self) -> None:
        """
        Rasterise every static obstacle (inflated by robot_radius + margin)
        into the static occupancy layer.

        Strategy
        --------
        For each obstacle, compute its inflated AABB, iterate over the grid
        cells whose centres fall inside, and mark them occupied.  This is an
        O(obstacles × covered_cells) scan — cheap at construction time and
        avoids per-query geometry tests during planning.
        """
        inflate = self._inflate
        for obs in _STATIC_OBSTACLES:
            inf = obs.inflated(inflate)
            # Find cell range that overlaps the inflated AABB
            col_lo, row_lo = self.world_to_cell(
                inf.cx - inf.half_w, inf.cy - inf.half_h
            )
            col_hi, row_hi = self.world_to_cell(
                inf.cx + inf.half_w, inf.cy + inf.half_h
            )
            # Clamp
            col_lo = max(0, col_lo)
            row_lo = max(0, row_lo)
            col_hi = min(self._cols - 1, col_hi)
            row_hi = min(self._rows - 1, row_hi)

            for row in range(row_lo, row_hi + 1):
                for col in range(col_lo, col_hi + 1):
                    cx, cy = self.cell_to_world(col, row)
                    if inf.contains(cx, cy):
                        self._static[self._idx(col, row)] = True

    # =========================================================================
    # Dynamic obstacle interface
    # =========================================================================

    def mark_obstacle(self, x: float, y: float, radius: float = 0.0) -> None:
        """
        Mark world point (x, y) — and optionally a disc of cells within
        radius metres — as dynamically occupied.

        Called by CollisionAvoidance when another robot's position is known
        and the planner should route around it.
        """
        with self._lock:
            effective_radius = radius + self._inflate
            if effective_radius <= 0.0:
                col, row = self.world_to_cell(x, y)
                self._dynamic[self._idx(col, row)] = True
                return

            # Mark all cells within effective_radius
            dr = int(math.ceil(effective_radius / self._res)) + 1
            c0, r0 = self.world_to_cell(x, y)
            for dc in range(-dr, dr + 1):
                for dr_ in range(-dr, dr + 1):
                    col = c0 + dc
                    row = r0 + dr_
                    if not self.in_bounds(col, row):
                        continue
                    cx, cy = self.cell_to_world(col, row)
                    if math.hypot(cx - x, cy - y) <= effective_radius:
                        self._dynamic[self._idx(col, row)] = True

    def clear_obstacle(self, x: float, y: float, radius: float = 0.0) -> None:
        """
        Clear dynamic occupancy around (x, y).

        Note: does NOT clear static cells — only the dynamic layer.
        """
        with self._lock:
            effective_radius = radius + self._inflate
            if effective_radius <= 0.0:
                col, row = self.world_to_cell(x, y)
                self._dynamic[self._idx(col, row)] = False
                return

            dr = int(math.ceil(effective_radius / self._res)) + 1
            c0, r0 = self.world_to_cell(x, y)
            for dc in range(-dr, dr + 1):
                for dr_ in range(-dr, dr + 1):
                    col = c0 + dc
                    row = r0 + dr_
                    if not self.in_bounds(col, row):
                        continue
                    cx, cy = self.cell_to_world(col, row)
                    if math.hypot(cx - x, cy - y) <= effective_radius:
                        self._dynamic[self._idx(col, row)] = False

    def clear_all_dynamic(self) -> None:
        """Reset the entire dynamic obstacle layer (e.g. at start of re-plan)."""
        with self._lock:
            self._dynamic = [False] * (self._cols * self._rows)

    # =========================================================================
    # Neighbours
    # =========================================================================

    _CARDINAL    = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    _DIAGONAL    = [(1, 1), (1, -1), (-1, 1), (-1, -1)]
    _SQRT2       = math.sqrt(2.0)

    def neighbours(self, col: int, row: int) -> List[Tuple[Cell, float]]:
        """
        Return reachable (cell, cost) pairs for 8-connected movement.

        Diagonal moves are only returned if both cardinal neighbours sharing
        that corner are free (prevents cutting through shelf corners).

        Move costs
        ----------
        Cardinal  : 1.0  (one cell width)
        Diagonal  : √2   (Euclidean diagonal)
        """
        result: List[Tuple[Cell, float]] = []

        for dc, dr in self._CARDINAL:
            nc, nr = col + dc, row + dr
            if self.in_bounds(nc, nr) and self.is_free(nc, nr):
                result.append(((nc, nr), 1.0))

        for dc, dr in self._DIAGONAL:
            nc, nr = col + dc, row + dr
            if not self.in_bounds(nc, nr):
                continue
            if self.is_occupied(nc, nr):
                continue
            # Require both cardinal neighbours to be free (corner check)
            if self.is_occupied(col + dc, row) or self.is_occupied(col, row + dr):
                continue
            result.append(((nc, nr), self._SQRT2))

        return result

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def resolution(self) -> float:
        return self._res

    @property
    def shape(self) -> Tuple[int, int]:
        """(cols, rows)"""
        return (self._cols, self._rows)

    @property
    def inflation_radius(self) -> float:
        return self._inflate

    def obstacle_count(self) -> int:
        """Number of occupied static cells (diagnostic)."""
        return sum(self._static)


# =============================================================================
# A* open-set node
# =============================================================================

@dataclass(order=True)
class _AStarNode:
    """Priority-queue entry for the A* open set."""
    f:    float       # f = g + ε·h  (priority)
    g:    float       = field(compare=False)
    cell: Cell        = field(compare=False)
    parent: Optional["_AStarNode"] = field(default=None, compare=False)


# =============================================================================
# AStarPlanner
# =============================================================================

class AStarPlanner:
    """
    Weighted A* path planner operating on a WarehouseGrid.

    Heuristic
    ---------
    Octile distance: the exact cost on an 8-connected grid with unit cardinal
    and √2 diagonal moves.  It is consistent (monotone), so re-expansions
    never occur and the closed set check is a single hash lookup.

        h(n, goal) = max(|Δcol|, |Δrow|) + (√2 − 1) · min(|Δcol|, |Δrow|)

    Weighted A* (ε-A*)
    ------------------
    f(n) = g(n) + ε · h(n, goal)

    With ε = 1 the search is admissible and returns an optimal path.
    With ε > 1 the search explores fewer nodes (faster) at the cost of at most
    ε-optimal path length.  ε = 1.2 is the default — 20% suboptimality bound,
    typically 3–5× faster than ε = 1 on this warehouse layout.

    Path smoothing
    --------------
    After the raw cell path is found, a line-of-sight (LOS) check removes
    redundant waypoints: starting from the first cell, the planner tries to
    connect directly to cells further along the path.  If the straight line
    between two cells passes through no occupied cell (Bresenham trace), the
    intermediate waypoints are discarded.  This reduces the number of heading
    corrections the robot must perform.
    """

    def __init__(
        self,
        resolution:    float = 0.2,
        robot_radius:  float = 0.105,
        safety_margin: float = 0.10,
        epsilon:       float = 1.2,
        grid:          Optional[WarehouseGrid] = None,
    ) -> None:
        """
        Parameters
        ----------
        resolution
            Grid cell size in metres (passed to WarehouseGrid if grid=None).
        robot_radius
            Half-width of the robot (TurtleBot3 Burger = 0.105 m).
        safety_margin
            Extra inflation beyond robot_radius.
        epsilon
            Weighted A* inflation factor.  1.0 = optimal; 1.2 = default.
        grid
            Pre-built WarehouseGrid (useful for sharing across planners or
            injecting a test grid).  If None a new grid is constructed.
        """
        if grid is not None:
            self._grid = grid
        else:
            self._grid = WarehouseGrid(
                resolution    = resolution,
                robot_radius  = robot_radius,
                safety_margin = safety_margin,
            )

        self._epsilon = epsilon
        self._res     = self._grid.resolution

        # Planning statistics (not locked — single-caller assumed per plan())
        self._plan_calls:    int = 0
        self._nodes_expanded: int = 0
        self._last_path_len: int = 0

    # =========================================================================
    # Public API
    # =========================================================================

    def plan(
        self,
        start:           WorldPt,
        goal:            WorldPt,
        smooth:          bool = True,
        dynamic_blocks:  Optional[List[Tuple[WorldPt, float]]] = None,
    ) -> Optional[Path]:
        """
        Compute a collision-free path from start to goal in the world frame.

        Parameters
        ----------
        start
            (x, y) robot position in world metres.
        goal
            (x, y) target position in world metres.
        smooth
            If True, apply line-of-sight waypoint reduction after A*.
        dynamic_blocks
            Optional list of [(x, y), radius] pairs for one-shot dynamic
            obstacle injection.  These are added to the dynamic layer before
            planning and removed afterwards.  Use this when you don't want to
            permanently mark the grid (e.g. for multi-step lookahead).

        Returns
        -------
        List of (x, y) waypoints from just after start to goal (inclusive),
        or None if no path exists.  The start point itself is NOT included
        (the robot is already there).

        Raises
        ------
        ValueError
            If start or goal fall outside the map bounds.
        """
        self._plan_calls += 1

        # ── Validate start / goal ──────────────────────────────────────────
        start_cell = self._grid.world_to_cell(*start)
        goal_cell  = self._grid.world_to_cell(*goal)

        if self._grid.is_occupied(*start_cell):
            # Start is inside an obstacle — snap to nearest free cell
            start_cell = self._nearest_free(start_cell)
            if start_cell is None:
                return None

        if self._grid.is_occupied(*goal_cell):
            # Goal is inside an obstacle — snap to nearest free cell
            goal_cell = self._nearest_free(goal_cell)
            if goal_cell is None:
                return None

        # ── Inject one-shot dynamic obstacles ─────────────────────────────
        if dynamic_blocks:
            for (bx, by), brad in dynamic_blocks:
                self._grid.mark_obstacle(bx, by, brad)

        try:
            cell_path = self._astar(start_cell, goal_cell)
        finally:
            # Always remove one-shot blocks even if planning fails/raises
            if dynamic_blocks:
                for (bx, by), brad in dynamic_blocks:
                    self._grid.clear_obstacle(bx, by, brad)

        if cell_path is None:
            return None

        self._last_path_len = len(cell_path)
        world_path = [self._grid.cell_to_world(c, r) for c, r in cell_path]

        if smooth and len(world_path) > 2:
            world_path = self._smooth_path(cell_path, world_path)

        # Drop duplicate of start position (already at start_cell centre)
        if world_path and world_path[0] == self._grid.cell_to_world(*start_cell):
            world_path = world_path[1:]

        return world_path if world_path else None

    def replan_around_robots(
        self,
        start:    WorldPt,
        goal:     WorldPt,
        robots:   List[Tuple[WorldPt, float]],   # [(x,y), radius]
        smooth:   bool = True,
    ) -> Optional[Path]:
        """
        Plan a path that avoids known robot positions.

        Each robot is temporarily marked in the dynamic obstacle layer,
        the plan is computed, and the layer is cleaned up.  Equivalent to
        calling plan() with dynamic_blocks=robots.
        """
        return self.plan(start, goal, smooth=smooth, dynamic_blocks=robots)

    # =========================================================================
    # A* core
    # =========================================================================

    @staticmethod
    def _octile(a: Cell, b: Cell) -> float:
        """
        Octile distance heuristic — consistent on 8-connected grids.

        h = max(|dc|, |dr|) + (√2 − 1) · min(|dc|, |dr|)
        """
        dc = abs(a[0] - b[0])
        dr = abs(a[1] - b[1])
        return max(dc, dr) + (math.sqrt(2.0) - 1.0) * min(dc, dr)

    def _astar(self, start: Cell, goal: Cell) -> Optional[List[Cell]]:
        """
        Weighted A* on the occupancy grid.

        Returns
        -------
        Ordered list of cells from start to goal (inclusive), or None if
        the goal is unreachable.
        """
        if start == goal:
            return [start]

        eps = self._epsilon
        h0  = self._octile(start, goal)

        open_set: List[_AStarNode] = []
        start_node = _AStarNode(f=eps * h0, g=0.0, cell=start)
        heapq.heappush(open_set, start_node)

        # g-value table: cell → best known g (float)
        g_map: Dict[Cell, float] = {start: 0.0}
        # Closed set: cells already expanded
        closed: Set[Cell] = set()

        expanded = 0

        while open_set:
            node = heapq.heappop(open_set)

            if node.cell in closed:
                continue
            closed.add(node.cell)
            expanded += 1

            if node.cell == goal:
                self._nodes_expanded += expanded
                return self._reconstruct(node)

            for neighbour_cell, move_cost in self._grid.neighbours(*node.cell):
                if neighbour_cell in closed:
                    continue

                tentative_g = node.g + move_cost
                if tentative_g < g_map.get(neighbour_cell, math.inf):
                    g_map[neighbour_cell] = tentative_g
                    h = self._octile(neighbour_cell, goal)
                    f = tentative_g + eps * h
                    child = _AStarNode(
                        f      = f,
                        g      = tentative_g,
                        cell   = neighbour_cell,
                        parent = node,
                    )
                    heapq.heappush(open_set, child)

        self._nodes_expanded += expanded
        return None   # goal unreachable

    @staticmethod
    def _reconstruct(node: _AStarNode) -> List[Cell]:
        """Walk parent pointers to reconstruct the cell path."""
        path: List[Cell] = []
        cur: Optional[_AStarNode] = node
        while cur is not None:
            path.append(cur.cell)
            cur = cur.parent
        path.reverse()
        return path

    # =========================================================================
    # Path smoothing — line-of-sight reduction
    # =========================================================================

    def _smooth_path(
        self, cell_path: List[Cell], world_path: Path
    ) -> Path:
        """
        Remove collinear / redundant waypoints using LOS (Bresenham) checks.

        Algorithm
        ---------
        Greedy string-pulling: start at index 0; find the furthest index j
        such that the straight line from path[0] to path[j] is obstacle-free.
        Keep path[j] and restart from it.  Repeat to the goal.

        The result is a minimal waypoint list that the robot can follow
        with pure heading+distance PID control.
        """
        if len(cell_path) <= 2:
            return world_path

        smoothed: Path = [world_path[0]]
        i = 0

        while i < len(cell_path) - 1:
            # Find the furthest j reachable in LOS from i
            j = i + 1
            last_clear = i + 1
            while j < len(cell_path):
                if self._los_clear(cell_path[i], cell_path[j]):
                    last_clear = j
                j += 1
            smoothed.append(world_path[last_clear])
            i = last_clear

        return smoothed

    def _los_clear(self, a: Cell, b: Cell) -> bool:
        """
        Bresenham line trace from cell a to cell b.

        Returns True if every cell along the line is free.
        Uses the standard integer Bresenham algorithm — O(max(|Δcol|,|Δrow|)).
        """
        col0, row0 = a
        col1, row1 = b

        dc = abs(col1 - col0)
        dr = abs(row1 - row0)
        sc = 1 if col1 > col0 else -1
        sr = 1 if row1 > row0 else -1

        err = dc - dr

        col, row = col0, row0

        while True:
            if self._grid.is_occupied(col, row):
                return False
            if col == col1 and row == row1:
                return True

            e2 = 2 * err
            if e2 > -dr:
                err -= dr
                col += sc
            if e2 < dc:
                err += dc
                row += sr

    # =========================================================================
    # Nearest free cell  (BFS, used for start/goal snapping)
    # =========================================================================

    def _nearest_free(self, cell: Cell, max_radius: int = 10) -> Optional[Cell]:
        """
        BFS from cell outward until a free cell is found or max_radius
        cells have been searched.  Returns None if no free cell exists nearby.
        """
        from collections import deque
        visited: Set[Cell] = {cell}
        queue: deque = deque([cell])

        while queue:
            c = queue.popleft()
            if self._grid.is_free(*c):
                return c
            col, row = c
            dist = max(abs(col - cell[0]), abs(row - cell[1]))
            if dist >= max_radius:
                continue
            for dc, dr in [
                (1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)
            ]:
                nc = (col + dc, row + dr)
                if self._grid.in_bounds(*nc) and nc not in visited:
                    visited.add(nc)
                    queue.append(nc)

        return None

    # =========================================================================
    # Dynamic obstacle helpers (pass-through to grid)
    # =========================================================================

    def mark_obstacle(self, x: float, y: float, radius: float = 0.0) -> None:
        """Mark a dynamic obstacle at world point (x, y) with given radius."""
        self._grid.mark_obstacle(x, y, radius)

    def clear_obstacle(self, x: float, y: float, radius: float = 0.0) -> None:
        """Clear dynamic occupancy at world point (x, y) with given radius."""
        self._grid.clear_obstacle(x, y, radius)

    def clear_all_dynamic(self) -> None:
        """Clear the entire dynamic obstacle layer."""
        self._grid.clear_all_dynamic()

    # =========================================================================
    # Named-pose convenience helpers  (from warehouse.world / launch file)
    # =========================================================================

    #: Access point in front of each shelf (world x,y in metres)
    #: Positioned 0.8 m in front of shelf board edge — comfortably clear of
    #: the inflation layer — aligned with the aisle guide lines.
    SHELF_ACCESS: Dict[str, WorldPt] = {
        # Row A — access from south (y = 5.5 - 0.2 - 0.8 = 4.5)
        "A1": (-7.5, 4.5),
        "A2": (-5.5, 4.5),
        "A3": (-3.5, 4.5),
        # Row B — access from south
        "B1": ( 3.5, 4.5),
        "B2": ( 5.5, 4.5),
        "B3": ( 7.5, 4.5),
        # Row C — access from north (y = -5.5 + 0.2 + 0.8 = -4.5)
        "C1": (-7.5, -4.5),
        "C2": (-5.5, -4.5),
        "C3": (-3.5, -4.5),
        # Row D — access from north
        "D1": ( 3.5, -4.5),
        "D2": ( 5.5, -4.5),
        "D3": ( 7.5, -4.5),
    }

    #: Named operational poses (match multi_robot.launch.py parameter values)
    CHARGING_PADS: List[WorldPt] = [
        (-8.0,  0.0),   # pad_1 → robot_1 home
        (-8.0, -1.0),   # pad_2 → robot_2 home
        (-8.0, -2.0),   # pad_3 → robot_3 home
    ]
    DISPATCH_POSE:  WorldPt = (-4.0, -8.5)
    RECEIVING_POSE: WorldPt = ( 4.0, -8.5)

    def plan_to_shelf(
        self,
        start: WorldPt,
        shelf: str,
        smooth: bool = True,
    ) -> Optional[Path]:
        """
        Plan from start to the access aisle in front of the named shelf.

        Parameters
        ----------
        shelf
            Shelf label, e.g. "A1", "B3", "C2", "D1".

        Returns
        -------
        Path to the shelf access point, or None if unreachable.

        Raises
        ------
        KeyError
            If shelf is not in SHELF_ACCESS.
        """
        goal = self.SHELF_ACCESS[shelf.upper()]
        return self.plan(start, goal, smooth=smooth)

    def plan_to_charger(
        self,
        start:    WorldPt,
        robot_id: int,
        smooth:   bool = True,
    ) -> Optional[Path]:
        """
        Plan from start to the charging pad for robot_id (1, 2, or 3).

        Returns None if robot_id is out of range or path is unreachable.
        """
        idx = robot_id - 1
        if not (0 <= idx < len(self.CHARGING_PADS)):
            return None
        return self.plan(start, self.CHARGING_PADS[idx], smooth=smooth)

    def plan_to_dispatch(self, start: WorldPt, smooth: bool = True) -> Optional[Path]:
        """Plan from start to the dispatch zone."""
        return self.plan(start, self.DISPATCH_POSE, smooth=smooth)

    def plan_to_receiving(self, start: WorldPt, smooth: bool = True) -> Optional[Path]:
        """Plan from start to the receiving zone."""
        return self.plan(start, self.RECEIVING_POSE, smooth=smooth)

    # =========================================================================
    # Diagnostics
    # =========================================================================

    @property
    def grid(self) -> WarehouseGrid:
        """Direct access to the underlying grid (for tests / visualisation)."""
        return self._grid

    def stats(self) -> dict:
        """Return accumulated planning statistics."""
        return {
            "plan_calls":     self._plan_calls,
            "nodes_expanded": self._nodes_expanded,
            "last_path_len":  self._last_path_len,
            "grid_shape":     self._grid.shape,
            "resolution":     self._grid.resolution,
            "inflation_m":    self._grid.inflation_radius,
            "epsilon":        self._epsilon,
            "static_cells":   self._grid.obstacle_count(),
        }

    def __repr__(self) -> str:
        s = self._grid.shape
        return (
            f"AStarPlanner("
            f"grid={s[0]}×{s[1]}, "
            f"res={self._res}m, "
            f"inflate={self._grid.inflation_radius:.3f}m, "
            f"ε={self._epsilon})"
        )
