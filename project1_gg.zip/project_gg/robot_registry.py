#!/usr/bin/env python3
# =============================================================================
# fleet_manager/robot_registry.py
# =============================================================================
# Central in-process registry that the fleet manager (and its sub-modules)
# use as the single source of truth about every robot in the fleet.
#
# Responsibilities
# ----------------
#   • Parse JSON status messages published by each robot node and store the
#     result in a typed RobotRecord dataclass.
#   • Track heartbeat timestamps so the fleet manager can detect a robot that
#     has stopped publishing (node crash, network drop, hardware fault).
#   • Expose thread-safe read/write access — the ROS2 executor calls
#     callbacks from a single thread by default, but the Streamlit dashboard
#     reads registry state from a separate thread via a REST bridge, so all
#     mutations are protected by a reentrant lock.
#   • Provide query helpers used throughout the fleet stack:
#       - get_robot(robot_id)          → RobotRecord | None
#       - all_robots()                 → list[RobotRecord]
#       - robots_in_state(state)       → list[RobotRecord]
#       - available_robots()           → IDLE robots with battery > threshold
#       - nearest_available_robot(x,y) → closest available robot to a point
#       - is_alive(robot_id)           → bool  (heartbeat within timeout)
#       - any_robot_near(x,y,radius)   → bool  (collision pre-check)
#
# Integration
# -----------
#   The registry is NOT a ROS2 node itself. It is instantiated once inside
#   FleetManagerNode.__init__ and passed by reference to TaskAllocator and
#   CollisionAvoidance.  Subscriber callbacks registered in FleetManagerNode
#   call registry.update_status() and registry.update_heartbeat() directly.
#
#   Example wiring in fleet_manager.py:
#
#       from fleet_manager.robot_registry import RobotRegistry
#
#       self._registry = RobotRegistry(
#           robot_ids=[1, 2, 3],
#           heartbeat_timeout=5.0,
#           low_battery_threshold=20.0,
#       )
#       self.create_subscription(
#           String, "/fleet/robot_1/status",
#           lambda msg: self._registry.update_status(msg.data), 10,
#       )
#       self.create_subscription(
#           Header, "/fleet/robot_1/heartbeat",
#           lambda msg: self._registry.update_heartbeat(1), 10,
#       )
#
# Status JSON schema (from robot1/2/3.py)
# ----------------------------------------
#   {
#     "robot_id":    int,
#     "state":       str,        # RobotState enum name
#     "x":           float,
#     "y":           float,
#     "yaw":         float,
#     "battery":     float,      # 0.0–100.0 %
#     "task_id":     str | null,
#     "task_action": str | null,
#     "obstacle":    bool,
#     "goal_x":      float | null,
#     "goal_y":      float | null,
#     "timestamp":   int,        # nanoseconds (ROS clock)
#   }
# =============================================================================

from __future__ import annotations

import json
import math
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional


# =============================================================================
# RobotState mirror
# =============================================================================
# Mirrors the RobotState enum in robot1/2/3.py so the fleet manager can
# compare states without importing from the robot modules.  String comparison
# would also work but this gives type-safe switch logic throughout the fleet.

class RobotState(str, Enum):
    IDLE            = "IDLE"
    NAVIGATING      = "NAVIGATING"
    EXECUTING       = "EXECUTING"
    RETURNING       = "RETURNING"
    CHARGING        = "CHARGING"
    EMERGENCY_STOP  = "EMERGENCY_STOP"
    UNKNOWN         = "UNKNOWN"   # used when no status has been received yet


# =============================================================================
# RobotRecord — one record per robot, updated on every status message
# =============================================================================

@dataclass
class RobotRecord:
    """
    Snapshot of a single robot's last known state.

    All fields have safe defaults so the record is usable the moment it
    is created — before the first status message arrives.
    """

    # ── Identity ──────────────────────────────────────────────────────────
    robot_id: int

    # ── Pose ──────────────────────────────────────────────────────────────
    x:   float = 0.0
    y:   float = 0.0
    yaw: float = 0.0

    # ── State machine ─────────────────────────────────────────────────────
    state: RobotState = RobotState.UNKNOWN

    # ── Battery ───────────────────────────────────────────────────────────
    battery: float = 100.0          # %

    # ── Active task ───────────────────────────────────────────────────────
    task_id:     Optional[str] = None
    task_action: Optional[str] = None

    # ── Navigation ────────────────────────────────────────────────────────
    goal_x: Optional[float] = None
    goal_y: Optional[float] = None

    # ── Sensor flags ──────────────────────────────────────────────────────
    obstacle_detected: bool = False

    # ── Liveness tracking ─────────────────────────────────────────────────
    # Wall-clock seconds (time.monotonic) of the most recent status message.
    last_status_time:    float = 0.0
    # Wall-clock seconds of the most recent heartbeat message.
    last_heartbeat_time: float = 0.0
    # ROS timestamp (nanoseconds) from the status payload.
    ros_timestamp_ns:    int   = 0

    # ── Statistics ────────────────────────────────────────────────────────
    # Counters that help the task allocator make load-balancing decisions
    # and the dashboard surface utilisation metrics.
    tasks_completed:  int = 0
    total_nav_time_s: float = 0.0   # cumulative seconds spent navigating
    estop_count:      int = 0       # number of emergency-stop events

    # ── Internal navigation timing (set by registry on state transitions) ─
    _nav_start_time: float = field(default=0.0, repr=False)

    # ── Charging station home pose (set by RobotRegistry on construction) ─
    home_x: float = 0.0
    home_y: float = 0.0

    # ── Convenience properties ────────────────────────────────────────────

    @property
    def is_available(self) -> bool:
        """True when the robot can accept a new task from the allocator."""
        return self.state == RobotState.IDLE

    @property
    def is_moving(self) -> bool:
        """True when the robot is consuming navigation power."""
        return self.state in (RobotState.NAVIGATING, RobotState.RETURNING)

    @property
    def distance_to_goal(self) -> Optional[float]:
        """Euclidean distance to the current navigation goal, or None."""
        if self.goal_x is None or self.goal_y is None:
            return None
        return math.hypot(self.goal_x - self.x, self.goal_y - self.y)

    def distance_to(self, x: float, y: float) -> float:
        """Euclidean distance from current pose to an arbitrary (x, y) point."""
        return math.hypot(x - self.x, y - self.y)

    def as_dict(self) -> dict:
        """
        Serialise to a plain dict for the dashboard REST bridge or logging.
        Excludes internal fields prefixed with _.
        """
        return {
            "robot_id":         self.robot_id,
            "state":            self.state.value,
            "x":                round(self.x,   3),
            "y":                round(self.y,   3),
            "yaw":              round(self.yaw, 3),
            "battery":          round(self.battery, 2),
            "task_id":          self.task_id,
            "task_action":      self.task_action,
            "goal_x":           self.goal_x,
            "goal_y":           self.goal_y,
            "obstacle":         self.obstacle_detected,
            "ros_timestamp_ns": self.ros_timestamp_ns,
            "tasks_completed":  self.tasks_completed,
            "total_nav_time_s": round(self.total_nav_time_s, 1),
            "estop_count":      self.estop_count,
            "home_x":           self.home_x,
            "home_y":           self.home_y,
        }


# =============================================================================
# RobotRegistry
# =============================================================================

class RobotRegistry:
    """
    Thread-safe store for RobotRecord objects, one per robot in the fleet.

    Lifecycle
    ---------
    1. Instantiated by FleetManagerNode with the list of robot IDs and their
       home (charging pad) positions.
    2. FleetManagerNode subscriber callbacks call update_status() and
       update_heartbeat() on every incoming message.
    3. TaskAllocator, CollisionAvoidance, and the dashboard REST bridge read
       records via the query helpers — all reads acquire the same lock.
    """

    # Default charging positions indexed by robot_id.
    # These are overridden by the constructor argument `home_positions` and
    # must match the `charging_positions` parameter in multi_robot.launch.py.
    _DEFAULT_HOMES: Dict[int, tuple] = {
        1: (-8.0,  0.0),
        2: (-8.0, -1.0),
        3: (-8.0, -2.0),
    }

    def __init__(
        self,
        robot_ids: List[int],
        heartbeat_timeout:     float = 5.0,
        low_battery_threshold: float = 20.0,
        home_positions: Optional[Dict[int, tuple]] = None,
    ) -> None:
        """
        Parameters
        ----------
        robot_ids
            IDs of every robot the fleet manager will supervise.
            Typically [1, 2, 3] for this warehouse deployment.
        heartbeat_timeout
            Seconds after the last heartbeat before a robot is declared
            OFFLINE.  Should be ≥2× the robot's heartbeat publish period
            (robot nodes publish at 1 Hz, so 5 s gives a 5× margin).
        low_battery_threshold
            Battery percentage below which a robot is excluded from new task
            assignments by available_robots() and nearest_available_robot().
        home_positions
            Optional override: {robot_id: (x, y)}.  If None, the class
            _DEFAULT_HOMES table is used.  The launch file and world file
            are the ground truth; keep these three in sync.
        """
        self._heartbeat_timeout     = heartbeat_timeout
        self._low_battery_threshold = low_battery_threshold
        self._lock = threading.RLock()   # reentrant — callbacks may call helpers

        homes = home_positions or self._DEFAULT_HOMES

        # Initialise one record per robot with seeded home pose
        self._records: Dict[int, RobotRecord] = {}
        for rid in robot_ids:
            hx, hy = homes.get(rid, (0.0, 0.0))
            self._records[rid] = RobotRecord(
                robot_id=rid,
                x=hx,
                y=hy,
                home_x=hx,
                home_y=hy,
            )

        # Parse-error counter — surfaced in logs to spot malformed payloads
        self._parse_errors: int = 0

    # =========================================================================
    # Write interface  (called from ROS2 subscriber callbacks)
    # =========================================================================

    def update_status(self, json_payload: str) -> bool:
        """
        Parse a JSON status string published by a robot node and update
        the corresponding RobotRecord.

        Returns True on success, False if the payload could not be parsed
        or contained an unrecognised robot_id.

        State-transition side-effects
        ------------------------------
        • NAVIGATING → any non-NAVIGATING : accumulates total_nav_time_s
        • any → EMERGENCY_STOP            : increments estop_count
        • EXECUTING → IDLE                : increments tasks_completed
          (proxy: task_id transitions from non-None to None)
        """
        try:
            data = json.loads(json_payload)
        except json.JSONDecodeError as exc:
            self._parse_errors += 1
            # Intentionally do not raise — a single bad packet should not
            # crash the fleet manager.  The heartbeat timeout will catch a
            # robot that stops publishing entirely.
            return False

        rid = data.get("robot_id")
        if rid not in self._records:
            return False

        with self._lock:
            rec = self._records[rid]
            now = time.monotonic()

            # ── Derive new state ───────────────────────────────────────────
            try:
                new_state = RobotState(data.get("state", "UNKNOWN"))
            except ValueError:
                new_state = RobotState.UNKNOWN

            prev_state   = rec.state
            prev_task_id = rec.task_id

            # ── Navigation timing ─────────────────────────────────────────
            if prev_state == RobotState.NAVIGATING and rec._nav_start_time > 0.0:
                if new_state != RobotState.NAVIGATING:
                    rec.total_nav_time_s += now - rec._nav_start_time
                    rec._nav_start_time = 0.0
            if new_state == RobotState.NAVIGATING and prev_state != RobotState.NAVIGATING:
                rec._nav_start_time = now

            # ── Emergency stop counter ────────────────────────────────────
            if (new_state == RobotState.EMERGENCY_STOP
                    and prev_state != RobotState.EMERGENCY_STOP):
                rec.estop_count += 1

            # ── Task completion counter ───────────────────────────────────
            # A task is considered complete when task_id transitions from a
            # non-None value to None and the robot returns to IDLE.
            incoming_task_id = data.get("task_id")
            if (prev_task_id is not None
                    and incoming_task_id is None
                    and new_state == RobotState.IDLE):
                rec.tasks_completed += 1

            # ── Update all fields ─────────────────────────────────────────
            rec.state              = new_state
            rec.x                  = float(data.get("x",       rec.x))
            rec.y                  = float(data.get("y",       rec.y))
            rec.yaw                = float(data.get("yaw",     rec.yaw))
            rec.battery            = float(data.get("battery", rec.battery))
            rec.task_id            = incoming_task_id
            rec.task_action        = data.get("task_action")
            rec.obstacle_detected  = bool(data.get("obstacle", False))
            rec.goal_x             = data.get("goal_x")
            rec.goal_y             = data.get("goal_y")
            rec.ros_timestamp_ns   = int(data.get("timestamp", 0))
            rec.last_status_time   = now

        return True

    def update_heartbeat(self, robot_id: int) -> None:
        """
        Record the wall-clock time of the most recent heartbeat from robot_id.
        Called by the Header subscriber callback in FleetManagerNode.
        """
        with self._lock:
            if robot_id in self._records:
                self._records[robot_id].last_heartbeat_time = time.monotonic()

    # =========================================================================
    # Read interface  (called by fleet manager, task allocator, dashboard)
    # =========================================================================

    def get_robot(self, robot_id: int) -> Optional[RobotRecord]:
        """Return the record for robot_id, or None if unknown."""
        with self._lock:
            return self._records.get(robot_id)

    def all_robots(self) -> List[RobotRecord]:
        """Return a list of all records (one per robot, sorted by robot_id)."""
        with self._lock:
            return sorted(self._records.values(), key=lambda r: r.robot_id)

    def robots_in_state(self, state: RobotState) -> List[RobotRecord]:
        """Return all robots currently in the given state."""
        with self._lock:
            return [r for r in self._records.values() if r.state == state]

    def available_robots(self) -> List[RobotRecord]:
        """
        Return IDLE robots that:
          • are alive (heartbeat within timeout), AND
          • have battery > low_battery_threshold.

        Sorted by battery level descending so the task allocator naturally
        prefers the most-charged robot when distances are equal.
        """
        with self._lock:
            candidates = [
                r for r in self._records.values()
                if r.state == RobotState.IDLE
                and r.battery > self._low_battery_threshold
                and self._is_alive_unsafe(r)
            ]
        return sorted(candidates, key=lambda r: r.battery, reverse=True)

    def nearest_available_robot(
        self, x: float, y: float
    ) -> Optional[RobotRecord]:
        """
        Return the available robot closest to point (x, y), or None.

        The task allocator calls this for simple distance-based dispatch.
        A more sophisticated allocator (task_allocator.py) weights distance
        against battery and current load; this helper is the fast-path.
        """
        candidates = self.available_robots()
        if not candidates:
            return None
        return min(candidates, key=lambda r: r.distance_to(x, y))

    def is_alive(self, robot_id: int) -> bool:
        """
        Return True if a heartbeat was received from robot_id within the
        configured timeout window.

        A robot that has never sent a heartbeat (last_heartbeat_time == 0.0)
        is considered NOT alive.  This prevents the fleet manager from
        dispatching to a robot whose node has not yet started.
        """
        with self._lock:
            rec = self._records.get(robot_id)
            if rec is None:
                return False
            return self._is_alive_unsafe(rec)

    def any_robot_near(
        self,
        x: float,
        y: float,
        radius: float,
        exclude_id: Optional[int] = None,
    ) -> bool:
        """
        Return True if any robot (except exclude_id) is within radius metres
        of point (x, y).

        Used by CollisionAvoidance as a fast spatial pre-check before
        computing detailed inter-robot distances.
        """
        with self._lock:
            for rec in self._records.values():
                if rec.robot_id == exclude_id:
                    continue
                if rec.distance_to(x, y) <= radius:
                    return True
        return False

    def robots_near(
        self,
        x: float,
        y: float,
        radius: float,
        exclude_id: Optional[int] = None,
    ) -> List[RobotRecord]:
        """
        Return all robots (except exclude_id) within radius metres of (x, y).

        Used by the collision avoidance module when it needs to identify
        *which* robots are in conflict, not just whether any are.
        """
        with self._lock:
            return [
                rec for rec in self._records.values()
                if rec.robot_id != exclude_id
                and rec.distance_to(x, y) <= radius
            ]

    # =========================================================================
    # Fleet-level summary helpers
    # =========================================================================

    def fleet_summary(self) -> dict:
        """
        Return a dict summarising fleet health for the dashboard and logs.

        Keys
        ----
        total           int   — number of robots registered
        alive           int   — robots with a recent heartbeat
        available       int   — IDLE robots above battery threshold
        navigating      int   — robots in NAVIGATING state
        executing       int   — robots in EXECUTING state
        charging        int   — robots in CHARGING state
        returning       int   — robots in RETURNING state
        emergency_stop  int   — robots in EMERGENCY_STOP state
        unknown         int   — robots in UNKNOWN state (no status yet)
        low_battery     int   — alive robots at or below battery threshold
        avg_battery     float — mean battery across all alive robots
        parse_errors    int   — cumulative malformed status payloads
        robots          list  — per-robot dicts from RobotRecord.as_dict()
        """
        with self._lock:
            all_rec = list(self._records.values())

        alive_recs = [r for r in all_rec if self._is_alive_unsafe(r)]

        state_counts = {s: 0 for s in RobotState}
        for r in all_rec:
            state_counts[r.state] += 1

        avg_battery = (
            sum(r.battery for r in alive_recs) / len(alive_recs)
            if alive_recs else 0.0
        )
        low_battery_count = sum(
            1 for r in alive_recs
            if r.battery <= self._low_battery_threshold
        )

        return {
            "total":          len(all_rec),
            "alive":          len(alive_recs),
            "available":      len(self.available_robots()),
            "navigating":     state_counts[RobotState.NAVIGATING],
            "executing":      state_counts[RobotState.EXECUTING],
            "charging":       state_counts[RobotState.CHARGING],
            "returning":      state_counts[RobotState.RETURNING],
            "emergency_stop": state_counts[RobotState.EMERGENCY_STOP],
            "unknown":        state_counts[RobotState.UNKNOWN],
            "low_battery":    low_battery_count,
            "avg_battery":    round(avg_battery, 2),
            "parse_errors":   self._parse_errors,
            "robots":         [r.as_dict() for r in sorted(all_rec, key=lambda r: r.robot_id)],
        }

    def record_task_assigned(self, robot_id: int, task_id: str, action: str) -> None:
        """
        Called by TaskAllocator immediately after it dispatches a goal so the
        registry reflects the assignment even before the robot's next status
        message arrives.  Prevents double-dispatch of the same task.
        """
        with self._lock:
            rec = self._records.get(robot_id)
            if rec is not None:
                rec.task_id     = task_id
                rec.task_action = action

    # =========================================================================
    # Internal helpers  (must be called with self._lock held)
    # =========================================================================

    def _is_alive_unsafe(self, rec: RobotRecord) -> bool:
        """
        Check liveness without acquiring the lock (caller must hold it).
        A robot is alive if:
          • It has sent at least one heartbeat (last_heartbeat_time > 0), AND
          • That heartbeat arrived within the timeout window.
        """
        if rec.last_heartbeat_time <= 0.0:
            return False
        return (time.monotonic() - rec.last_heartbeat_time) <= self._heartbeat_timeout

    # =========================================================================
    # Dunder helpers
    # =========================================================================

    def __len__(self) -> int:
        """Number of robots registered."""
        return len(self._records)

    def __contains__(self, robot_id: int) -> bool:
        """Supports `1 in registry` syntax."""
        return robot_id in self._records

    def __repr__(self) -> str:
        with self._lock:
            states = {rid: rec.state.value for rid, rec in self._records.items()}
        return f"RobotRegistry({states})"
