#!/usr/bin/env python3
# =============================================================================
# traffic_manager/collision_manager.py
# =============================================================================
# Fleet-level, inter-robot collision avoidance and traffic management.
#
# Role in the stack
# -----------------
#   CollisionManager sits between the TaskAllocator and the per-robot command
#   publishers.  It is called by FleetManagerNode on every allocation tick
#   (1 Hz) and on every robot status update (≈ 5–20 Hz) to ensure that no two
#   robots are on a collision course before a new goal is committed.
#
#                        ┌────────────────────────────────────────────────┐
#                        │            CollisionManager                    │
#                        │                                                │
#   RobotRegistry ───────┤→ live poses, paths, speeds, states            │
#   AStarPlanner  ───────┤→ replan_around_robots() on conflict           │
#   path_utils    ───────┤→ geometry / temporal separation helpers       │
#                        │                                                │
#                        │  ┌──────────────────────────────────────────┐ │
#                        │  │  Proximity monitor  (20 Hz)              │ │
#                        │  │  • pairwise Euclidean checks             │ │
#                        │  │  • triggers SOFT_STOP when < safe_dist  │ │
#                        │  └──────────────────────────────────────────┘ │
#                        │  ┌──────────────────────────────────────────┐ │
#                        │  │  Path-conflict gate  (pre-dispatch)      │ │
#                        │  │  • temporal_separation() lookahead       │ │
#                        │  │  • blocks dispatch if conflict predicted │ │
#                        │  │  • requests replan or yield delay        │ │
#                        │  └──────────────────────────────────────────┘ │
#                        │  ┌──────────────────────────────────────────┐ │
#                        │  │  Right-of-way (ROW) arbiter              │ │
#                        │  │  • priority rules: URGENT > NORMAL,      │ │
#                        │  │    higher battery, lower task count      │ │
#                        │  │  • yield_robot() injects pause command   │ │
#                        │  │  • resume_robot() lifts the pause        │ │
#                        │  └──────────────────────────────────────────┘ │
#                        │  ┌──────────────────────────────────────────┐ │
#                        │  │  Dynamic obstacle layer manager          │ │
#                        │  │  • marks each robot's footprint into     │ │
#                        │  │    AStarPlanner grid before a replan     │ │
#                        │  │  • clears stale marks after replan       │ │
#                        │  └──────────────────────────────────────────┘ │
#                        └────────────────────────────────────────────────┘
#                                        │
#                    ┌───────────────────┼───────────────────┐
#                    ▼                   ▼                   ▼
#           /fleet/robot_1/cmd   /fleet/robot_2/cmd  /fleet/robot_3/cmd
#                (SOFT_STOP / RESUME / new PoseStamped goal)
#
# Conflict taxonomy (ordered by severity)
# ----------------------------------------
#   NONE          — robots are well separated, no action required.
#   PROXIMITY     — robots are within safe_dist; one is commanded SOFT_STOP.
#   PATH_CROSSING — predicted future conflict on current planned paths;
#                   lower-priority robot is re-planned around the other.
#   HEAD_ON       — robots approaching each other in the same aisle;
#                   one robot yields at the nearest pull-aside point.
#   DEADLOCK      — both robots are yielding and neither can proceed;
#                   resolved by priority-based forced resume with replan.
#
# Parameters
# ----------
#   safe_dist         float  0.40 m  — hard proximity threshold
#                                      (2 × Burger half-width + margin)
#   warn_dist         float  0.80 m  — soft proximity threshold; triggers
#                                      anticipatory slow-down only
#   robot_radius      float  0.105 m — TurtleBot3 Burger half-width
#   replan_margin     float  0.15 m  — extra safety margin added to
#                                      robot_radius during replanning
#   yield_timeout     float  5.0 s   — max time a robot waits at yield
#                                      before a forced replan is issued
#   temporal_horizon  float  8.0 s   — look-ahead window for temporal
#                                      conflict prediction
#   temporal_step     float  0.25 s  — simulation step for temporal check
#   check_hz          float  5.0 Hz  — proximity monitor call rate
#                                      (CollisionManager does NOT own a
#                                       ROS timer; the caller drives it)
#
# Thread safety
# -------------
#   All public methods acquire self._lock (RLock).  The FleetManagerNode
#   calls check_proximity() from its status-subscription callbacks (possibly
#   interleaved) and gate_dispatch() from its allocation timer — the lock
#   ensures consistent state across both call sites.
#
# Integration
# -----------
#   Instantiate once in FleetManagerNode.__init__ and pass the same
#   AStarPlanner and RobotRegistry references:
#
#       from traffic_manager.collision_manager import CollisionManager
#
#       self._collision_mgr = CollisionManager(
#           registry        = self._registry,
#           planner         = self._planner,
#           cmd_publishers  = self._cmd_pubs,   # dict[int, Publisher<String>]
#           goal_publishers = self._goal_pubs,  # dict[int, Publisher<PoseStamped>]
#           node_logger     = self.get_logger(),
#           safe_dist       = 0.40,
#           warn_dist       = 0.80,
#       )
#
#   In the status subscriber callback (called for every robot status message):
#       self._collision_mgr.check_proximity()
#
#   In the TaskAllocator pre-dispatch hook (called before publishing a goal):
#       allowed = self._collision_mgr.gate_dispatch(
#           robot_id   = rid,
#           new_path   = planned_path,
#       )
#       if allowed:
#           self._publish_goal(rid, task)
#
# =============================================================================

from __future__ import annotations

import json
import math
import threading
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Callable, Dict, List, Optional, Set, Tuple

# ---------------------------------------------------------------------------
# Lazy ROS2 imports — module is unit-testable without a running ROS2 install.
# ---------------------------------------------------------------------------
try:
    from geometry_msgs.msg import PoseStamped
    from std_msgs.msg import String
    _ROS_AVAILABLE = True
except ImportError:
    _ROS_AVAILABLE = False

from fleet_manager.robot_registry import RobotRegistry, RobotRecord, RobotState
from navigation.astar_planner import AStarPlanner
from navigation.path_utils import (
    WorldPt,
    Path,
    euclidean_distance,
    heading_to,
    normalise_angle,
    path_length,
    temporal_separation,
    paths_conflict,
    earliest_conflict_point,
    lookahead_point,
    CHARGING_PADS,
)


# =============================================================================
# Public enumerations
# =============================================================================

class ConflictType(Enum):
    """
    Severity classification for a detected inter-robot conflict.

    Members are ordered by ascending severity so numeric comparison works:
        ConflictType.NONE < ConflictType.PROXIMITY < …
    """
    NONE          = 0
    PROXIMITY     = 1   # robots too close right now
    PATH_CROSSING = 2   # predicted future overlap on planned paths
    HEAD_ON       = 3   # approaching head-on in the same aisle
    DEADLOCK      = 4   # both yielding; neither can proceed


class ResolutionAction(Enum):
    """
    Action taken by the manager to resolve a conflict.
    """
    NONE            = auto()   # No action needed
    SOFT_STOP       = auto()   # Send SOFT_STOP to the lower-priority robot
    RESUME          = auto()   # Lift a previous SOFT_STOP
    REPLAN          = auto()   # Request A* replan around the other robot
    YIELD           = auto()   # Command a robot to pause at its current cell
    FORCE_RESUME    = auto()   # Break a deadlock by overriding yield timer


# =============================================================================
# Conflict event record
# =============================================================================

@dataclass
class ConflictEvent:
    """
    Immutable record of a single conflict detection and resolution event.
    Written to the event log and surfaced via get_conflict_log().
    """
    timestamp:    float             # time.monotonic()
    conflict_type: ConflictType
    robot_ids:    Tuple[int, ...]   # robots involved (ascending order)
    separation:   float             # metres between robots at detection time
    action:       ResolutionAction
    detail:       str               # human-readable description

    def as_dict(self) -> dict:
        return {
            "t":            round(self.timestamp, 3),
            "type":         self.conflict_type.name,
            "robots":       list(self.robot_ids),
            "separation_m": round(self.separation, 3),
            "action":       self.action.name,
            "detail":       self.detail,
        }


# =============================================================================
# Per-robot yield state
# =============================================================================

@dataclass
class _YieldState:
    """
    Tracks the yield status of a single robot.

    A robot enters YIELDING when the arbiter decides it must wait for another
    robot to pass.  It is released (RESUMING) either when the blocking robot
    has cleared the conflict zone, or when the yield_timeout expires and a
    forced replan is issued.
    """
    robot_id:       int
    yielding:       bool  = False
    yield_start:    float = 0.0     # time.monotonic() when yield began
    blocking_robot: Optional[int] = None  # robot_id of the blocker


# =============================================================================
# CollisionManager
# =============================================================================

class CollisionManager:
    """
    Fleet-level inter-robot collision avoidance and traffic arbiter.

    Responsibilities
    ----------------
    1. **Proximity monitoring** — pairwise distance check on every call to
       check_proximity().  When two robots are within safe_dist a SOFT_STOP
       is issued to the lower-priority robot; when they separate beyond
       warn_dist the stop is lifted.

    2. **Pre-dispatch path gate** — gate_dispatch() uses temporal_separation()
       to predict whether a newly planned path would conflict with any
       currently active robot path.  If a conflict is predicted it blocks
       dispatch and optionally requests a replan with the conflicting robot's
       position injected as a dynamic obstacle.

    3. **Right-of-way arbitration** — when two robots are in conflict the
       arbiter picks a winner using:
           a. Task priority (URGENT > HIGH > NORMAL > LOW)
           b. Battery level (higher battery wins ties)
           c. Cumulative task count (fewer tasks wins ties at equal battery)
       The loser is commanded to yield.

    4. **Deadlock detection and resolution** — if both robots in a conflict
       are simultaneously in a YIELDING state for longer than yield_timeout,
       the lower-priority robot receives a forced REPLAN command; the
       higher-priority robot is immediately resumed.

    5. **Dynamic obstacle layer management** — before requesting a replan the
       manager injects the positions of all other active robots into the
       AStarPlanner's dynamic grid layer, then clears them afterwards.

    Thread safety
    -------------
    All public methods are protected by self._lock (threading.RLock).
    """

    # ── Default parameters ─────────────────────────────────────────────────
    _DEFAULT_SAFE_DIST:        float = 0.40   # m — hard stop threshold
    _DEFAULT_WARN_DIST:        float = 0.80   # m — soft warning threshold
    _DEFAULT_ROBOT_RADIUS:     float = 0.105  # m — TurtleBot3 Burger
    _DEFAULT_REPLAN_MARGIN:    float = 0.15   # m — extra inflation for replanning
    _DEFAULT_YIELD_TIMEOUT:    float = 5.0    # s
    _DEFAULT_TEMPORAL_HORIZON: float = 8.0    # s
    _DEFAULT_TEMPORAL_STEP:    float = 0.25   # s
    _MAX_EVENT_LOG:            int   = 200    # events kept in circular buffer

    # ── Approach heading tolerance to classify head-on (radians) ───────────
    # Two robots are "head-on" if their headings differ by more than this
    # from π (i.e. they are within _HEAD_ON_ARC of anti-parallel).
    _HEAD_ON_ARC: float = math.radians(30.0)

    def __init__(
        self,
        registry:        RobotRegistry,
        planner:         AStarPlanner,
        cmd_publishers:  Dict,              # {robot_id: rclpy Publisher<String>}
        goal_publishers: Dict,              # {robot_id: rclpy Publisher<PoseStamped>}
        node_logger,                        # rclpy Logger (or None for tests)
        safe_dist:          float = _DEFAULT_SAFE_DIST,
        warn_dist:          float = _DEFAULT_WARN_DIST,
        robot_radius:       float = _DEFAULT_ROBOT_RADIUS,
        replan_margin:      float = _DEFAULT_REPLAN_MARGIN,
        yield_timeout:      float = _DEFAULT_YIELD_TIMEOUT,
        temporal_horizon:   float = _DEFAULT_TEMPORAL_HORIZON,
        temporal_step:      float = _DEFAULT_TEMPORAL_STEP,
        robot_ids:          Optional[List[int]] = None,
        clock_fn:           Callable[[], float] = time.monotonic,
    ) -> None:
        """
        Parameters
        ----------
        registry
            Shared RobotRegistry populated by FleetManagerNode.
        planner
            Shared AStarPlanner; its dynamic layer is mutated during replanning.
        cmd_publishers
            Dict mapping robot_id → rclpy Publisher for std_msgs/String commands.
        goal_publishers
            Dict mapping robot_id → rclpy Publisher for geometry_msgs/PoseStamped.
        node_logger
            rclpy Logger (pass None in unit tests for silent operation).
        safe_dist
            Hard proximity threshold in metres.  Robots closer than this
            trigger an immediate SOFT_STOP on the lower-priority robot.
        warn_dist
            Soft threshold.  Robots inside warn_dist but outside safe_dist
            are flagged as PATH_CROSSING candidates for temporal analysis.
        robot_radius
            Physical half-width of each robot (metres).  Added to obstacle
            inflation during dynamic replanning.
        replan_margin
            Additional clearance on top of robot_radius when injecting a robot
            as a dynamic obstacle before replanning.
        yield_timeout
            Seconds a robot may be held in YIELDING before a forced replan
            breaks the potential deadlock.
        temporal_horizon
            Maximum look-ahead in seconds for temporal conflict prediction.
        temporal_step
            Simulation step in seconds for temporal conflict prediction.
        robot_ids
            IDs of robots managed by this instance.  Defaults to [1, 2, 3].
        clock_fn
            Callable returning monotonic time in seconds.  Injected for tests.
        """
        self._registry   = registry
        self._planner    = planner
        self._cmd_pubs   = cmd_publishers
        self._goal_pubs  = goal_publishers
        self._logger     = node_logger
        self._clock      = clock_fn

        self._safe_dist        = safe_dist
        self._warn_dist        = warn_dist
        self._robot_radius     = robot_radius
        self._replan_margin    = replan_margin
        self._yield_timeout    = yield_timeout
        self._temporal_horizon = temporal_horizon
        self._temporal_step    = temporal_step

        self._robot_ids: List[int] = robot_ids if robot_ids else [1, 2, 3]

        # ── Per-robot yield state ──────────────────────────────────────────
        self._yield: Dict[int, _YieldState] = {
            rid: _YieldState(robot_id=rid) for rid in self._robot_ids
        }

        # ── Currently active planned paths (updated by gate_dispatch) ──────
        # {robot_id: Path}  — None if no path is known for this robot
        self._active_paths: Dict[int, Optional[Path]] = {
            rid: None for rid in self._robot_ids
        }

        # ── Speed estimates (m/s) for temporal separation checks ───────────
        # Updated from registry velocity data when available; default to
        # TurtleBot3 Burger max linear speed otherwise.
        self._speed_estimate: Dict[int, float] = {
            rid: 0.18 for rid in self._robot_ids   # conservative < 0.22 m/s max
        }

        # ── Robots currently commanded to SOFT_STOP ───────────────────────
        self._stopped: Set[int] = set()

        # ── Conflict event log (circular buffer of size _MAX_EVENT_LOG) ────
        self._event_log: List[ConflictEvent] = []

        # ── Statistics ────────────────────────────────────────────────────
        self._proximity_checks:   int = 0
        self._path_gate_checks:   int = 0
        self._replans_requested:  int = 0
        self._yields_issued:      int = 0
        self._deadlocks_resolved: int = 0

        # ── Reentrant lock ─────────────────────────────────────────────────
        self._lock = threading.RLock()

        self._log_info(
            "[CollisionManager] Initialised — "
            f"safe={safe_dist}m  warn={warn_dist}m  "
            f"yield_timeout={yield_timeout}s  "
            f"temporal_horizon={temporal_horizon}s"
        )

    # =========================================================================
    # Public API — called by FleetManagerNode
    # =========================================================================

    def check_proximity(self) -> List[ConflictEvent]:
        """
        Perform a pairwise proximity check on all active robots.

        Must be called regularly (FleetManagerNode's status subscriber or a
        dedicated timer at ≥ 5 Hz).  Internally rate-limits its own heavy
        work via a timestamp gate so calling it at higher frequency is safe.

        Algorithm
        ---------
        For every unique (robot_i, robot_j) pair:
          1. Compute Euclidean distance between current poses.
          2. If distance < safe_dist → PROXIMITY conflict:
                • Identify lower-priority robot via _row_winner().
                • Publish SOFT_STOP to the loser (if not already stopped).
                • Record event.
          3. If safe_dist ≤ distance < warn_dist and both robots are moving:
                • Check for head-on approach via _is_head_on().
                • If head-on → HEAD_ON conflict; yield the lower-priority robot.
          4. If distance ≥ warn_dist and either robot was SOFT_STOPped by this
             pair → publish RESUME and clear the stop flag.

        Returns
        -------
        List[ConflictEvent]
            New events generated during this call (empty if no conflicts).
        """
        with self._lock:
            self._proximity_checks += 1
            new_events: List[ConflictEvent] = []

            robots = self._registry.all_robots()
            now    = self._clock()

            for i in range(len(robots)):
                for j in range(i + 1, len(robots)):
                    ra = robots[i]
                    rb = robots[j]

                    # Skip robots that are not in a mobile state
                    if ra.state in (RobotState.CHARGING, RobotState.UNKNOWN):
                        continue
                    if rb.state in (RobotState.CHARGING, RobotState.UNKNOWN):
                        continue

                    sep = euclidean_distance((ra.x, ra.y), (rb.x, rb.y))

                    # ── Hard proximity: immediate SOFT_STOP ─────────────────
                    if sep < self._safe_dist:
                        evt = self._handle_proximity(ra, rb, sep, now)
                        if evt:
                            new_events.append(evt)

                    # ── Soft proximity: head-on detection ───────────────────
                    elif sep < self._warn_dist:
                        if (
                            ra.state == RobotState.NAVIGATING
                            and rb.state == RobotState.NAVIGATING
                        ):
                            if self._is_head_on(ra, rb):
                                evt = self._handle_head_on(ra, rb, sep, now)
                                if evt:
                                    new_events.append(evt)

                    # ── Robots have separated — resume if we stopped them ───
                    else:
                        self._maybe_resume_pair(ra.robot_id, rb.robot_id, sep, now)

            # ── Deadlock detection across all yielding robots ───────────────
            deadlock_events = self._check_deadlocks(now)
            new_events.extend(deadlock_events)

            return new_events

    def gate_dispatch(
        self,
        robot_id:  int,
        new_path:  Path,
        task_speed: Optional[float] = None,
    ) -> bool:
        """
        Pre-dispatch path conflict gate.

        Called by TaskAllocator **before** publishing a new goal to a robot.
        Checks whether the proposed path would cause a temporal conflict with
        any other robot's active path.

        Algorithm
        ---------
        1. For each other robot that has a known active path and is NAVIGATING
           or RETURNING:
              a. Estimate robot speeds (from speed_estimate dict or default).
              b. Call temporal_separation() with temporal_horizon lookahead.
              c. If a conflict is predicted within the horizon:
                   • Attempt a replan with all other active robots blocked.
                   • If replan succeeds → update active_path, return True.
                   • If replan fails    → return False (dispatch blocked).
        2. If no temporal conflict is detected:
              • Store new_path as active path for robot_id.
              • Return True (dispatch allowed).

        Parameters
        ----------
        robot_id
            ID of the robot about to be dispatched.
        new_path
            Planned path for the robot (from AStarPlanner.plan()).
        task_speed
            Estimated travel speed for the robot in m/s.  If None, the stored
            speed estimate is used.

        Returns
        -------
        bool
            True  → dispatch is safe; caller may publish the goal.
            False → conflict predicted; caller should delay dispatch or
                    wait for the next allocation tick.
        """
        with self._lock:
            self._path_gate_checks += 1

            if not new_path:
                return True   # Empty path — nothing to conflict with

            speed_a = task_speed or self._speed_estimate.get(robot_id, 0.18)

            for other_id, other_path in self._active_paths.items():
                if other_id == robot_id:
                    continue
                if not other_path:
                    continue

                other_rec = self._registry.get_robot(other_id)
                if other_rec is None:
                    continue
                if other_rec.state not in (
                    RobotState.NAVIGATING, RobotState.RETURNING
                ):
                    continue

                speed_b = self._speed_estimate.get(other_id, 0.18)

                conflict_t = temporal_separation(
                    path_a          = new_path,
                    speed_a         = speed_a,
                    path_b          = other_path,
                    speed_b         = speed_b,
                    time_step       = self._temporal_step,
                    safety_radius   = self._safe_dist,
                )

                if conflict_t is None or conflict_t > self._temporal_horizon:
                    continue  # No conflict within horizon with this robot

                # ── Conflict predicted — attempt replan ──────────────────────
                self._log_warning(
                    f"[CollisionManager] Path conflict predicted: "
                    f"robot_{robot_id} vs robot_{other_id} "
                    f"at t+{conflict_t:.1f}s — attempting replan"
                )

                replanned = self._replan_around_others(
                    robot_id   = robot_id,
                    original_path = new_path,
                )

                if replanned is not None:
                    # Replan succeeded — update stored path and allow dispatch
                    self._active_paths[robot_id] = replanned
                    self._replans_requested += 1
                    self._record_event(ConflictEvent(
                        timestamp     = self._clock(),
                        conflict_type = ConflictType.PATH_CROSSING,
                        robot_ids     = tuple(sorted([robot_id, other_id])),
                        separation    = euclidean_distance(
                            (self._registry.get_robot(robot_id).x,
                             self._registry.get_robot(robot_id).y),
                            (other_rec.x, other_rec.y),
                        ),
                        action  = ResolutionAction.REPLAN,
                        detail  = (
                            f"Replan succeeded for robot_{robot_id}; "
                            f"conflict with robot_{other_id} at t+{conflict_t:.1f}s resolved"
                        ),
                    ))
                    return True   # Allow dispatch with the new path

                else:
                    # Replan failed — block dispatch this tick
                    self._record_event(ConflictEvent(
                        timestamp     = self._clock(),
                        conflict_type = ConflictType.PATH_CROSSING,
                        robot_ids     = tuple(sorted([robot_id, other_id])),
                        separation    = euclidean_distance(
                            (self._registry.get_robot(robot_id).x,
                             self._registry.get_robot(robot_id).y),
                            (other_rec.x, other_rec.y),
                        ),
                        action  = ResolutionAction.YIELD,
                        detail  = (
                            f"Replan failed for robot_{robot_id}; "
                            f"dispatch blocked pending robot_{other_id} movement"
                        ),
                    ))
                    self._log_warning(
                        f"[CollisionManager] Dispatch BLOCKED for robot_{robot_id}: "
                        f"replan failed, conflict with robot_{other_id} unresolved"
                    )
                    return False

            # ── No conflict — register path and allow dispatch ───────────────
            self._active_paths[robot_id] = new_path
            return True

    def register_path(self, robot_id: int, path: Optional[Path]) -> None:
        """
        Register or clear the active path for a robot without triggering a
        gate check.

        Called by FleetManagerNode when:
          • A robot completes its task and clears its goal (path=None).
          • A robot's path is externally replanned outside this module.

        Parameters
        ----------
        robot_id : int          — 1-based robot identifier.
        path     : Path | None  — new path, or None to clear.
        """
        with self._lock:
            self._active_paths[robot_id] = path

    def update_speed_estimate(self, robot_id: int, speed_ms: float) -> None:
        """
        Update the travel speed estimate for a robot.

        Called by FleetManagerNode when odometry-derived velocity is available
        from the robot's status message.  Speed estimates are used by the
        temporal separation check; stale estimates degrade to the default 0.18 m/s.

        Parameters
        ----------
        robot_id : int   — 1-based robot identifier.
        speed_ms : float — current speed in m/s (must be ≥ 0).
        """
        with self._lock:
            if speed_ms >= 0.0:
                # Exponential moving average with α = 0.3 to dampen noise
                current = self._speed_estimate.get(robot_id, 0.18)
                self._speed_estimate[robot_id] = 0.3 * speed_ms + 0.7 * current

    def clear_robot_state(self, robot_id: int) -> None:
        """
        Reset all collision-manager state for a robot.

        Called when a robot goes OFFLINE or IDLE so stale yield / stop flags
        do not affect the next dispatch cycle.

        Parameters
        ----------
        robot_id : int — robot to reset.
        """
        with self._lock:
            self._active_paths[robot_id]      = None
            self._yield[robot_id].yielding     = False
            self._yield[robot_id].blocking_robot = None
            if robot_id in self._stopped:
                self._stopped.discard(robot_id)

    # =========================================================================
    # Diagnostics and introspection
    # =========================================================================

    def get_conflict_log(self, last_n: int = 20) -> List[dict]:
        """
        Return the most recent *last_n* conflict events as plain dicts.

        Parameters
        ----------
        last_n : int — number of events to return (capped at _MAX_EVENT_LOG).

        Returns
        -------
        List[dict]
            Most-recent events first.
        """
        with self._lock:
            return [e.as_dict() for e in self._event_log[-last_n:]][::-1]

    def stats(self) -> dict:
        """
        Return accumulated operational statistics.

        Returns
        -------
        dict with keys:
            proximity_checks   — total calls to check_proximity()
            path_gate_checks   — total calls to gate_dispatch()
            replans_requested  — paths that were replanned due to conflict
            yields_issued      — SOFT_STOP / YIELD commands sent
            deadlocks_resolved — deadlock break-outs performed
            currently_stopped  — robot IDs currently SOFT_STOPped
            currently_yielding — robot IDs currently in YIELDING state
        """
        with self._lock:
            return {
                "proximity_checks":   self._proximity_checks,
                "path_gate_checks":   self._path_gate_checks,
                "replans_requested":  self._replans_requested,
                "yields_issued":      self._yields_issued,
                "deadlocks_resolved": self._deadlocks_resolved,
                "currently_stopped":  sorted(self._stopped),
                "currently_yielding": sorted(
                    rid for rid, ys in self._yield.items() if ys.yielding
                ),
            }

    def active_paths_snapshot(self) -> Dict[int, Optional[List]]:
        """
        Return a copy of the active path registry for diagnostics / RViz.

        Returns
        -------
        dict mapping robot_id → path (list of (x,y) tuples) or None.
        """
        with self._lock:
            return {
                rid: list(p) if p else None
                for rid, p in self._active_paths.items()
            }

    # =========================================================================
    # Proximity conflict handler
    # =========================================================================

    def _handle_proximity(
        self,
        ra:  RobotRecord,
        rb:  RobotRecord,
        sep: float,
        now: float,
    ) -> Optional[ConflictEvent]:
        """
        Respond to a hard-proximity (< safe_dist) conflict between ra and rb.

        The right-of-way winner continues; the loser receives SOFT_STOP.

        Returns
        -------
        ConflictEvent if an action was taken, else None (already handled).
        """
        winner_id, loser_id = self._row_winner(ra, rb)

        if loser_id in self._stopped:
            # Already stopped — nothing more to do this tick
            return None

        self._send_command(loser_id, "SOFT_STOP")
        self._stopped.add(loser_id)
        self._yields_issued += 1

        detail = (
            f"PROXIMITY: robot_{loser_id} SOFT_STOPped; "
            f"robot_{winner_id} has ROW; separation={sep:.3f}m"
        )
        self._log_warning(f"[CollisionManager] {detail}")

        evt = ConflictEvent(
            timestamp     = now,
            conflict_type = ConflictType.PROXIMITY,
            robot_ids     = tuple(sorted([ra.robot_id, rb.robot_id])),
            separation    = sep,
            action        = ResolutionAction.SOFT_STOP,
            detail        = detail,
        )
        self._record_event(evt)
        return evt

    # =========================================================================
    # Head-on conflict handler
    # =========================================================================

    def _handle_head_on(
        self,
        ra:  RobotRecord,
        rb:  RobotRecord,
        sep: float,
        now: float,
    ) -> Optional[ConflictEvent]:
        """
        Respond to a head-on approach (anti-parallel headings, warn_dist zone).

        The lower-priority robot is placed in YIELDING state.  Its yield timer
        starts now; if it does not clear by yield_timeout the deadlock resolver
        will intervene.

        Returns
        -------
        ConflictEvent if a new yield was initiated, else None.
        """
        winner_id, loser_id = self._row_winner(ra, rb)
        ys = self._yield[loser_id]

        if ys.yielding:
            # Already yielding — refresh blocking robot but don't re-issue
            ys.blocking_robot = winner_id
            return None

        ys.yielding       = True
        ys.yield_start    = now
        ys.blocking_robot = winner_id

        self._send_command(loser_id, "SOFT_STOP")
        self._stopped.add(loser_id)
        self._yields_issued += 1

        detail = (
            f"HEAD_ON: robot_{loser_id} yields to robot_{winner_id}; "
            f"separation={sep:.3f}m"
        )
        self._log_warning(f"[CollisionManager] {detail}")

        evt = ConflictEvent(
            timestamp     = now,
            conflict_type = ConflictType.HEAD_ON,
            robot_ids     = tuple(sorted([ra.robot_id, rb.robot_id])),
            separation    = sep,
            action        = ResolutionAction.YIELD,
            detail        = detail,
        )
        self._record_event(evt)
        return evt

    # =========================================================================
    # Resume logic
    # =========================================================================

    def _maybe_resume_pair(
        self,
        id_a: int,
        id_b: int,
        sep:  float,
        now:  float,
    ) -> None:
        """
        Resume either robot in the pair if they were SOFT_STOPped due to
        each other and have now separated beyond warn_dist.

        Only resumes robots that are not yielding due to an unresolved head-on
        with a *different* robot.
        """
        for rid, other in [(id_a, id_b), (id_b, id_a)]:
            if rid not in self._stopped:
                continue
            ys = self._yield[rid]
            # Resume only if the blocking robot is the one that moved away
            if ys.yielding and ys.blocking_robot != other:
                continue

            self._send_command(rid, "RESUME")
            self._stopped.discard(rid)
            ys.yielding       = False
            ys.blocking_robot = None

            self._log_info(
                f"[CollisionManager] robot_{rid} RESUMED — "
                f"cleared separation={sep:.3f}m from robot_{other}"
            )
            self._record_event(ConflictEvent(
                timestamp     = now,
                conflict_type = ConflictType.NONE,
                robot_ids     = (rid,),
                separation    = sep,
                action        = ResolutionAction.RESUME,
                detail        = f"robot_{rid} resumed after clearing robot_{other}",
            ))

    # =========================================================================
    # Deadlock detection and resolution
    # =========================================================================

    def _check_deadlocks(self, now: float) -> List[ConflictEvent]:
        """
        Detect and resolve deadlock states.

        A deadlock is identified when:
          • Two robots are both in YIELDING state, AND
          • Both reference each other as the blocking robot, AND
          • At least one has exceeded yield_timeout.

        Resolution:
          1. Determine the lower-priority robot (ROW loser).
          2. Issue a forced REPLAN for the loser around the winner's position.
          3. Resume the winner immediately.

        Returns
        -------
        List[ConflictEvent] — one event per resolved deadlock.
        """
        events: List[ConflictEvent] = []

        yielding_ids = [
            rid for rid, ys in self._yield.items()
            if ys.yielding
        ]

        for i in range(len(yielding_ids)):
            for j in range(i + 1, len(yielding_ids)):
                rid_a = yielding_ids[i]
                rid_b = yielding_ids[j]

                ys_a = self._yield[rid_a]
                ys_b = self._yield[rid_b]

                # Check mutual blocking
                mutual = (
                    ys_a.blocking_robot == rid_b
                    and ys_b.blocking_robot == rid_a
                )
                if not mutual:
                    continue

                # Check timeout on either
                elapsed_a = now - ys_a.yield_start
                elapsed_b = now - ys_b.yield_start

                if (
                    elapsed_a < self._yield_timeout
                    and elapsed_b < self._yield_timeout
                ):
                    continue  # Give them more time

                # ── Deadlock confirmed — resolve ──────────────────────────
                rec_a = self._registry.get_robot(rid_a)
                rec_b = self._registry.get_robot(rid_b)

                if rec_a is None or rec_b is None:
                    continue

                winner_id, loser_id = self._row_winner(rec_a, rec_b)
                loser_ys  = self._yield[loser_id]

                # Attempt replan for the loser around the winner
                loser_path = self._active_paths.get(loser_id)
                loser_rec  = self._registry.get_robot(loser_id)

                if loser_rec and loser_rec.goal_x is not None:
                    replanned = self._replan_around_others(
                        robot_id      = loser_id,
                        original_path = loser_path,
                    )
                    if replanned:
                        self._active_paths[loser_id] = replanned
                        self._publish_replanned_goal(loser_id, loser_rec)
                        self._replans_requested += 1

                # Resume the winner
                self._send_command(winner_id, "RESUME")
                self._stopped.discard(winner_id)
                self._yield[winner_id].yielding       = False
                self._yield[winner_id].blocking_robot = None

                # Clear the loser's yield (it has a new path)
                loser_ys.yielding       = False
                loser_ys.blocking_robot = None
                self._stopped.discard(loser_id)

                self._deadlocks_resolved += 1

                sep = euclidean_distance((rec_a.x, rec_a.y), (rec_b.x, rec_b.y))
                detail = (
                    f"DEADLOCK resolved: robot_{winner_id} resumes; "
                    f"robot_{loser_id} replanned. "
                    f"yield_elapsed=({elapsed_a:.1f}s, {elapsed_b:.1f}s)"
                )
                self._log_error(f"[CollisionManager] {detail}")

                events.append(ConflictEvent(
                    timestamp     = now,
                    conflict_type = ConflictType.DEADLOCK,
                    robot_ids     = tuple(sorted([rid_a, rid_b])),
                    separation    = sep,
                    action        = ResolutionAction.FORCE_RESUME,
                    detail        = detail,
                ))

        return events

    # =========================================================================
    # Right-of-way arbiter
    # =========================================================================

    def _row_winner(
        self,
        ra: RobotRecord,
        rb: RobotRecord,
    ) -> Tuple[int, int]:
        """
        Determine right-of-way between two robots.

        Priority rules (first rule that distinguishes them wins):
          1. Task priority: URGENT > HIGH > NORMAL > LOW.
             Extracted from the robot's task_action if it encodes priority,
             otherwise defaults to NORMAL for all non-CHARGE tasks, LOW for
             CHARGE tasks (a robot returning to charge should yield).
          2. Battery level: higher battery wins ties (a low-battery robot
             returning to charge should not be delayed further).
          3. Task count: fewer completed tasks wins (load balancing).
          4. Robot ID: lower ID wins as a deterministic tiebreaker.

        Returns
        -------
        (winner_id, loser_id) — both are robot_id integers.
        """
        score_a = self._row_score(ra)
        score_b = self._row_score(rb)

        if score_a >= score_b:
            return ra.robot_id, rb.robot_id
        return rb.robot_id, ra.robot_id

    @staticmethod
    def _row_score(rec: RobotRecord) -> Tuple:
        """
        Return a comparable tuple for ROW priority.

        Higher tuple = higher right-of-way priority.
        """
        # Task priority component
        action = (rec.task_action or "").upper()
        if "URGENT" in action:
            task_prio = 4
        elif "HIGH" in action:
            task_prio = 3
        elif "CHARGE" in action or rec.state in (RobotState.RETURNING,):
            task_prio = 1   # charging robots yield unless at critical battery
        else:
            task_prio = 2   # NORMAL

        # Critical battery override: if < 10% battery, boost priority so
        # the robot can reach the charger without being delayed.
        if rec.battery < 10.0:
            task_prio = max(task_prio, 3)

        return (
            task_prio,
            round(rec.battery, 0),          # higher battery = higher prio
            -rec.tasks_completed,            # fewer tasks = higher prio
            -rec.robot_id,                   # lower ID = higher prio (tiebreaker)
        )

    # =========================================================================
    # Head-on detection
    # =========================================================================

    def _is_head_on(self, ra: RobotRecord, rb: RobotRecord) -> bool:
        """
        Return True if robots ra and rb are approaching each other head-on.

        Classification criteria:
          • Both robots are NAVIGATING.
          • Their current headings (yaw) differ from anti-parallel by less than
            _HEAD_ON_ARC radians (i.e. they are facing each other).
          • The bearing from ra to rb is within 90° of ra's heading AND the
            bearing from rb to ra is within 90° of rb's heading (approaching,
            not passing).

        Uses yaw as a proxy for velocity heading (valid when the robot is
        forward-driving, which is the normal navigation mode).
        """
        if ra.state != RobotState.NAVIGATING or rb.state != RobotState.NAVIGATING:
            return False

        # Are they facing roughly opposite directions?
        heading_diff = abs(normalise_angle(ra.yaw - rb.yaw))
        if abs(heading_diff - math.pi) > self._HEAD_ON_ARC:
            return False

        # Are they each approaching the other (bearing aligns with heading)?
        bearing_ab = heading_to((ra.x, ra.y), (rb.x, rb.y))
        bearing_ba = heading_to((rb.x, rb.y), (ra.x, ra.y))

        approaching_a = abs(normalise_angle(bearing_ab - ra.yaw)) < math.pi / 2
        approaching_b = abs(normalise_angle(bearing_ba - rb.yaw)) < math.pi / 2

        return approaching_a and approaching_b

    # =========================================================================
    # Dynamic obstacle injection and replanning
    # =========================================================================

    def _replan_around_others(
        self,
        robot_id:      int,
        original_path: Optional[Path],
    ) -> Optional[Path]:
        """
        Request a new path for *robot_id* that avoids all other active robots.

        Steps
        -----
        1. Collect poses of all other robots that are NAVIGATING or RETURNING.
        2. Inject them as dynamic obstacles in the AStarPlanner grid.
        3. Call planner.replan_around_robots() from the robot's current pose
           to its current goal.
        4. Clear the dynamic obstacle layer.

        Parameters
        ----------
        robot_id      : int          — robot requesting a replan.
        original_path : Path | None  — used only for logging; the replan
                                       always uses the robot's live goal pose.

        Returns
        -------
        Optional[Path]
            New collision-free path, or None if no path could be found.
        """
        rec = self._registry.get_robot(robot_id)
        if rec is None or rec.goal_x is None or rec.goal_y is None:
            return None

        start: WorldPt = (rec.x, rec.y)
        goal:  WorldPt = (rec.goal_x, rec.goal_y)

        # Build dynamic block list: all other mobile robots
        dynamic_blocks: List[Tuple[WorldPt, float]] = []
        for other in self._registry.all_robots():
            if other.robot_id == robot_id:
                continue
            if other.state in (RobotState.CHARGING, RobotState.UNKNOWN, RobotState.IDLE):
                continue
            block_radius = self._robot_radius + self._replan_margin
            dynamic_blocks.append(((other.x, other.y), block_radius))

        if not dynamic_blocks:
            # No moving obstacles — replan on clean grid
            return self._planner.plan(start, goal)

        new_path = self._planner.replan_around_robots(
            start   = start,
            goal    = goal,
            robots  = dynamic_blocks,
        )

        orig_len = path_length(original_path) if original_path else 0.0
        new_len  = path_length(new_path) if new_path else 0.0
        self._log_info(
            f"[CollisionManager] Replan robot_{robot_id}: "
            f"blocked_by={len(dynamic_blocks)} robots  "
            f"orig_len={orig_len:.2f}m  new_len={new_len:.2f}m  "
            f"{'OK' if new_path else 'FAILED'}"
        )

        return new_path

    def _publish_replanned_goal(
        self, robot_id: int, rec: RobotRecord
    ) -> None:
        """
        Publish a PoseStamped to the robot's goal topic with its existing
        goal coordinates (after a replan the goal does not change, only
        the path does — but the robot needs a fresh goal message to resume).

        No-op if ROS2 is not available (unit-test mode).
        """
        if not _ROS_AVAILABLE:
            return
        pub = self._goal_pubs.get(robot_id)
        if pub is None or rec.goal_x is None:
            return

        from builtin_interfaces.msg import Time as RosTime

        msg = PoseStamped()
        msg.header.frame_id = "world"
        msg.pose.position.x = rec.goal_x
        msg.pose.position.y = rec.goal_y
        msg.pose.position.z = 0.0
        msg.pose.orientation.w = 1.0   # identity quaternion (yaw = 0)
        pub.publish(msg)

    # =========================================================================
    # Command publishing helpers
    # =========================================================================

    def _send_command(self, robot_id: int, command: str) -> None:
        """
        Publish a string command to /fleet/robot_<id>/command.

        Recognised by robot nodes: STOP | SOFT_STOP | RESUME | CANCEL |
        RETURN_TO_CHARGE.

        Gracefully no-ops when ROS2 is unavailable (unit tests).
        """
        if not _ROS_AVAILABLE:
            return
        pub = self._cmd_pubs.get(robot_id)
        if pub is None:
            self._log_error(
                f"[CollisionManager] No command publisher for robot_{robot_id}"
            )
            return
        msg      = String()
        msg.data = command
        pub.publish(msg)

    # =========================================================================
    # Event log
    # =========================================================================

    def _record_event(self, event: ConflictEvent) -> None:
        """Append event to the circular log, evicting oldest if at capacity."""
        if len(self._event_log) >= self._MAX_EVENT_LOG:
            self._event_log.pop(0)
        self._event_log.append(event)

    # =========================================================================
    # Logger helpers  (no-ops when node_logger is None for unit tests)
    # =========================================================================

    def _log_info(self, msg: str) -> None:
        if self._logger:
            self._logger.info(msg)

    def _log_warning(self, msg: str) -> None:
        if self._logger:
            self._logger.warning(msg)

    def _log_error(self, msg: str) -> None:
        if self._logger:
            self._logger.error(msg)

    # =========================================================================
    # Dunder helpers
    # =========================================================================

    def __repr__(self) -> str:
        with self._lock:
            stopped  = sorted(self._stopped)
            yielding = sorted(
                rid for rid, ys in self._yield.items() if ys.yielding
            )
        return (
            f"CollisionManager("
            f"safe={self._safe_dist}m, "
            f"warn={self._warn_dist}m, "
            f"stopped={stopped}, "
            f"yielding={yielding})"
        )


# =============================================================================
# Module self-test  (python -m traffic_manager.collision_manager)
# =============================================================================

if __name__ == "__main__":  # pragma: no cover
    import sys

    # ------------------------------------------------------------------
    # Minimal stubs so the test runs without ROS2 or real fleet classes
    # ------------------------------------------------------------------

    class _FakeRecord:
        def __init__(self, rid, x, y, yaw=0.0, battery=80.0, state="NAVIGATING",
                     task_action="PICK", tasks_completed=0, goal_x=None, goal_y=None):
            self.robot_id        = rid
            self.x               = x
            self.y               = y
            self.yaw             = yaw
            self.battery         = battery
            self.state           = RobotState(state)
            self.task_action     = task_action
            self.tasks_completed = tasks_completed
            self.goal_x          = goal_x
            self.goal_y          = goal_y
            self.obstacle_detected = False

        def distance_to(self, x, y):
            return math.hypot(x - self.x, y - self.y)

    class _FakeRegistry:
        def __init__(self, records):
            self._records = {r.robot_id: r for r in records}

        def all_robots(self):
            return list(self._records.values())

        def get_robot(self, rid):
            return self._records.get(rid)

        def robots_near(self, x, y, radius, exclude_id=None):
            return [
                r for r in self._records.values()
                if r.robot_id != exclude_id and r.distance_to(x, y) <= radius
            ]

    class _FakePlanner:
        def plan(self, start, goal, **kw):
            # Straight-line path with 5 points
            n = 5
            return [
                (start[0] + (goal[0]-start[0])*i/(n-1),
                 start[1] + (goal[1]-start[1])*i/(n-1))
                for i in range(n)
            ]

        def replan_around_robots(self, start, goal, robots, **kw):
            return self.plan(start, goal)

    # ------------------------------------------------------------------
    # Test 1: ROW winner — URGENT task beats NORMAL
    # ------------------------------------------------------------------
    rec_a = _FakeRecord(1, 0.0, 0.0, task_action="URGENT_PICK", battery=50.0)
    rec_b = _FakeRecord(2, 0.1, 0.0, task_action="PICK",        battery=80.0)

    mgr = CollisionManager(
        registry        = _FakeRegistry([rec_a, rec_b]),
        planner         = _FakePlanner(),
        cmd_publishers  = {},
        goal_publishers = {},
        node_logger     = None,
    )
    winner, loser = mgr._row_winner(rec_a, rec_b)
    assert winner == 1, f"ROW winner should be robot_1 (URGENT); got {winner}"
    print(f"[test] ROW winner (URGENT vs NORMAL): robot_{winner}  ✓")

    # ------------------------------------------------------------------
    # Test 2: ROW winner — equal task priority, higher battery wins
    # ------------------------------------------------------------------
    rec_c = _FakeRecord(1, 0.0, 0.0, task_action="PICK", battery=40.0)
    rec_d = _FakeRecord(2, 0.1, 0.0, task_action="PICK", battery=80.0)
    mgr2  = CollisionManager(
        registry        = _FakeRegistry([rec_c, rec_d]),
        planner         = _FakePlanner(),
        cmd_publishers  = {},
        goal_publishers = {},
        node_logger     = None,
    )
    winner2, loser2 = mgr2._row_winner(rec_c, rec_d)
    assert winner2 == 2, f"ROW winner should be robot_2 (higher battery); got {winner2}"
    print(f"[test] ROW winner (battery 40 vs 80): robot_{winner2}  ✓")

    # ------------------------------------------------------------------
    # Test 3: _is_head_on — opposing headings, approaching
    # ------------------------------------------------------------------
    ra = _FakeRecord(1, -1.0, 0.0, yaw=0.0)           # facing East, moving East
    rb = _FakeRecord(2,  1.0, 0.0, yaw=math.pi)       # facing West, moving West
    assert mgr._is_head_on(ra, rb), "Should detect head-on"
    print("[test] _is_head_on (anti-parallel, approaching): True  ✓")

    ra_parallel = _FakeRecord(1, -1.0, 0.0, yaw=0.0)
    rb_parallel = _FakeRecord(2,  1.0, 0.0, yaw=0.0)  # same direction
    assert not mgr._is_head_on(ra_parallel, rb_parallel), "Same direction should not be head-on"
    print("[test] _is_head_on (parallel, same direction): False  ✓")

    # ------------------------------------------------------------------
    # Test 4: gate_dispatch — non-conflicting paths pass through
    # ------------------------------------------------------------------
    rec_e = _FakeRecord(1, -8.0,  0.0, state="NAVIGATING", goal_x=0.0, goal_y=0.0)
    rec_f = _FakeRecord(2, -8.0, -1.0, state="NAVIGATING", goal_x=5.0, goal_y=5.0)
    reg4  = _FakeRegistry([rec_e, rec_f])
    mgr4  = CollisionManager(
        registry        = reg4,
        planner         = _FakePlanner(),
        cmd_publishers  = {},
        goal_publishers = {},
        node_logger     = None,
        safe_dist       = 0.4,
        warn_dist       = 0.8,
    )
    # Register a path for robot_2 that is far from robot_1's path
    mgr4.register_path(2, [(5.0, y) for y in range(10)])

    # robot_1's path down the y=0 aisle — far from robot_2's x=5 path
    path_r1 = [(float(x), 0.0) for x in range(-8, 1)]
    allowed  = mgr4.gate_dispatch(robot_id=1, new_path=path_r1)
    assert allowed, "Non-conflicting dispatch should be allowed"
    print("[test] gate_dispatch (no conflict): allowed=True  ✓")

    # ------------------------------------------------------------------
    # Test 5: stats() returns expected keys
    # ------------------------------------------------------------------
    s = mgr4.stats()
    expected_keys = {
        "proximity_checks", "path_gate_checks", "replans_requested",
        "yields_issued", "deadlocks_resolved",
        "currently_stopped", "currently_yielding",
    }
    assert expected_keys.issubset(s.keys()), f"Missing stats keys: {expected_keys - s.keys()}"
    print("[test] stats() keys: ✓")

    # ------------------------------------------------------------------
    # Test 6: update_speed_estimate applies EMA correctly
    # ------------------------------------------------------------------
    mgr4.update_speed_estimate(1, 0.22)
    spd = mgr4._speed_estimate[1]
    assert 0.17 < spd < 0.22, f"EMA speed estimate out of range: {spd}"
    print(f"[test] update_speed_estimate EMA={spd:.4f}  ✓")

    print("\n[collision_manager] All self-tests passed.")
    sys.exit(0)
